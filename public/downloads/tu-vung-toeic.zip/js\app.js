/**
 * Application Core Logic - TOEIC Vocabulary Trainer
 * Hỗ trợ nạp CSV, quản lý trạng thái học tập (localStorage),
 * lọc theo nhiều điều kiện, chế độ Flashcard và Trắc nghiệm với thời gian nghỉ và review lỗi sai.
 */

// Application State
const state = {
  allWords: [],          // Toàn bộ danh sách từ nạp từ CSV
  filteredWords: [],     // Danh sách sau khi áp dụng bộ lọc
  learnedWordsMap: {},   // { word: true } lưu trong localStorage
  
  // Filter states
  currentTab: 'list',    // 'list' | 'flashcard' | 'quiz'
  searchQuery: '',
  selectedStatus: 'all', // 'all' | 'unlearned' | 'learned'
  selectedTypes: new Set(['all']), // Set('all') hoặc Set('Danh từ', ...)
  
  // Pagination (List view)
  currentPage: 1,
  pageSize: 24,

  // Flashcard state
  fcIndex: 0,
  fcFlipped: false,

  // Quiz state
  quizConfig: {
    count: 10,
    source: 'all',
    type: 'all',
    questionMode: 'meaning',
    perQuestionTime: 15,
    pauseTime: 3 // 'manual' hoặc số giây
  },
  quizQuestions: [],
  quizCurrentIndex: 0,
  quizScore: 0,
  quizWrongAnswers: [],
  quizTimerInterval: null,
  quizTimeLeft: 15,
  quizAnswerLocked: false
};

// Storage Key
const STORAGE_LEARNED_KEY = 'toeic_learned_words_v1';
const STORAGE_THEME_KEY = 'toeic_app_theme';

// DOM Elements
const elements = {
  themeToggleBtn: document.getElementById('themeToggleBtn'),
  themeIcon: document.getElementById('themeIcon'),
  
  statTotalWords: document.getElementById('statTotalWords'),
  statLearnedCount: document.getElementById('statLearnedCount'),
  statUnlearnedCount: document.getElementById('statUnlearnedCount'),
  progressBarFill: document.getElementById('progressBarFill'),
  progressPercentage: document.getElementById('progressPercentage'),

  tabBtnList: document.getElementById('tabBtnList'),
  tabBtnFlashcard: document.getElementById('tabBtnFlashcard'),
  tabBtnQuiz: document.getElementById('tabBtnQuiz'),
  filtersSection: document.getElementById('filtersSection'),
  
  tabContentList: document.getElementById('tabContentList'),
  tabContentFlashcard: document.getElementById('tabContentFlashcard'),
  tabContentQuiz: document.getElementById('tabContentQuiz'),

  searchInput: document.getElementById('searchInput'),
  statusFilterChips: document.getElementById('statusFilterChips'),
  typeFilterChips: document.getElementById('typeFilterChips'),
  btnResetFilters: document.getElementById('btnResetFilters'),
  listResultCount: document.getElementById('listResultCount'),
  wordCardsGrid: document.getElementById('wordCardsGrid'),
  paginationControls: document.getElementById('paginationControls'),

  // Flashcard Elements
  flashcardElement: document.getElementById('flashcardElement'),
  fcProgressCounter: document.getElementById('fcProgressCounter'),
  fcFrontType: document.getElementById('fcFrontType'),
  fcFrontWord: document.getElementById('fcFrontWord'),
  fcFrontIpa: document.getElementById('fcFrontIpa'),
  fcAudioBtnFront: document.getElementById('fcAudioBtnFront'),
  fcBackWordSmall: document.getElementById('fcBackWordSmall'),
  fcBackMeaning: document.getElementById('fcBackMeaning'),
  fcBackExamples: document.getElementById('fcBackExamples'),
  fcAudioBtnBack: document.getElementById('fcAudioBtnBack'),
  fcBtnPrev: document.getElementById('fcBtnPrev'),
  fcBtnNext: document.getElementById('fcBtnNext'),
  fcBtnToggleLearn: document.getElementById('fcBtnToggleLearn'),
  fcLearnStatusText: document.getElementById('fcLearnStatusText'),
  fcLearnStatusIcon: document.getElementById('fcLearnStatusIcon'),

  // Quiz Elements
  quizSetupView: document.getElementById('quizSetupView'),
  quizActiveView: document.getElementById('quizActiveView'),
  quizResultView: document.getElementById('quizResultView'),
  
  quizConfigCount: document.getElementById('quizConfigCount'),
  quizConfigSource: document.getElementById('quizConfigSource'),
  quizConfigType: document.getElementById('quizConfigType'),
  quizConfigQuestionMode: document.getElementById('quizConfigQuestionMode'),
  quizConfigPerQuestionTime: document.getElementById('quizConfigPerQuestionTime'),
  quizConfigPauseTime: document.getElementById('quizConfigPauseTime'),
  btnStartQuiz: document.getElementById('btnStartQuiz'),
  
  quizCurrentProgress: document.getElementById('quizCurrentProgress'),
  quizTimerBadge: document.getElementById('quizTimerBadge'),
  quizTimeRemaining: document.getElementById('quizTimeRemaining'),
  quizTimerBar: document.getElementById('quizTimerBar'),
  quizQuestionWord: document.getElementById('quizQuestionWord'),
  quizQuestionPrompt: document.getElementById('quizQuestionPrompt'),
  quizQuestionIpa: document.getElementById('quizQuestionIpa'),
  quizQuestionType: document.getElementById('quizQuestionType'),
  quizQuestionAudioBtn: document.getElementById('quizQuestionAudioBtn'),
  quizOptionsGrid: document.getElementById('quizOptionsGrid'),
  quizInstantFeedback: document.getElementById('quizInstantFeedback'),
  quizFeedbackTitle: document.getElementById('quizFeedbackTitle'),
  quizFeedbackMeaning: document.getElementById('quizFeedbackMeaning'),
  quizFeedbackExamples: document.getElementById('quizFeedbackExamples'),
  quizNextManualBtn: document.getElementById('quizNextManualBtn'),

  resultScoreLarge: document.getElementById('resultScoreLarge'),
  resultScoreSub: document.getElementById('resultScoreSub'),
  wrongAnswersSection: document.getElementById('wrongAnswersSection'),
  wrongCount: document.getElementById('wrongCount'),
  wrongListContainer: document.getElementById('wrongListContainer'),
  btnRetryQuiz: document.getElementById('btnRetryQuiz'),
  btnBackToSetup: document.getElementById('btnBackToSetup')
};

/* ==========================================================================
   INITIALIZATION & DATA LOADING
   ========================================================================== */

async function initApp() {
  loadLearnedWordsFromStorage();
  loadThemePreference();
  setupEventListeners();

  let csvText = '';
  // Nếu có dữ liệu nhúng sẵn (cho phép click đúp mở trực tiếp file index.html mà không cần cài server)
  if (typeof embeddedCsvData !== 'undefined' && embeddedCsvData) {
    csvText = embeddedCsvData;
  } else {
    try {
      const response = await fetch('TOEIC_2026_vocabulary.csv');
      csvText = await response.text();
    } catch (error) {
      console.warn('Fetch CSV không thành công, thử dùng dữ liệu dự phòng:', error);
    }
  }

  if (csvText) {
    state.allWords = parseCSV(csvText);
    applyFilters();
    updateGlobalStats();
  } else {
    elements.wordCardsGrid.innerHTML = `
      <div style="grid-column: 1 / -1; padding: 2rem; text-align: center; color: var(--danger);">
        ⚠️ Không thể nạp dữ liệu từ vựng. Vui lòng mở lại file index.html!
      </div>
    `;
  }
}

/**
 * Phân tích cú pháp CSV xử lý đầy đủ trường có dấu phẩy và ngoặc kép
 */
function parseCSV(text) {
  const lines = text.split(/\r?\n/);
  const result = [];
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Phân tách CSV tính đến dấu ngoặc kép ""
    const fields = [];
    let insideQuotes = false;
    let currentField = '';

    for (let charIndex = 0; charIndex < line.length; charIndex++) {
      const char = line[charIndex];
      if (char === '"') {
        insideQuotes = !insideQuotes;
      } else if (char === ',' && !insideQuotes) {
        fields.push(currentField.trim());
        currentField = '';
      } else {
        currentField += char;
      }
    }
    fields.push(currentField.trim());

    if (fields.length >= 5) {
      const stt = fields[0];
      const word = fields[1].trim();
      const ipa = fields[2].trim();
      const type = fields[3].trim();
      const meaning = fields[4].replace(/^"|"$/g, '').trim();

      if (word) {
        result.push({
          id: stt || String(i),
          word: word,
          ipa: ipa,
          type: type,
          meaning: meaning
        });
      }
    }
  }

  return result;
}

/* ==========================================================================
   STORAGE & THEME MANAGEMENT
   ========================================================================== */

function loadLearnedWordsFromStorage() {
  try {
    const data = localStorage.getItem(STORAGE_LEARNED_KEY);
    state.learnedWordsMap = data ? JSON.parse(data) : {};
  } catch (e) {
    state.learnedWordsMap = {};
  }
}

function saveLearnedWordsToStorage() {
  try {
    localStorage.setItem(STORAGE_LEARNED_KEY, JSON.stringify(state.learnedWordsMap));
  } catch (e) {
    console.error('Không thể lưu vào localStorage:', e);
  }
  updateGlobalStats();
}

function toggleWordLearned(word) {
  if (state.learnedWordsMap[word]) {
    delete state.learnedWordsMap[word];
  } else {
    state.learnedWordsMap[word] = true;
  }
  saveLearnedWordsToStorage();
  
  // Re-render UI nếu đang ở tab Danh sách hoặc Flashcard
  if (state.currentTab === 'list') {
    renderListCards();
  } else if (state.currentTab === 'flashcard') {
    updateFlashcardContent();
  }
}

function loadThemePreference() {
  const saved = localStorage.getItem(STORAGE_THEME_KEY);
  if (saved === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
    elements.themeIcon.textContent = '☀️';
  } else {
    document.documentElement.removeAttribute('data-theme');
    elements.themeIcon.textContent = '🌙';
  }
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme');
  if (current === 'dark') {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem(STORAGE_THEME_KEY, 'light');
    elements.themeIcon.textContent = '🌙';
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem(STORAGE_THEME_KEY, 'dark');
    elements.themeIcon.textContent = '☀️';
  }
}

function updateGlobalStats() {
  const total = state.allWords.length;
  let learned = 0;
  for (const item of state.allWords) {
    if (state.learnedWordsMap[item.word]) {
      learned++;
    }
  }
  const unlearned = total - learned;
  const pct = total > 0 ? Math.round((learned / total) * 100) : 0;

  elements.statTotalWords.textContent = total.toLocaleString();
  elements.statLearnedCount.textContent = learned.toLocaleString();
  elements.statUnlearnedCount.textContent = unlearned.toLocaleString();
  elements.progressBarFill.style.width = `${pct}%`;
  elements.progressPercentage.textContent = `${pct}%`;
}

/* ==========================================================================
   AUDIO PRONUNCIATION (WEB SPEECH API)
   ========================================================================== */

function speakWord(text) {
  if (!('speechSynthesis' in window)) {
    alert('Trình duyệt của bạn chưa hỗ trợ chức năng phát âm.');
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-US';
  utterance.rate = 0.9; // Tốc độ vừa phải, rõ ràng
  window.speechSynthesis.speak(utterance);
}

/* ==========================================================================
   FILTERS & SEARCH LOGIC
   ========================================================================== */

function applyFilters() {
  const q = state.searchQuery.toLowerCase().trim();

  state.filteredWords = state.allWords.filter(item => {
    // 1. Lọc theo từ khóa
    if (q) {
      const matchWord = item.word.toLowerCase().includes(q);
      const matchMeaning = item.meaning.toLowerCase().includes(q);
      const matchIpa = item.ipa.toLowerCase().includes(q);
      if (!matchWord && !matchMeaning && !matchIpa) return false;
    }

    // 2. Lọc theo trạng thái đã học / chưa học
    const isLearned = !!state.learnedWordsMap[item.word];
    if (state.selectedStatus === 'learned' && !isLearned) return false;
    if (state.selectedStatus === 'unlearned' && isLearned) return false;

    // 3. Lọc theo nhiều loại từ (Multi-select)
    if (!state.selectedTypes.has('all')) {
      const itemType = (item.type || '').toLowerCase();
      let matchesAnySelected = false;
      for (const t of state.selectedTypes) {
        if (itemType.includes(t.toLowerCase())) {
          matchesAnySelected = true;
          break;
        }
      }
      if (!matchesAnySelected) return false;
    }

    return true;
  });

  // Reset pagination & flashcard index
  state.currentPage = 1;
  state.fcIndex = 0;
  state.fcFlipped = false;

  renderListCards();
  updateFlashcardContent();
}

/* ==========================================================================
   VIEW 1: RENDER LIST MODE
   ========================================================================== */

function getTypeBadgeClass(typeStr) {
  const t = (typeStr || '').toLowerCase();
  if (t.includes('danh từ') || t.includes('noun')) return 'noun';
  if (t.includes('động từ') || t.includes('verb')) return 'verb';
  if (t.includes('tính từ') || t.includes('adj')) return 'adj';
  if (t.includes('trạng từ') || t.includes('adv')) return 'adv';
  return 'phrase';
}

function renderListCards() {
  const total = state.filteredWords.length;
  elements.listResultCount.textContent = `Hiển thị ${total.toLocaleString()} từ phù hợp`;

  if (total === 0) {
    elements.wordCardsGrid.innerHTML = `
      <div style="grid-column: 1 / -1; padding: 3rem 1rem; text-align: center; color: var(--text-muted);">
        <p style="font-size: 2rem; margin-bottom: 0.5rem;">🔍</p>
        <p style="font-size: 1.1rem; font-weight: 600;">Không tìm thấy từ vựng nào phù hợp</p>
        <p style="font-size: 0.9rem;">Hãy thử đổi từ khóa tìm kiếm hoặc bấm Đặt lại bộ lọc.</p>
      </div>
    `;
    elements.paginationControls.innerHTML = '';
    return;
  }

  // Phân trang
  const totalPages = Math.ceil(total / state.pageSize);
  if (state.currentPage > totalPages) state.currentPage = totalPages;
  const startIdx = (state.currentPage - 1) * state.pageSize;
  const endIdx = Math.min(startIdx + state.pageSize, total);
  const currentBatch = state.filteredWords.slice(startIdx, endIdx);

  elements.wordCardsGrid.innerHTML = currentBatch.map(item => {
    const isLearned = !!state.learnedWordsMap[item.word];
    const typeClass = getTypeBadgeClass(item.type);
    const examples = getExamplesForWord(item.word, item.type, item.meaning);

    return `
      <div class="word-card ${isLearned ? 'learned' : ''}" data-word="${item.word}">
        <div>
          <div class="card-header-row">
            <div>
              <div class="word-term">${escapeHtml(item.word)}</div>
              <div class="word-phonetic">${escapeHtml(item.ipa)}</div>
            </div>
            <div class="card-actions-top">
              <button class="audio-btn" onclick="speakWord('${escapeSingleQuote(item.word)}')" title="Phát âm">
                🔊
              </button>
              <span class="status-badge ${isLearned ? 'learned' : 'unlearned'}" onclick="toggleWordLearned('${escapeSingleQuote(item.word)}')">
                ${isLearned ? '✓ Đã học' : '+ Chưa học'}
              </span>
            </div>
          </div>
          <span class="type-tag ${typeClass}">${escapeHtml(item.type)}</span>
          <div class="word-meaning">${escapeHtml(item.meaning)}</div>
        </div>

        <div class="examples-box">
          <div class="examples-box-title">
            <span>💬</span> 2 Câu ví dụ thực tế:
          </div>
          ${examples.map(ex => `
            <div class="example-item">
              <div class="example-en">• ${escapeHtml(ex.en)}</div>
              <div class="example-vi">${escapeHtml(ex.vi)}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');

  renderPagination(totalPages);
}

function renderPagination(totalPages) {
  if (totalPages <= 1) {
    elements.paginationControls.innerHTML = '';
    return;
  }

  let html = '';
  html += `<button class="page-btn" ${state.currentPage === 1 ? 'disabled' : ''} onclick="goToPage(${state.currentPage - 1})">« Trước</button>`;

  const maxVisiblePages = 5;
  let startPage = Math.max(1, state.currentPage - Math.floor(maxVisiblePages / 2));
  let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

  if (endPage - startPage + 1 < maxVisiblePages) {
    startPage = Math.max(1, endPage - maxVisiblePages + 1);
  }

  if (startPage > 1) {
    html += `<button class="page-btn" onclick="goToPage(1)">1</button>`;
    if (startPage > 2) html += `<span style="color: var(--text-muted); padding: 0 4px;">...</span>`;
  }

  for (let p = startPage; p <= endPage; p++) {
    html += `<button class="page-btn ${p === state.currentPage ? 'active' : ''}" onclick="goToPage(${p})">${p}</button>`;
  }

  if (endPage < totalPages) {
    if (endPage < totalPages - 1) html += `<span style="color: var(--text-muted); padding: 0 4px;">...</span>`;
    html += `<button class="page-btn" onclick="goToPage(${totalPages})">${totalPages}</button>`;
  }

  html += `<button class="page-btn" ${state.currentPage === totalPages ? 'disabled' : ''} onclick="goToPage(${state.currentPage + 1})">Sau »</button>`;
  elements.paginationControls.innerHTML = html;
}

function goToPage(page) {
  state.currentPage = page;
  renderListCards();
  window.scrollTo({ top: elements.filtersSection.offsetTop - 20, behavior: 'smooth' });
}

/* ==========================================================================
   VIEW 2: FLASHCARD MODE
   ========================================================================== */

function updateFlashcardContent() {
  const total = state.filteredWords.length;

  if (total === 0) {
    elements.fcProgressCounter.textContent = '0 / 0';
    elements.fcFrontWord.textContent = 'Không có từ';
    elements.fcFrontIpa.textContent = '';
    elements.fcFrontType.textContent = 'Trống';
    elements.fcBackMeaning.textContent = 'Vui lòng điều chỉnh lại bộ lọc để có từ vựng học.';
    elements.fcBackExamples.innerHTML = '';
    return;
  }

  if (state.fcIndex >= total) state.fcIndex = total - 1;
  if (state.fcIndex < 0) state.fcIndex = 0;

  const currentItem = state.filteredWords[state.fcIndex];
  const isLearned = !!state.learnedWordsMap[currentItem.word];
  const examples = getExamplesForWord(currentItem.word, currentItem.type, currentItem.meaning);

  elements.fcProgressCounter.textContent = `Thẻ ${state.fcIndex + 1} / ${total.toLocaleString()}`;
  
  // Mặt trước
  elements.fcFrontWord.textContent = currentItem.word;
  elements.fcFrontIpa.textContent = currentItem.ipa;
  elements.fcFrontType.textContent = currentItem.type;
  elements.fcFrontType.className = `type-tag ${getTypeBadgeClass(currentItem.type)}`;

  // Mặt sau
  elements.fcBackWordSmall.textContent = `${currentItem.word} ${currentItem.ipa}`;
  elements.fcBackMeaning.textContent = currentItem.meaning;
  elements.fcBackExamples.innerHTML = `
    <div style="font-weight: 600; font-size: 0.82rem; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase;">
      💬 2 Câu ví dụ thực tế:
    </div>
    ${examples.map(ex => `
      <div style="margin-bottom: 8px;">
        <div style="color: var(--text-main); font-weight: 600; font-size: 0.95rem;">• ${escapeHtml(ex.en)}</div>
        <div style="color: var(--text-muted); font-size: 0.88rem;">${escapeHtml(ex.vi)}</div>
      </div>
    `).join('')}
  `;

  // Trạng thái đã học/chưa học
  if (isLearned) {
    elements.fcLearnStatusIcon.textContent = '✓';
    elements.fcLearnStatusText.textContent = 'Đã học (Bấm để hủy)';
    elements.fcBtnToggleLearn.className = 'fc-btn fc-btn-learned';
  } else {
    elements.fcLearnStatusIcon.textContent = '+';
    elements.fcLearnStatusText.textContent = 'Đánh dấu đã học';
    elements.fcBtnToggleLearn.className = 'fc-btn fc-btn-flip';
  }

  // Nút nghe âm thanh
  elements.fcAudioBtnFront.onclick = (e) => {
    e.stopPropagation();
    speakWord(currentItem.word);
  };
  elements.fcAudioBtnBack.onclick = (e) => {
    e.stopPropagation();
    speakWord(currentItem.word);
  };

  // Đảm bảo không bị giật lật thẻ khi sang từ mới
  if (state.fcFlipped) {
    elements.flashcardElement.classList.remove('is-flipped');
    state.fcFlipped = false;
  }
}

function flipFlashcard() {
  state.fcFlipped = !state.fcFlipped;
  elements.flashcardElement.classList.toggle('is-flipped', state.fcFlipped);
}

function nextFlashcard() {
  if (state.filteredWords.length === 0) return;
  if (state.fcIndex < state.filteredWords.length - 1) {
    state.fcIndex++;
    updateFlashcardContent();
  } else {
    // Quay lại từ đầu nếu hết danh sách
    state.fcIndex = 0;
    updateFlashcardContent();
  }
}

function prevFlashcard() {
  if (state.filteredWords.length === 0) return;
  if (state.fcIndex > 0) {
    state.fcIndex--;
    updateFlashcardContent();
  }
}

/* ==========================================================================
   VIEW 3: QUIZ SYSTEM (TRẮC NGHIỆM ĐẦY ĐỦ TÍNH NĂNG)
   ========================================================================== */

function startQuiz() {
  // Đọc cài đặt
  const countVal = elements.quizConfigCount.value;
  const sourceVal = elements.quizConfigSource.value;
  const typeVal = elements.quizConfigType.value;
  const questionMode = elements.quizConfigQuestionMode.value;
  const timeVal = parseInt(elements.quizConfigPerQuestionTime.value, 10);
  const pauseVal = elements.quizConfigPauseTime.value;

  state.quizConfig.source = sourceVal;
  state.quizConfig.type = typeVal;
  state.quizConfig.questionMode = questionMode;
  state.quizConfig.perQuestionTime = timeVal;
  state.quizConfig.pauseTime = pauseVal === 'manual' ? 'manual' : parseFloat(pauseVal);

  // Lọc tập từ cho trắc nghiệm
  let pool = state.allWords.filter(item => {
    const isLearned = !!state.learnedWordsMap[item.word];
    if (sourceVal === 'learned' && !isLearned) return false;
    if (sourceVal === 'unlearned' && isLearned) return false;

    if (typeVal !== 'all') {
      if (!item.type.toLowerCase().includes(typeVal.toLowerCase())) return false;
    }
    return true;
  });

  if (pool.length < 4) {
    alert(`Số lượng từ vựng thỏa mãn điều kiện chỉ có ${pool.length} từ (cần ít nhất 4 từ để tạo 4 lựa chọn trắc nghiệm). Vui lòng chọn phạm vi rộng hơn!`);
    return;
  }

  // Trộn ngẫu nhiên câu hỏi (Fisher-Yates Shuffle)
  pool = shuffleArray([...pool]);

  let totalQuestions = countVal === 'all' ? pool.length : Math.min(parseInt(countVal, 10), pool.length);
  const selectedPool = pool.slice(0, totalQuestions);

  // Tạo cấu trúc câu hỏi & 4 lựa chọn (1 đúng, 3 sai)
  state.quizQuestions = selectedPool.map(targetWord => {
    // Tìm các từ nhiễu
    const distractorCandidates = state.allWords.filter(w => w.word !== targetWord.word);
    const shuffledDistractors = shuffleArray(distractorCandidates).slice(0, 3);
    
    const optionText = word => questionMode === 'meaning' ? word.meaning : word.word;
    const options = shuffleArray([
      { text: optionText(targetWord), isCorrect: true },
      ...shuffledDistractors.map(d => ({ text: optionText(d), isCorrect: false }))
    ]);

    return {
      wordObj: targetWord,
      options: options,
      chosenOption: null,
      isCorrect: false,
      questionMode: questionMode
    };
  });

  state.quizCurrentIndex = 0;
  state.quizScore = 0;
  state.quizWrongAnswers = [];

  // Hiển thị màn hình làm bài
  elements.quizSetupView.classList.add('hidden');
  elements.quizResultView.classList.add('hidden');
  elements.quizActiveView.classList.remove('hidden');

  renderCurrentQuizQuestion();
}

function renderCurrentQuizQuestion() {
  clearInterval(state.quizTimerInterval);
  state.quizAnswerLocked = false;
  elements.quizInstantFeedback.style.display = 'none';
  elements.quizNextManualBtn.classList.add('hidden');

  const q = state.quizQuestions[state.quizCurrentIndex];
  const total = state.quizQuestions.length;

  elements.quizCurrentProgress.textContent = `Câu ${state.quizCurrentIndex + 1} / ${total}`;
  const isExampleQuestion = q.questionMode !== 'meaning';
  const example = isExampleQuestion ? getQuizExample(q.wordObj) : null;
  elements.quizQuestionPrompt.textContent = isExampleQuestion
    ? (q.questionMode === 'vi-cloze' ? 'Chọn từ tiếng Anh phù hợp để hoàn thành câu:' : 'Câu ví dụ tiếng Việt (hãy tìm từ được gạch chân):')
    : '';
  elements.quizQuestionWord.className = `quiz-question-word${isExampleQuestion ? ' example-sentence' : ''}`;
  elements.quizQuestionWord.innerHTML = isExampleQuestion
    ? renderVietnameseQuizSentence(example ? example.vi : q.wordObj.meaning, q.wordObj.meaning, q.questionMode === 'vi-cloze')
    : escapeHtml(q.wordObj.word);
  elements.quizQuestionIpa.textContent = q.wordObj.ipa;
  elements.quizQuestionType.textContent = q.wordObj.type;
  elements.quizQuestionType.className = `type-tag ${getTypeBadgeClass(q.wordObj.type)}`;

  elements.quizQuestionAudioBtn.onclick = () => speakWord(q.wordObj.word);

  // Render 4 options
  elements.quizOptionsGrid.innerHTML = q.options.map((opt, idx) => `
    <button class="quiz-opt-btn" data-index="${idx}" onclick="handleSelectOption(${idx})">
      <span><strong>${String.fromCharCode(65 + idx)}.</strong> ${escapeHtml(opt.text)}</span>
    </button>
  `).join('');

  // Setup Timer
  const timeLimit = state.quizConfig.perQuestionTime;
  if (timeLimit > 0) {
    state.quizTimeLeft = timeLimit;
    elements.quizTimerBadge.classList.remove('hidden', 'urgent');
    elements.quizTimeRemaining.textContent = `${state.quizTimeLeft}s`;
    elements.quizTimerBar.style.width = '100%';

    state.quizTimerInterval = setInterval(() => {
      state.quizTimeLeft--;
      elements.quizTimeRemaining.textContent = `${state.quizTimeLeft}s`;
      const pct = (state.quizTimeLeft / timeLimit) * 100;
      elements.quizTimerBar.style.width = `${pct}%`;

      if (state.quizTimeLeft <= 3) {
        elements.quizTimerBadge.classList.add('urgent');
      }

      if (state.quizTimeLeft <= 0) {
        clearInterval(state.quizTimerInterval);
        handleTimeout();
      }
    }, 1000);
  } else {
    elements.quizTimerBadge.classList.add('hidden');
    elements.quizTimerBar.style.width = '100%';
  }
}

function handleSelectOption(selectedIndex) {
  if (state.quizAnswerLocked) return;
  state.quizAnswerLocked = true;
  clearInterval(state.quizTimerInterval);

  const q = state.quizQuestions[state.quizCurrentIndex];
  const selectedOpt = q.options[selectedIndex];
  q.chosenOption = selectedOpt;
  q.isCorrect = selectedOpt.isCorrect;

  if (q.isCorrect) {
    state.quizScore++;
  } else {
    state.quizWrongAnswers.push(q);
  }

  // Highlight buttons (đúng màu xanh lá, sai màu đỏ)
  const buttons = elements.quizOptionsGrid.querySelectorAll('.quiz-opt-btn');
  buttons.forEach((btn, idx) => {
    btn.disabled = true;
    if (q.options[idx].isCorrect) {
      btn.classList.add('correct');
    }
    if (idx === selectedIndex && !q.options[idx].isCorrect) {
      btn.classList.add('wrong');
    }
  });

  // Hiển thị phản hồi tức thời & 2 câu ví dụ để người học kịp xem lỗi sai trong thời gian nghỉ
  showInstantFeedback(q);
}

function handleTimeout() {
  if (state.quizAnswerLocked) return;
  state.quizAnswerLocked = true;

  const q = state.quizQuestions[state.quizCurrentIndex];
  q.chosenOption = { text: 'Hết thời gian (Không chọn)', isCorrect: false };
  q.isCorrect = false;
  state.quizWrongAnswers.push(q);

  const buttons = elements.quizOptionsGrid.querySelectorAll('.quiz-opt-btn');
  buttons.forEach((btn, idx) => {
    btn.disabled = true;
    if (q.options[idx].isCorrect) {
      btn.classList.add('correct');
    }
  });

  showInstantFeedback(q, true);
}

function getMeaningVariants(meaning) {
  return String(meaning || '')
    .split(/[,;/]/)
    .map(value => value.replace(/\([^)]*\)/g, '').trim())
    .filter(value => value.length > 1)
    .sort((a, b) => b.length - a.length);
}

function getQuizExample(wordObj) {
  const examples = getExamplesForWord(wordObj.word, wordObj.type, wordObj.meaning);
  return examples.find(example => {
    const vi = String(example.vi || '').toLocaleLowerCase();
    return getMeaningVariants(wordObj.meaning).some(variant => vi.includes(variant.toLocaleLowerCase()));
  }) || examples[0] || { vi: wordObj.meaning };
}

function renderVietnameseQuizSentence(sentence, meaning, isCloze) {
  const source = String(sentence || '');
  const variant = getMeaningVariants(meaning).find(item =>
    source.toLocaleLowerCase().includes(item.toLocaleLowerCase())
  );
  if (!variant) return escapeHtml(source);

  const start = source.toLocaleLowerCase().indexOf(variant.toLocaleLowerCase());
  const before = source.slice(0, start);
  const matched = source.slice(start, start + variant.length);
  const after = source.slice(start + variant.length);
  const replacement = isCloze
    ? '<span class="quiz-cloze-blank">________</span>'
    : `<u class="quiz-highlighted-vi">${escapeHtml(matched)}</u>`;
  return `${escapeHtml(before)}${replacement}${escapeHtml(after)}`;
}

function showInstantFeedback(q, isTimeout = false) {
  const examples = getExamplesForWord(q.wordObj.word, q.wordObj.type, q.wordObj.meaning);
  elements.quizInstantFeedback.style.display = 'block';

  if (q.isCorrect) {
    elements.quizFeedbackTitle.className = 'quiz-feedback-title correct';
    elements.quizFeedbackTitle.innerHTML = '<span>✅ Chính xác!</span>';
  } else {
    elements.quizFeedbackTitle.className = 'quiz-feedback-title wrong';
    elements.quizFeedbackTitle.innerHTML = isTimeout 
      ? '<span>⏰ Đã hết thời gian! Đáp án đúng:</span>' 
      : '<span>❌ Rất tiếc, chưa đúng! Đáp án đúng:</span>';
  }

  elements.quizFeedbackMeaning.textContent = `${q.wordObj.word} (${q.wordObj.type}): ${q.wordObj.meaning}`;
  elements.quizFeedbackExamples.innerHTML = `
    <div style="font-weight: 600; color: var(--text-muted); margin-bottom: 4px;">2 Ví dụ thực tế:</div>
    ${examples.map(ex => `<div>• <strong>${escapeHtml(ex.en)}</strong> - ${escapeHtml(ex.vi)}</div>`).join('')}
  `;

  // Xử lý thời gian nghỉ trước khi qua câu kế tiếp
  const pauseSetting = state.quizConfig.pauseTime;
  if (pauseSetting === 'manual') {
    elements.quizNextManualBtn.classList.remove('hidden');
    elements.quizNextManualBtn.onclick = () => advanceToNextQuizQuestion();
  } else {
    const pauseMs = pauseSetting * 1000;
    setTimeout(() => {
      advanceToNextQuizQuestion();
    }, pauseMs);
  }
}

function advanceToNextQuizQuestion() {
  state.quizCurrentIndex++;
  if (state.quizCurrentIndex < state.quizQuestions.length) {
    renderCurrentQuizQuestion();
  } else {
    showQuizResults();
  }
}

function showQuizResults() {
  elements.quizActiveView.classList.add('hidden');
  elements.quizResultView.classList.remove('hidden');

  const total = state.quizQuestions.length;
  const score = state.quizScore;
  const pct = Math.round((score / total) * 100);

  elements.resultScoreLarge.textContent = `${score} / ${total}`;
  elements.resultScoreSub.textContent = `Tỷ lệ chính xác: ${pct}% • Bạn đã nắm vững kiến thức!`;

  // Render danh sách câu sai
  const wrongList = state.quizWrongAnswers;
  elements.wrongCount.textContent = wrongList.length;

  if (wrongList.length === 0) {
    elements.wrongAnswersSection.style.display = 'none';
  } else {
    elements.wrongAnswersSection.style.display = 'block';
    elements.wrongListContainer.innerHTML = wrongList.map((item, idx) => {
      const examples = getExamplesForWord(item.wordObj.word, item.wordObj.type, item.wordObj.meaning);
      return `
        <div class="wrong-card">
          <div class="wrong-card-top">
            <span class="wrong-term">${idx + 1}. ${escapeHtml(item.wordObj.word)} <span style="font-size: 0.9rem; font-weight: normal; color: var(--accent);">${escapeHtml(item.wordObj.ipa)}</span></span>
            <span class="type-tag ${getTypeBadgeClass(item.wordObj.type)}">${escapeHtml(item.wordObj.type)}</span>
          </div>

          <div class="wrong-answer-row">
            ❌ Lựa chọn của bạn: <span class="chosen-wrong">${escapeHtml(item.chosenOption ? item.chosenOption.text : 'Bỏ qua')}</span>
          </div>
          <div class="wrong-answer-row">
            ✅ Đáp án đúng: <span class="correct-choice">${escapeHtml(item.questionMode === 'meaning' ? item.wordObj.meaning : item.wordObj.word)}</span>
          </div>

          <div class="examples-box" style="margin-top: 10px;">
            <div class="examples-box-title">💬 2 Ví dụ thực tế dễ nhớ:</div>
            ${examples.map(ex => `
              <div class="example-item">
                <div class="example-en">• ${escapeHtml(ex.en)}</div>
                <div class="example-vi">${escapeHtml(ex.vi)}</div>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    }).join('');
  }
}

/* ==========================================================================
   EVENT LISTENERS & TAB ROUTING
   ========================================================================== */

function setupEventListeners() {
  // Theme Toggle
  elements.themeToggleBtn.addEventListener('click', toggleTheme);

  // Tab Switching
  [elements.tabBtnList, elements.tabBtnFlashcard, elements.tabBtnQuiz].forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.dataset.tab;
      switchTab(targetTab);
    });
  });

  // Search input with debounce
  let searchTimeout;
  elements.searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      state.searchQuery = e.target.value;
      applyFilters();
    }, 250);
  });

  // Status Filter Chips
  elements.statusFilterChips.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      elements.statusFilterChips.querySelectorAll('.chip-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.selectedStatus = btn.dataset.status;
      applyFilters();
    });
  });

  // Type Filter Chips (Multi-Select Support)
  elements.typeFilterChips.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const typeVal = btn.dataset.type;

      if (typeVal === 'all') {
        state.selectedTypes.clear();
        state.selectedTypes.add('all');
        elements.typeFilterChips.querySelectorAll('.chip-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      } else {
        // Bỏ 'all' nếu đang chọn loại cụ thể
        state.selectedTypes.delete('all');
        const allBtn = elements.typeFilterChips.querySelector('[data-type="all"]');
        if (allBtn) allBtn.classList.remove('active');

        if (state.selectedTypes.has(typeVal)) {
          state.selectedTypes.delete(typeVal);
          btn.classList.remove('active');
        } else {
          state.selectedTypes.add(typeVal);
          btn.classList.add('active');
        }

        // Nếu bỏ chọn hết thì tự động về 'all'
        if (state.selectedTypes.size === 0) {
          state.selectedTypes.add('all');
          if (allBtn) allBtn.classList.add('active');
        }
      }

      applyFilters();
    });
  });

  // Reset Filters Button
  elements.btnResetFilters.addEventListener('click', () => {
    state.searchQuery = '';
    elements.searchInput.value = '';
    
    state.selectedStatus = 'all';
    elements.statusFilterChips.querySelectorAll('.chip-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.status === 'all');
    });

    state.selectedTypes.clear();
    state.selectedTypes.add('all');
    elements.typeFilterChips.querySelectorAll('.chip-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.type === 'all');
    });

    applyFilters();
  });

  // Flashcard Interactivity
  elements.flashcardElement.addEventListener('click', flipFlashcard);
  elements.fcBtnPrev.addEventListener('click', (e) => {
    e.stopPropagation();
    prevFlashcard();
  });
  elements.fcBtnNext.addEventListener('click', (e) => {
    e.stopPropagation();
    nextFlashcard();
  });
  elements.fcBtnToggleLearn.addEventListener('click', (e) => {
    e.stopPropagation();
    if (state.filteredWords.length > 0) {
      const currentWord = state.filteredWords[state.fcIndex].word;
      toggleWordLearned(currentWord);
    }
  });

  // Keyboard Navigation for Flashcards
  window.addEventListener('keydown', (e) => {
    if (state.currentTab === 'flashcard' && document.activeElement !== elements.searchInput) {
      if (e.code === 'Space') {
        e.preventDefault();
        flipFlashcard();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        nextFlashcard();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        prevFlashcard();
      }
    }
  });

  // Quiz Events
  elements.btnStartQuiz.addEventListener('click', startQuiz);
  elements.btnRetryQuiz.addEventListener('click', startQuiz);
  elements.btnBackToSetup.addEventListener('click', () => {
    elements.quizResultView.classList.add('hidden');
    elements.quizActiveView.classList.add('hidden');
    elements.quizSetupView.classList.remove('hidden');
  });
}

function switchTab(tabName) {
  state.currentTab = tabName;

  // Active Buttons
  elements.tabBtnList.classList.toggle('active', tabName === 'list');
  elements.tabBtnFlashcard.classList.toggle('active', tabName === 'flashcard');
  elements.tabBtnQuiz.classList.toggle('active', tabName === 'quiz');

  // Show/Hide Panes
  elements.tabContentList.classList.toggle('hidden', tabName !== 'list');
  elements.tabContentFlashcard.classList.toggle('hidden', tabName !== 'flashcard');
  elements.tabContentQuiz.classList.toggle('hidden', tabName !== 'quiz');

  // Filter Bar chỉ hiển thị khi ở tab Danh sách hoặc Flashcard
  if (tabName === 'quiz') {
    elements.filtersSection.classList.add('hidden');
  } else {
    elements.filtersSection.classList.remove('hidden');
  }

  // Smooth scroll up
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* ==========================================================================
   HELPERS
   ========================================================================== */

function shuffleArray(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function escapeSingleQuote(str) {
  if (!str) return '';
  return String(str).replace(/'/g, "\\'");
}

// Chạy ứng dụng khi DOM sẵn sàng
document.addEventListener('DOMContentLoaded', initApp);
