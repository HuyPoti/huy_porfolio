/**
 * Examples Data & Engine for TOEIC Vocabulary
 * Cung cấp 2 câu ví dụ ngắn gọn, thực tế, ĐA DẠNG NGỮ CẢNH (không rập khuôn) cho từng từ vựng.
 */

// Danh mục các ví dụ biên soạn phong phú theo nhiều chủ đề TOEIC
/** Examples imported from TOEIC_2026_vocabulary_3_vi_du.csv */
/** Examples imported from TOEIC_2026_vocabulary_with_examples.csv */
const curatedExamples = {
  "A majority of": [
    {"en":"We should consider \u0027a majority of\u0027 when planning our marketing budget for next year.","vi":"Chúng ta nên xem xét \u0027đa số, phần lớn\u0027 khi lập kế hoạch ngân sách tiếp thị cho năm tới."}
  ],
  "A variety of": [
    {"en":"The director mentioned \u0027a variety of\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027đa dạng\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Aboard": [
    {"en":"The team completed the task aboard despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách trên tàu, trên xe mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Abrasive": [
    {"en":"His feedback on the project was remarkably abrasive and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng có tính mài mòn, thô ráp và mang tính xây dựng."}
  ],
  "Abstract": [
    {"en":"Please ensure that the client receives a abstract response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời trừu tượng trong vòng 24 giờ."}
  ],
  "Abundance": [
    {"en":"The client expressed great interest in our strategy for abundance.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự phong phú, dồi dào."}
  ],
  "Abundant": [
    {"en":"Our team achieved abundant progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển dồi dào, phong phú sau khi áp dụng quy trình làm việc mới."}
  ],
  "Accept": [
    {"en":"Could you help me accept these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi chấp nhận những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Acceptable": [
    {"en":"The newly designed office environment is very acceptable for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất chấp nhận được cho sức khỏe của nhân viên."}
  ],
  "Access": [
    {"en":"We need to access closely with our partners to finalize the deal.","vi":"Chúng ta cần sự truy cập / truy cập chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Accidentally": [
    {"en":"The team completed the task accidentally despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách tình cờ, ngẫu nhiên mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Accommodate": [
    {"en":"We plan to accommodate the new guidelines across all regional offices.","vi":"Chúng tôi dự định đáp ứng, cung cấp chỗ ở các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Accordingly": [
    {"en":"The team completed the task accordingly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách phù hợp, theo đó mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Account": [
    {"en":"Having a clear understand of account is essential for this project.","vi":"Hiểu rõ về tài khoản là điều cần thiết cho dự án này."}
  ],
  "Accountant": [
    {"en":"Please send all relevant documents related to the accountant by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến kế toán viên trước thứ Sáu."}
  ],
  "Accounting": [
    {"en":"The client expressed great interest in our strategy for accounting.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với kế toán."}
  ],
  "Accurate": [
    {"en":"Our team achieved accurate progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển chính xác sau khi áp dụng quy trình làm việc mới."}
  ],
  "Accurately": [
    {"en":"Please double-check the figures accurately to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách chính xác để tránh các sai sót về ngân sách."}
  ],
  "Achieve": [
    {"en":"It is critical that we achieve all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải đạt được tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Achievement": [
    {"en":"The executive team will discuss the proposed achievement during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về thành tựu được đề xuất trong cuộc họp ngày mai."}
  ],
  "Acquire": [
    {"en":"Please make sure to acquire all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn đạt được, thâu tóm mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Acquisition": [
    {"en":"The management decided to focus on improving our acquisition this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự giành được, sự thâu tóm (công ty) của chúng ta trong quý này."}
  ],
  "Act": [
    {"en":"Did you have a chance to act the quarterly report yet?","vi":"Bạn đã có cơ hội diễn xuất, hành động báo cáo hàng quý chưa?"}
  ],
  "Activate": [
    {"en":"The supervisor asked us to activate the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi kích hoạt cho cả đội về những cập nhật mới nhất."}
  ],
  "Addition": [
    {"en":"Please send all relevant documents related to the addition by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự thêm vào, bổ sung trước thứ Sáu."}
  ],
  "Additional": [
    {"en":"The market demand remains highly additional during this period of the year.","vi":"Nhu cầu thị trường vẫn rất thêm vào, bổ sung trong khoảng thời gian này của năm."}
  ],
  "Address": [
    {"en":"They intend to address the project schedule to accommodate client requests.","vi":"Họ có ý định giải quyết, xử lý (vấn đề) lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Adequate": [
    {"en":"Make sure that all adequate details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đầy đủ, thỏa đáng đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Adhere": [
    {"en":"It is critical that we adhere all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải dính chặt, tuân thủ tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Adjoining": [
    {"en":"They hired a adjoining specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia kế bên, liền kề để giám sát việc chuyển đổi hệ thống."}
  ],
  "Adjournment": [
    {"en":"We are currently reviewing the updated policies regarding adjournment.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự hoãn lại, bế mạc (cuộc họp)."}
  ],
  "Adjust": [
    {"en":"We plan to adjust the new guidelines across all regional offices.","vi":"Chúng tôi dự định điều chỉnh các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Adjustable": [
    {"en":"We are looking for a adjustable approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp có thể điều chỉnh để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Adjustment": [
    {"en":"Having a clear understand of adjustment is essential for this project.","vi":"Hiểu rõ về sự điều chỉnh là điều cần thiết cho dự án này."}
  ],
  "Administer": [
    {"en":"Our team strives to administer high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực quản lý, thực thi các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Administration": [
    {"en":"The client expressed great interest in our strategy for administration.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự quản lý, chính quyền."}
  ],
  "Administrative": [
    {"en":"Our team achieved administrative progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển thuộc hành chính sau khi áp dụng quy trình làm việc mới."}
  ],
  "Administrator": [
    {"en":"Our team will host a seminar to address issues concerning administrator.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người quản lý, quản trị viên."}
  ],
  "Admire": [
    {"en":"It is critical that we admire all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải ngưỡng mộ, khâm phục tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Admission": [
    {"en":"The executive team will discuss the proposed admission during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự vào cửa, phí vào cửa được đề xuất trong cuộc họp ngày mai."}
  ],
  "Adopt": [
    {"en":"Please make sure to adopt all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn thông qua, áp dụng mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Advance": [
    {"en":"It is important to keep all official documentation advance and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức trước, sớm (ví dụ: đặt trước) và được sắp xếp gọn gàng."}
  ],
  "Advanced": [
    {"en":"We are looking for a advanced approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp tiên tiến, cao cấp để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Advancement": [
    {"en":"Having a clear understand of advancement is essential for this project.","vi":"Hiểu rõ về sự tiến bộ, thăng tiến là điều cần thiết cho dự án này."}
  ],
  "Advantage": [
    {"en":"Please send all relevant documents related to the advantage by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến lợi thế, ưu điểm trước thứ Sáu."}
  ],
  "Advertise": [
    {"en":"Don\u0027t hesitate to advertise if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại quảng cáo nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Advertisement": [
    {"en":"We noticed a significant change in the overall advertisement last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về quảng cáo trong tháng trước."}
  ],
  "Advertising": [
    {"en":"Our team will host a seminar to address issues concerning advertising.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến ngành quảng cáo, hoạt động quảng cáo."}
  ],
  "Aesthetic": [
    {"en":"The newly designed office environment is very aesthetic for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất thuộc về thẩm mỹ cho sức khỏe của nhân viên."}
  ],
  "Affect": [
    {"en":"We need to affect closely with our partners to finalize the deal.","vi":"Chúng ta cần ảnh hưởng, tác động chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Afford": [
    {"en":"Please make sure to afford all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn đủ khả năng chi trả mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Affordable": [
    {"en":"It is important to keep all official documentation affordable and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức giá cả phải chăng và được sắp xếp gọn gàng."}
  ],
  "Affordably": [
    {"en":"The team completed the task affordably despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách với giá phải chăng mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Agenda": [
    {"en":"Having a clear understand of agenda is essential for this project.","vi":"Hiểu rõ về chương trình nghị sự là điều cần thiết cho dự án này."}
  ],
  "Agree": [
    {"en":"Our team strives to agree high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực đồng ý các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Agreement": [
    {"en":"The client expressed great interest in our strategy for agreement.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với hợp đồng, thỏa thuận."}
  ],
  "Agriculture": [
    {"en":"We noticed a significant change in the overall agriculture last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về nông nghiệp trong tháng trước."}
  ],
  "Aim": [
    {"en":"Could you help me aim these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi nhắm tới, mục tiêu những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Alert": [
    {"en":"Ensure that all safety standards regarding the alert are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự báo động, cảnh báo đều được tuân thủ nghiêm ngặt."},
    {"en":"The executive team will discuss the proposed alert during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về cảnh báo, báo động được đề xuất trong cuộc họp ngày mai."}
  ],
  "Align": [
    {"en":"Please make sure to align all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn căn chỉnh, sắp hàng mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Allow": [
    {"en":"We plan to allow the new guidelines across all regional offices.","vi":"Chúng tôi dự định cho phép các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Alternate": [
    {"en":"We are looking for a alternate approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp xen kẽ, luân phiên, thay thế để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Alternative": [
    {"en":"Having a clear understand of alternative is essential for this project.","vi":"Hiểu rõ về sự thay thế, phương án khác là điều cần thiết cho dự án này."}
  ],
  "Amazement": [
    {"en":"Please send all relevant documents related to the amazement by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự ngạc nhiên trước thứ Sáu."}
  ],
  "Ambitious": [
    {"en":"The market demand remains highly ambitious during this period of the year.","vi":"Nhu cầu thị trường vẫn rất có tham vọng, đầy hoài bão trong khoảng thời gian này của năm."}
  ],
  "Amenity": [
    {"en":"We noticed a significant change in the overall amenity last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về tiện nghi trong tháng trước."}
  ],
  "Analysis": [
    {"en":"Our team will host a seminar to address issues concerning analysis.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự phân tích."}
  ],
  "Analyst": [
    {"en":"Ensure that all safety standards regarding the analyst are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về nhà phân tích đều được tuân thủ nghiêm ngặt."}
  ],
  "Analyze": [
    {"en":"We need to analyze closely with our partners to finalize the deal.","vi":"Chúng ta cần phân tích chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Ancient": [
    {"en":"The manager praised her for providing a very ancient solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất cổ đại cho vấn đề."}
  ],
  "Anecdote": [
    {"en":"The management decided to focus on improving our anecdote this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện giai thoại, chuyện vặt của chúng ta trong quý này."}
  ],
  "Anniversary": [
    {"en":"Could you provide more details about the anniversary mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về lễ kỷ niệm được đề cập trong email không?"}
  ],
  "Announcement": [
    {"en":"Having a clear understand of announcement is essential for this project.","vi":"Hiểu rõ về thông báo là điều cần thiết cho dự án này."}
  ],
  "Annual": [
    {"en":"Please ensure that the client receives a annual response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời hằng năm, thường niên trong vòng 24 giờ."}
  ],
  "Anticipate": [
    {"en":"Don\u0027t hesitate to anticipate if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại dự đoán, mong đợi nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Antique": [
    {"en":"We noticed a significant change in the overall antique last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về đồ cổ, vật xưa trong tháng trước."}
  ],
  "Apparel": [
    {"en":"Our team will host a seminar to address issues concerning apparel.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến y phục, quần áo."}
  ],
  "Appear": [
    {"en":"It is critical that we appear all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải xuất hiện tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Appearance": [
    {"en":"The executive team will discuss the proposed appearance during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự xuất hiện, vẻ bề ngoài được đề xuất trong cuộc họp ngày mai."}
  ],
  "Appendix": [
    {"en":"We are currently reviewing the updated policies regarding appendix.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến phụ lục."}
  ],
  "Appliance": [
    {"en":"The management decided to focus on improving our appliance this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện thiết bị, dụng cụ (thường là gia dụng) của chúng ta trong quý này."}
  ],
  "Applicant": [
    {"en":"Could you provide more details about the applicant mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về ứng viên được đề cập trong email không?"}
  ],
  "Application": [
    {"en":"Having a clear understand of application is essential for this project.","vi":"Hiểu rõ về đơn ứng tuyển, sự áp dụng là điều cần thiết cho dự án này."}
  ],
  "Apply": [
    {"en":"Our team strives to apply high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực áp dụng, nộp đơn các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Apply for": [
    {"en":"Don\u0027t hesitate to apply for if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại nộp đơn, ứng tuyển nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Appoint": [
    {"en":"They intend to appoint the project schedule to accommodate client requests.","vi":"Họ có ý định bổ nhiệm lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Appointment": [
    {"en":"Our team will host a seminar to address issues concerning appointment.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến cuộc hẹn, sự bổ nhiệm."}
  ],
  "Appreciate": [
    {"en":"It is critical that we appreciate all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải cảm kích, đánh giá cao tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Appreciative": [
    {"en":"They hired a appreciative specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia biết ơn, đánh giá cao để giám sát việc chuyển đổi hệ thống."}
  ],
  "Approach": [
    {"en":"Please make sure to approach all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn tiếp cận mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Appropriate": [
    {"en":"It is important to keep all official documentation appropriate and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức thích hợp và được sắp xếp gọn gàng."}
  ],
  "Approval": [
    {"en":"Could you provide more details about the approval mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự chấp thuận được đề cập trong email không?"}
  ],
  "Approve": [
    {"en":"The supervisor asked us to approve the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi phê duyệt, chấp thuận cho cả đội về những cập nhật mới nhất."}
  ],
  "Approximately": [
    {"en":"The team completed the task approximately despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách khoảng, xấp xỉ mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Architect": [
    {"en":"The client expressed great interest in our strategy for architect.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với kiến trúc sư."}
  ],
  "Architectural": [
    {"en":"Our team achieved architectural progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển thuộc về kiến trúc sau khi áp dụng quy trình làm việc mới."}
  ],
  "Architecture": [
    {"en":"Our team will host a seminar to address issues concerning architecture.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến kiến trúc."}
  ],
  "Archive": [
    {"en":"Ensure that all safety standards regarding the archive are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về kho lưu trữ, tài liệu lưu trữ đều được tuân thủ nghiêm ngặt."}
  ],
  "Argue": [
    {"en":"We need to argue closely with our partners to finalize the deal.","vi":"Chúng ta cần tranh luận, biện luận chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Argument": [
    {"en":"We are currently reviewing the updated policies regarding argument.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến lý lẽ, sự tranh luận."}
  ],
  "Arrange": [
    {"en":"We plan to arrange the new guidelines across all regional offices.","vi":"Chúng tôi dự định sắp xếp các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Arrangement": [
    {"en":"Could you provide more details about the arrangement mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự sắp xếp được đề cập trong email không?"}
  ],
  "Artificial": [
    {"en":"His feedback on the project was remarkably artificial and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng nhân tạo và mang tính xây dựng."}
  ],
  "Aspect": [
    {"en":"Please send all relevant documents related to the aspect by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến khía cạnh trước thứ Sáu."}
  ],
  "Aspiring": [
    {"en":"The market demand remains highly aspiring during this period of the year.","vi":"Nhu cầu thị trường vẫn rất có khát vọng, muốn trở thành trong khoảng thời gian này của năm."}
  ],
  "Assemble": [
    {"en":"They intend to assemble the project schedule to accommodate client requests.","vi":"Họ có ý định lắp ráp, tập hợp lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Assembly": [
    {"en":"Our team will host a seminar to address issues concerning assembly.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự lắp ráp."}
  ],
  "Assess": [
    {"en":"It is critical that we assess all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải đánh giá tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Asset": [
    {"en":"The executive team will discuss the proposed asset during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về tài sản, vốn quý được đề xuất trong cuộc họp ngày mai."}
  ],
  "Assign": [
    {"en":"Please make sure to assign all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn phân công, chỉ định mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Assignment": [
    {"en":"The management decided to focus on improving our assignment this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện nhiệm vụ, sự phân công của chúng ta trong quý này."}
  ],
  "Assist": [
    {"en":"Did you have a chance to assist the quarterly report yet?","vi":"Bạn đã có cơ hội hỗ trợ, giúp đỡ báo cáo hàng quý chưa?"}
  ],
  "Assistance": [
    {"en":"Having a clear understand of assistance is essential for this project.","vi":"Hiểu rõ về sự hỗ trợ là điều cần thiết cho dự án này."}
  ],
  "Assistant": [
    {"en":"Please send all relevant documents related to the assistant by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến trợ lý, phụ tá trước thứ Sáu."}
  ],
  "Associate": [
    {"en":"The client expressed great interest in our strategy for associate.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với cộng sự, nhân viên."}
  ],
  "Associated": [
    {"en":"Our team achieved associated progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển có liên quan, liên kết sau khi áp dụng quy trình làm việc mới."}
  ],
  "Assume": [
    {"en":"Could you help me assume these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi cho rằng, đảm nhận (trách nhiệm) những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Assure": [
    {"en":"It is critical that we assure all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải đảm bảo, cam đoan tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Astronaut": [
    {"en":"The executive team will discuss the proposed astronaut during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về phi hành gia được đề xuất trong cuộc họp ngày mai."}
  ],
  "Astronomy": [
    {"en":"We are currently reviewing the updated policies regarding astronomy.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thiên văn học."}
  ],
  "At no charge": [
    {"en":"The director mentioned \u0027at no charge\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027miễn phí\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Athlete": [
    {"en":"Could you provide more details about the athlete mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về vận động viên được đề cập trong email không?"}
  ],
  "Athletic": [
    {"en":"His feedback on the project was remarkably athletic and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thuộc về thể thao và mang tính xây dựng."}
  ],
  "Attempt": [
    {"en":"Our team strives to attempt high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực cố gắng các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Attend": [
    {"en":"Don\u0027t hesitate to attend if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại tham dự nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Attendance": [
    {"en":"We noticed a significant change in the overall attendance last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự tham dự, chuyên cần trong tháng trước."}
  ],
  "Attendant": [
    {"en":"Our team will host a seminar to address issues concerning attendant.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người phục vụ, tiếp viên."}
  ],
  "Attendee": [
    {"en":"Ensure that all safety standards regarding the attendee are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về người tham dự đều được tuân thủ nghiêm ngặt."},
    {"en":"The executive team will discuss the proposed attendee during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về người tham dự được đề xuất trong cuộc họp ngày mai."}
  ],
  "Attention": [
    {"en":"We are currently reviewing the updated policies regarding attention.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự chú ý."}
  ],
  "Attract": [
    {"en":"We plan to attract the new guidelines across all regional offices.","vi":"Chúng tôi dự định thu hút các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Attractive": [
    {"en":"We are looking for a attractive approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp hấp dẫn, thu hút để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Attune": [
    {"en":"The supervisor asked us to attune the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi làm cho hòa hợp cho cả đội về những cập nhật mới nhất."}
  ],
  "Auction": [
    {"en":"Please send all relevant documents related to the auction by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến cuộc đấu giá trước thứ Sáu."}
  ],
  "Audience": [
    {"en":"The client expressed great interest in our strategy for audience.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với khán giả, thính giả."}
  ],
  "Audiovisual": [
    {"en":"Our team achieved audiovisual progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển nghe nhìn sau khi áp dụng quy trình làm việc mới."}
  ],
  "Authentic": [
    {"en":"Make sure that all authentic details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đích thực, chính cống đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Author": [
    {"en":"Ensure that all safety standards regarding the author are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về tác giả đều được tuân thủ nghiêm ngặt."}
  ],
  "Authority": [
    {"en":"The executive team will discuss the proposed authority during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về thẩm quyền, nhà chức trách được đề xuất trong cuộc họp ngày mai."}
  ],
  "Authorize": [
    {"en":"Please make sure to authorize all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn ủy quyền, cho phép mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Automated": [
    {"en":"It is important to keep all official documentation automated and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức tự động hóa và được sắp xếp gọn gàng."}
  ],
  "Automotive": [
    {"en":"We are looking for a automotive approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thuộc về ô tô để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Autonomous": [
    {"en":"His feedback on the project was remarkably autonomous and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng tự trị, tự động và mang tính xây dựng."}
  ],
  "Availability": [
    {"en":"Please send all relevant documents related to the availability by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến khả năng đáp ứng, tính sẵn có trước thứ Sáu."}
  ],
  "Available": [
    {"en":"The market demand remains highly available during this period of the year.","vi":"Nhu cầu thị trường vẫn rất có sẵn, rảnh rỗi trong khoảng thời gian này của năm."}
  ],
  "Average": [
    {"en":"We noticed a significant change in the overall average last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về trung bình trong tháng trước."}
  ],
  "Avoid": [
    {"en":"Could you help me avoid these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi tránh những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Award-winning": [
    {"en":"The newly designed office environment is very award-winning for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất từng đoạt giải thưởng cho sức khỏe của nhân viên."}
  ],
  "Awareness": [
    {"en":"The executive team will discuss the proposed awareness during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về nhận thức được đề xuất trong cuộc họp ngày mai."}
  ],
  "Backdrop": [
    {"en":"We are currently reviewing the updated policies regarding backdrop.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến phông nền, bối cảnh."}
  ],
  "Banquet": [
    {"en":"The management decided to focus on improving our banquet this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện bữa tiệc lớn, yến tiệc của chúng ta trong quý này."}
  ],
  "Be supposed to": [
    {"en":"Did you have a chance to be supposed to the quarterly report yet?","vi":"Bạn đã có cơ hội được cho là, phải báo cáo hàng quý chưa?"}
  ],
  "Beautify": [
    {"en":"The supervisor asked us to beautify the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi làm đẹp, tô điểm cho cả đội về những cập nhật mới nhất."}
  ],
  "Belongings": [
    {"en":"Please send all relevant documents related to the belongings by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến đồ dùng cá nhân trước thứ Sáu."}
  ],
  "Benefit": [
    {"en":"Don\u0027t hesitate to benefit if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại có lợi nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Benefits": [
    {"en":"We noticed a significant change in the overall benefits last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về phúc lợi, lợi ích trong tháng trước."}
  ],
  "Beverage": [
    {"en":"Our team will host a seminar to address issues concerning beverage.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến đồ uống."}
  ],
  "Bid": [
    {"en":"Ensure that all safety standards regarding the bid are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự đấu thầu, giá thầu đều được tuân thủ nghiêm ngặt."}
  ],
  "Bill": [
    {"en":"The executive team will discuss the proposed bill during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về hóa đơn được đề xuất trong cuộc họp ngày mai."}
  ],
  "Bin": [
    {"en":"We are currently reviewing the updated policies regarding bin.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thùng chứa."}
  ],
  "Biographer": [
    {"en":"The management decided to focus on improving our biographer this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện người viết tiểu sử của chúng ta trong quý này."}
  ],
  "Biography": [
    {"en":"Could you provide more details about the biography mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tiểu sử được đề cập trong email không?"}
  ],
  "Biweekly": [
    {"en":"Please double-check the figures biweekly to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách hai tuần một lần để tránh các sai sót về ngân sách."}
  ],
  "Board": [
    {"en":"Our team strives to board high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực lên tàu, lên xe các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Boarding pass": [
    {"en":"The client expressed great interest in our strategy for boarding pass.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với thẻ lên máy bay."}
  ],
  "Bold": [
    {"en":"Our team achieved bold progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển táo bạo, dũng cảm, đậm (nét) sau khi áp dụng quy trình làm việc mới."}
  ],
  "Book": [
    {"en":"Could you help me book these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi đặt chỗ những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Bookkeeping": [
    {"en":"Ensure that all safety standards regarding the bookkeeping are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về công việc kế toán, ghi chép sổ sách đều được tuân thủ nghiêm ngặt."}
  ],
  "Border": [
    {"en":"We need to border closely with our partners to finalize the deal.","vi":"Chúng ta cần tiếp giáp, bao quanh chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Borrow": [
    {"en":"Please make sure to borrow all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn vay, mượn mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Botanical": [
    {"en":"It is important to keep all official documentation botanical and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức thuộc thực vật học và được sắp xếp gọn gàng."}
  ],
  "Boulevard": [
    {"en":"Could you provide more details about the boulevard mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về đại lộ được đề cập trong email không?"}
  ],
  "Branch": [
    {"en":"Having a clear understand of branch is essential for this project.","vi":"Hiểu rõ về chi nhánh là điều cần thiết cho dự án này."}
  ],
  "Breach": [
    {"en":"Please send all relevant documents related to the breach by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự vi phạm trước thứ Sáu."}
  ],
  "Breathtaking": [
    {"en":"The market demand remains highly breathtaking during this period of the year.","vi":"Nhu cầu thị trường vẫn rất ngoạn mục, hấp dẫn trong khoảng thời gian này của năm."}
  ],
  "Brief": [
    {"en":"Our team achieved brief progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển ngắn gọn sau khi áp dụng quy trình làm việc mới."}
  ],
  "Broadcast": [
    {"en":"Could you help me broadcast these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi phát sóng những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Brochure": [
    {"en":"Ensure that all safety standards regarding the brochure are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về tờ rơi, sách quảng cáo đều được tuân thủ nghiêm ngặt."}
  ],
  "Broken": [
    {"en":"They hired a broken specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia hỏng, vỡ để giám sát việc chuyển đổi hệ thống."}
  ],
  "Bucket": [
    {"en":"We are currently reviewing the updated policies regarding bucket.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến cái xô, thùng."}
  ],
  "Budget": [
    {"en":"The management decided to focus on improving our budget this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện ngân sách của chúng ta trong quý này."}
  ],
  "Bulk": [
    {"en":"Could you provide more details about the bulk mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về số lượng lớn được đề cập trong email không?"}
  ],
  "Bulletin board": [
    {"en":"Having a clear understand of bulletin board is essential for this project.","vi":"Hiểu rõ về bảng tin là điều cần thiết cho dự án này."}
  ],
  "Bustle": [
    {"en":"Please send all relevant documents related to the bustle by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự huyên náo, nhộn nhịp trước thứ Sáu."}
  ],
  "Bypass": [
    {"en":"Don\u0027t hesitate to bypass if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại đi vòng, bỏ qua nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."},
    {"en":"We noticed a significant change in the overall bypass last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về đường vòng trong tháng trước."}
  ],
  "Cabin": [
    {"en":"Our team will host a seminar to address issues concerning cabin.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến khoang (máy bay, tàu), nhà gỗ nhỏ."}
  ],
  "Cafeteria": [
    {"en":"Ensure that all safety standards regarding the cafeteria are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về quán ăn tự phục vụ đều được tuân thủ nghiêm ngặt."}
  ],
  "Calculate": [
    {"en":"We need to calculate closely with our partners to finalize the deal.","vi":"Chúng ta cần tính toán chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Candid": [
    {"en":"The manager praised her for providing a very candid solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất thẳng thắn, thật thà cho vấn đề."}
  ],
  "Candidate": [
    {"en":"The management decided to focus on improving our candidate this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện ứng viên của chúng ta trong quý này."}
  ],
  "Capability": [
    {"en":"Could you provide more details about the capability mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về khả năng, năng lực được đề cập trong email không?"}
  ],
  "Capacity": [
    {"en":"Having a clear understand of capacity is essential for this project.","vi":"Hiểu rõ về sức chứa, năng lực là điều cần thiết cho dự án này."}
  ],
  "Carry": [
    {"en":"Our team strives to carry high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực mang, vác, đem theo các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Catch up": [
    {"en":"Don\u0027t hesitate to catch up if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại bắt kịp nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Cater": [
    {"en":"They intend to cater the project schedule to accommodate client requests.","vi":"Họ có ý định cung cấp thực phẩm, phục vụ tiệc lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Caterer": [
    {"en":"Our team will host a seminar to address issues concerning caterer.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến nhà cung cấp dịch vụ ăn uống."}
  ],
  "Catering": [
    {"en":"Ensure that all safety standards regarding the catering are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về dịch vụ cung cấp đồ ăn đều được tuân thủ nghiêm ngặt."}
  ],
  "Cause": [
    {"en":"We need to cause closely with our partners to finalize the deal.","vi":"Chúng ta cần gây ra chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Caution": [
    {"en":"We are currently reviewing the updated policies regarding caution.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự thận trọng, cảnh báo."},
    {"en":"We plan to caution the new guidelines across all regional offices.","vi":"Chúng tôi dự định cảnh báo các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Ceiling": [
    {"en":"Could you provide more details about the ceiling mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về trần nhà được đề cập trong email không?"}
  ],
  "Celebrate": [
    {"en":"The supervisor asked us to celebrate the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi kỷ niệm, ăn mừng cho cả đội về những cập nhật mới nhất."}
  ],
  "Celebrity": [
    {"en":"Please send all relevant documents related to the celebrity by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến người nổi tiếng trước thứ Sáu."}
  ],
  "Cement": [
    {"en":"Don\u0027t hesitate to cement if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại củng cố, thắt chặt nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Certainly": [
    {"en":"The team completed the task certainly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách chắc chắn mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Certificate": [
    {"en":"Our team will host a seminar to address issues concerning certificate.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến giấy chứng nhận, chứng chỉ."}
  ],
  "Certification": [
    {"en":"Ensure that all safety standards regarding the certification are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về giấy chứng nhận đều được tuân thủ nghiêm ngặt."}
  ],
  "Certified": [
    {"en":"They hired a certified specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia được chứng nhận để giám sát việc chuyển đổi hệ thống."}
  ],
  "Challenge": [
    {"en":"We are currently reviewing the updated policies regarding challenge.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thử thách."}
  ],
  "Challenging": [
    {"en":"It is important to keep all official documentation challenging and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức đầy thách thức, khó khăn và được sắp xếp gọn gàng."}
  ],
  "Charge": [
    {"en":"Did you have a chance to charge the quarterly report yet?","vi":"Bạn đã có cơ hội tính phí, nạp báo cáo hàng quý chưa?"}
  ],
  "Charity": [
    {"en":"Having a clear understand of charity is essential for this project.","vi":"Hiểu rõ về tổ chức từ thiện là điều cần thiết cho dự án này."}
  ],
  "Chemistry": [
    {"en":"Please send all relevant documents related to the chemistry by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến hóa học trước thứ Sáu."}
  ],
  "Choreography": [
    {"en":"The client expressed great interest in our strategy for choreography.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với biên đạo múa, nghệ thuật múa."}
  ],
  "City hall": [
    {"en":"We noticed a significant change in the overall city hall last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về tòa thị chính trong tháng trước."}
  ],
  "Civilization": [
    {"en":"Our team will host a seminar to address issues concerning civilization.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến nền văn minh."}
  ],
  "Claim": [
    {"en":"It is critical that we claim all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải yêu cầu, đòi hỏi (quyền lợi) tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Clarify": [
    {"en":"We need to clarify closely with our partners to finalize the deal.","vi":"Chúng ta cần làm rõ chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Cleanliness": [
    {"en":"We are currently reviewing the updated policies regarding cleanliness.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự sạch sẽ."}
  ],
  "Climb": [
    {"en":"We plan to climb the new guidelines across all regional offices.","vi":"Chúng tôi dự định leo trèo các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Clinical": [
    {"en":"We are looking for a clinical approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thuộc lâm sàng để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Collaborate": [
    {"en":"The supervisor asked us to collaborate the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi hợp tác cho cả đội về những cập nhật mới nhất."}
  ],
  "Collaboration": [
    {"en":"Please send all relevant documents related to the collaboration by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự cộng tác trước thứ Sáu."}
  ],
  "Collapsible": [
    {"en":"The market demand remains highly collapsible during this period of the year.","vi":"Nhu cầu thị trường vẫn rất có thể gấp gọn trong khoảng thời gian này của năm."}
  ],
  "Colleague": [
    {"en":"We noticed a significant change in the overall colleague last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về đồng nghiệp trong tháng trước."}
  ],
  "Collection": [
    {"en":"Our team will host a seminar to address issues concerning collection.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến bộ sưu tập."}
  ],
  "Combine": [
    {"en":"It is critical that we combine all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải kết hợp tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Comfortable": [
    {"en":"They hired a comfortable specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia thoải mái để giám sát việc chuyển đổi hệ thống."}
  ],
  "Commence": [
    {"en":"Please make sure to commence all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn bắt đầu mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Commend": [
    {"en":"We plan to commend the new guidelines across all regional offices.","vi":"Chúng tôi dự định khen ngợi, ca ngợi các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Commensurate": [
    {"en":"We are looking for a commensurate approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp tương xứng để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Comment": [
    {"en":"Having a clear understand of comment is essential for this project.","vi":"Hiểu rõ về bình luận, ý kiến là điều cần thiết cho dự án này."}
  ],
  "Commercial": [
    {"en":"Please ensure that the client receives a commercial response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời thuộc thương mại trong vòng 24 giờ."},
    {"en":"The client expressed great interest in our strategy for commercial.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với quảng cáo (trên truyền hình/phát thanh)."}
  ],
  "Commission": [
    {"en":"They intend to commission the project schedule to accommodate client requests.","vi":"Họ có ý định ủy nhiệm, đặt làm lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Commissioner": [
    {"en":"Our team will host a seminar to address issues concerning commissioner.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến ủy viên."}
  ],
  "Commitment": [
    {"en":"Ensure that all safety standards regarding the commitment are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự cam kết, tận tụy đều được tuân thủ nghiêm ngặt."}
  ],
  "Committee": [
    {"en":"The executive team will discuss the proposed committee during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về ủy ban được đề xuất trong cuộc họp ngày mai."}
  ],
  "Commute": [
    {"en":"Please make sure to commute all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn đi làm, đi lại thường xuyên mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Commuter": [
    {"en":"The management decided to focus on improving our commuter this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện người đi làm xa (thường xuyên di chuyển) của chúng ta trong quý này."}
  ],
  "Compact": [
    {"en":"We are looking for a compact approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp gọn nhẹ, nhỏ gọn để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Compartment": [
    {"en":"Having a clear understand of compartment is essential for this project.","vi":"Hiểu rõ về ngăn chứa, khoang là điều cần thiết cho dự án này."}
  ],
  "Compatible": [
    {"en":"Please ensure that the client receives a compatible response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tương thích trong vòng 24 giờ."}
  ],
  "Compensate": [
    {"en":"Don\u0027t hesitate to compensate if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại đền bù, bồi thường nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Compete": [
    {"en":"They intend to compete the project schedule to accommodate client requests.","vi":"Họ có ý định cạnh tranh lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Competent": [
    {"en":"Make sure that all competent details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết có năng lực, thạo việc đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Competition": [
    {"en":"Ensure that all safety standards regarding the competition are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về cuộc thi, sự cạnh tranh đều được tuân thủ nghiêm ngặt."}
  ],
  "Competitive": [
    {"en":"They hired a competitive specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia có tính cạnh tranh để giám sát việc chuyển đổi hệ thống."}
  ],
  "Competitor": [
    {"en":"We are currently reviewing the updated policies regarding competitor.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến đối thủ cạnh tranh."}
  ],
  "Compile": [
    {"en":"We plan to compile the new guidelines across all regional offices.","vi":"Chúng tôi dự định biên soạn, tổng hợp các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Complain": [
    {"en":"Did you have a chance to complain the quarterly report yet?","vi":"Bạn đã có cơ hội phàn nàn, khiếu nại báo cáo hàng quý chưa?"}
  ],
  "Complaint": [
    {"en":"Having a clear understand of complaint is essential for this project.","vi":"Hiểu rõ về lời phàn nàn là điều cần thiết cho dự án này."}
  ],
  "Complete": [
    {"en":"Our team strives to complete high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực hoàn thành các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Completion": [
    {"en":"The client expressed great interest in our strategy for completion.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự hoàn thành."}
  ],
  "Compliance": [
    {"en":"We noticed a significant change in the overall compliance last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự tuân thủ trong tháng trước."}
  ],
  "Compliment": [
    {"en":"Our team will host a seminar to address issues concerning compliment.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến lời khen ngợi."}
  ],
  "Complimentary": [
    {"en":"The newly designed office environment is very complimentary for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất miễn phí cho sức khỏe của nhân viên."}
  ],
  "Comply with": [
    {"en":"We need to comply with closely with our partners to finalize the deal.","vi":"Chúng ta cần tuân thủ chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Component": [
    {"en":"We are currently reviewing the updated policies regarding component.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thành phần, linh kiện."}
  ],
  "Composer": [
    {"en":"The management decided to focus on improving our composer this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện nhà soạn nhạc, tác giả của chúng ta trong quý này."}
  ],
  "Comprehensive": [
    {"en":"We are looking for a comprehensive approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp toàn diện, bao quát để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Concern": [
    {"en":"Having a clear understand of concern is essential for this project.","vi":"Hiểu rõ về mối quan tâm, lo ngại là điều cần thiết cho dự án này."}
  ],
  "Concerned": [
    {"en":"Please ensure that the client receives a concerned response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời lo lắng, quan tâm trong vòng 24 giờ."}
  ],
  "Concrete": [
    {"en":"The client expressed great interest in our strategy for concrete.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với bê tông."}
  ],
  "Condition": [
    {"en":"We noticed a significant change in the overall condition last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về điều kiện, tình trạng trong tháng trước."}
  ],
  "Conduct": [
    {"en":"Could you help me conduct these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi tiến hành, thực hiện những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Confident": [
    {"en":"The newly designed office environment is very confident for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất tự tin cho sức khỏe của nhân viên."}
  ],
  "Confidential": [
    {"en":"They hired a confidential specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia bảo mật, kín để giám sát việc chuyển đổi hệ thống."}
  ],
  "Confidentiality": [
    {"en":"We are currently reviewing the updated policies regarding confidentiality.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự bảo mật."}
  ],
  "Confirm": [
    {"en":"We plan to confirm the new guidelines across all regional offices.","vi":"Chúng tôi dự định xác nhận các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Confirmation": [
    {"en":"Could you provide more details about the confirmation mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự xác nhận được đề cập trong email không?"}
  ],
  "Congested": [
    {"en":"His feedback on the project was remarkably congested and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng tắc nghẽn, đông nghịt và mang tính xây dựng."}
  ],
  "Connection": [
    {"en":"Please send all relevant documents related to the connection by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự kết nối trước thứ Sáu."}
  ],
  "Conservation": [
    {"en":"The client expressed great interest in our strategy for conservation.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự bảo tồn."}
  ],
  "Conserve": [
    {"en":"They intend to conserve the project schedule to accommodate client requests.","vi":"Họ có ý định bảo tồn, tiết kiệm lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Consider": [
    {"en":"Could you help me consider these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi cân nhắc, xem xét những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Consideration": [
    {"en":"Ensure that all safety standards regarding the consideration are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự cân nhắc, xem xét đều được tuân thủ nghiêm ngặt."}
  ],
  "Consignment": [
    {"en":"The executive team will discuss the proposed consignment during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về hàng ký gửi, lô hàng được đề xuất trong cuộc họp ngày mai."}
  ],
  "Consistently": [
    {"en":"The team completed the task consistently despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách nhất quán mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Constitute": [
    {"en":"We plan to constitute the new guidelines across all regional offices.","vi":"Chúng tôi dự định cấu thành, tạo nên các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Construction": [
    {"en":"Could you provide more details about the construction mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự xây dựng, công trình được đề cập trong email không?"}
  ],
  "Constructive": [
    {"en":"His feedback on the project was remarkably constructive and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng mang tính xây dựng và mang tính xây dựng."}
  ],
  "Consult": [
    {"en":"Our team strives to consult high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực tham khảo ý kiến, tư vấn các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Consumer": [
    {"en":"The client expressed great interest in our strategy for consumer.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với người tiêu dùng."}
  ],
  "Consumption": [
    {"en":"We noticed a significant change in the overall consumption last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự tiêu thụ trong tháng trước."}
  ],
  "Contain": [
    {"en":"Could you help me contain these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi chứa đựng những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Container": [
    {"en":"Ensure that all safety standards regarding the container are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về thùng chứa, đồ đựng đều được tuân thủ nghiêm ngặt."}
  ],
  "Contemporary": [
    {"en":"They hired a contemporary specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia đương đại để giám sát việc chuyển đổi hệ thống."}
  ],
  "Contract": [
    {"en":"We are currently reviewing the updated policies regarding contract.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến hợp đồng."}
  ],
  "Contribute": [
    {"en":"We plan to contribute the new guidelines across all regional offices.","vi":"Chúng tôi dự định đóng góp, góp phần các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Contribution": [
    {"en":"Could you provide more details about the contribution mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự đóng góp, bài đóng góp được đề cập trong email không?"}
  ],
  "Control": [
    {"en":"The supervisor asked us to control the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi kiểm soát, điều khiển cho cả đội về những cập nhật mới nhất."}
  ],
  "Convenient": [
    {"en":"Please ensure that the client receives a convenient response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tiện lợi, thuận tiện trong vòng 24 giờ."}
  ],
  "Conventional": [
    {"en":"The market demand remains highly conventional during this period of the year.","vi":"Nhu cầu thị trường vẫn rất thông thường, truyền thống trong khoảng thời gian này của năm."}
  ],
  "Convert": [
    {"en":"They intend to convert the project schedule to accommodate client requests.","vi":"Họ có ý định chuyển đổi lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Convey": [
    {"en":"Could you help me convey these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi truyền tải (suy nghĩ, cảm xúc, ý tưởng) những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Convince": [
    {"en":"It is critical that we convince all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải thuyết phục tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Convinced": [
    {"en":"They hired a convinced specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia tin chắc, bị thuyết phục để giám sát việc chuyển đổi hệ thống."}
  ],
  "Cookware": [
    {"en":"We are currently reviewing the updated policies regarding cookware.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến dụng cụ nấu ăn."}
  ],
  "Cooperation": [
    {"en":"The management decided to focus on improving our cooperation this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự hợp tác của chúng ta trong quý này."}
  ],
  "Coordinator": [
    {"en":"Could you provide more details about the coordinator mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về điều phối viên được đề cập trong email không?"}
  ],
  "Cordially": [
    {"en":"Please double-check the figures cordially to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách thân mật, chân thành để tránh các sai sót về ngân sách."}
  ],
  "Corporate": [
    {"en":"Please ensure that the client receives a corporate response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời thuộc về doanh nghiệp, công ty trong vòng 24 giờ."}
  ],
  "Corporation": [
    {"en":"The client expressed great interest in our strategy for corporation.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với tập đoàn, công ty kinh doanh."}
  ],
  "Correct": [
    {"en":"Our team achieved correct progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển chính xác, đúng sau khi áp dụng quy trình làm việc mới."}
  ],
  "Correction": [
    {"en":"Our team will host a seminar to address issues concerning correction.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự sửa chữa, hiệu chỉnh."}
  ],
  "Cost": [
    {"en":"It is critical that we cost all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tốn kém, trị giá tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Costly": [
    {"en":"They hired a costly specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia đắt đỏ, tốn kém để giám sát việc chuyển đổi hệ thống."}
  ],
  "Council": [
    {"en":"We are currently reviewing the updated policies regarding council.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến hội đồng."}
  ],
  "Courtesy": [
    {"en":"The management decided to focus on improving our courtesy this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự lịch sự, nhã nhặn của chúng ta trong quý này."}
  ],
  "Cover": [
    {"en":"Did you have a chance to cover the quarterly report yet?","vi":"Bạn đã có cơ hội đưa tin, bao phủ, chi trả báo cáo hàng quý chưa?"}
  ],
  "Cover letter": [
    {"en":"Having a clear understand of cover letter is essential for this project.","vi":"Hiểu rõ về thư xin việc là điều cần thiết cho dự án này."}
  ],
  "Covered": [
    {"en":"Please ensure that the client receives a covered response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời có mái che, được bao phủ trong vòng 24 giờ."}
  ],
  "Coworker": [
    {"en":"The client expressed great interest in our strategy for coworker.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với đồng nghiệp."}
  ],
  "Craft": [
    {"en":"We noticed a significant change in the overall craft last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về thủ công, nghề thủ công trong tháng trước."}
  ],
  "Crash": [
    {"en":"Could you help me crash these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi hỏng (máy tính), đâm sầm vào những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Creamery": [
    {"en":"Ensure that all safety standards regarding the creamery are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về cửa hàng bán các sản phẩm từ sữa đều được tuân thủ nghiêm ngặt."}
  ],
  "Crease": [
    {"en":"We need to crease closely with our partners to finalize the deal.","vi":"Chúng ta cần làm nhăn chặt chẽ với các đối tác để hoàn tất thương vụ."},
    {"en":"We are currently reviewing the updated policies regarding crease.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến nếp gấp."}
  ],
  "Create": [
    {"en":"We plan to create the new guidelines across all regional offices.","vi":"Chúng tôi dự định tạo ra các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Credential": [
    {"en":"Could you provide more details about the credential mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về chứng chỉ, bằng cấp được đề cập trong email không?"}
  ],
  "Credible": [
    {"en":"His feedback on the project was remarkably credible and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng đáng tin cậy và mang tính xây dựng."}
  ],
  "Crew": [
    {"en":"Please send all relevant documents related to the crew by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến đội, nhóm, phi hành đoàn trước thứ Sáu."}
  ],
  "Criteria": [
    {"en":"The client expressed great interest in our strategy for criteria.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với tiêu chí."}
  ],
  "Critic": [
    {"en":"We noticed a significant change in the overall critic last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về nhà phê bình trong tháng trước."}
  ],
  "Critical": [
    {"en":"Make sure that all critical details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết quan trọng, phê bình đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Criticism": [
    {"en":"Ensure that all safety standards regarding the criticism are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự phê bình, chỉ trích đều được tuân thủ nghiêm ngặt."}
  ],
  "Cross": [
    {"en":"We need to cross closely with our partners to finalize the deal.","vi":"Chúng ta cần băng qua, đi qua chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Crowded": [
    {"en":"The manager praised her for providing a very crowded solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất đông đúc cho vấn đề."}
  ],
  "Crucially": [
    {"en":"Please double-check the figures crucially to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách quyết định, quan trọng để tránh các sai sót về ngân sách."}
  ],
  "Cuisine": [
    {"en":"Could you provide more details about the cuisine mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về ẩm thực, cách nấu nướng được đề cập trong email không?"}
  ],
  "Culinary": [
    {"en":"His feedback on the project was remarkably culinary and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thuộc về ẩm thực và mang tính xây dựng."}
  ],
  "Cultivate": [
    {"en":"Our team strives to cultivate high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực trau dồi, canh tác các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Curate": [
    {"en":"Don\u0027t hesitate to curate if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại tuyển chọn, phụ trách nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Curious": [
    {"en":"Our team achieved curious progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển tò mò, hiếu kỳ sau khi áp dụng quy trình làm việc mới."}
  ],
  "Current": [
    {"en":"Make sure that all current details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết hiện tại đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Currently": [
    {"en":"The team completed the task currently despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách hiện tại mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Custodian": [
    {"en":"The executive team will discuss the proposed custodian during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về người trông coi, nhân viên tạp vụ được đề xuất trong cuộc họp ngày mai."}
  ],
  "Custom": [
    {"en":"The manager praised her for providing a very custom solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất tùy chỉnh, đặt làm riêng cho vấn đề."}
  ],
  "Customize": [
    {"en":"We plan to customize the new guidelines across all regional offices.","vi":"Chúng tôi dự định làm theo yêu cầu, tùy chỉnh các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Customized": [
    {"en":"We are looking for a customized approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp tùy chỉnh (theo yêu cầu) để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Damaged": [
    {"en":"His feedback on the project was remarkably damaged and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng bị hư hỏng và mang tính xây dựng."}
  ],
  "Day off": [
    {"en":"Please send all relevant documents related to the day off by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến ngày nghỉ trước thứ Sáu."}
  ],
  "Deactivation": [
    {"en":"The client expressed great interest in our strategy for deactivation.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự hủy kích hoạt, ngừng hoạt động."}
  ],
  "Deadline": [
    {"en":"We noticed a significant change in the overall deadline last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về hạn chót trong tháng trước."}
  ],
  "Deboard": [
    {"en":"Could you help me deboard these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi xuống (xe, tàu, máy bay) những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Decay": [
    {"en":"It is critical that we decay all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải suy tàn, mục nát tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Decision": [
    {"en":"The executive team will discuss the proposed decision during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về quyết định được đề xuất trong cuộc họp ngày mai."}
  ],
  "Decline": [
    {"en":"We are currently reviewing the updated policies regarding decline.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự sụt giảm."},
    {"en":"We plan to decline the new guidelines across all regional offices.","vi":"Chúng tôi dự định giảm, từ chối các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Decoration": [
    {"en":"Could you provide more details about the decoration mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự trang trí, đồ trang trí được đề cập trong email không?"}
  ],
  "Decorative": [
    {"en":"His feedback on the project was remarkably decorative and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng mang tính trang trí và mang tính xây dựng."}
  ],
  "Decrease": [
    {"en":"Our team strives to decrease high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực giảm xuống các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Dedicate": [
    {"en":"Don\u0027t hesitate to dedicate if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại cống hiến, dành cho nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Dedication": [
    {"en":"We noticed a significant change in the overall dedication last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự cống hiến trong tháng trước."}
  ],
  "Deduct": [
    {"en":"Could you help me deduct these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi khấu trừ những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Definitely": [
    {"en":"The team completed the task definitely despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách chắc chắn mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Definition": [
    {"en":"The executive team will discuss the proposed definition during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về định nghĩa được đề xuất trong cuộc họp ngày mai."}
  ],
  "Degree": [
    {"en":"We are currently reviewing the updated policies regarding degree.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến độ (nhiệt độ), bằng cấp."}
  ],
  "Delighted": [
    {"en":"It is important to keep all official documentation delighted and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức vui mừng, hài lòng và được sắp xếp gọn gàng."}
  ],
  "Demand": [
    {"en":"Could you provide more details about the demand mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về nhu cầu được đề cập trong email không?"}
  ],
  "Demolition": [
    {"en":"Having a clear understand of demolition is essential for this project.","vi":"Hiểu rõ về sự phá dỡ là điều cần thiết cho dự án này."}
  ],
  "Demonstrate": [
    {"en":"Our team strives to demonstrate high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực chứng minh, làm mẫu, trình bày các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Demonstration": [
    {"en":"The client expressed great interest in our strategy for demonstration.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự minh họa, cuộc biểu tình, sự thể hiện."}
  ],
  "Dentist": [
    {"en":"We noticed a significant change in the overall dentist last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về nha sĩ trong tháng trước."}
  ],
  "Depart": [
    {"en":"Could you help me depart these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi khởi hành những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Departure": [
    {"en":"Ensure that all safety standards regarding the departure are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự khởi hành đều được tuân thủ nghiêm ngặt."}
  ],
  "Depend on": [
    {"en":"We need to depend on closely with our partners to finalize the deal.","vi":"Chúng ta cần phụ thuộc vào chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Dependent": [
    {"en":"The manager praised her for providing a very dependent solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất phụ thuộc cho vấn đề."}
  ],
  "Deposit": [
    {"en":"The management decided to focus on improving our deposit this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện tiền đặt cọc của chúng ta trong quý này."}
  ],
  "Describe": [
    {"en":"Did you have a chance to describe the quarterly report yet?","vi":"Bạn đã có cơ hội mô tả báo cáo hàng quý chưa?"}
  ],
  "Description": [
    {"en":"Having a clear understand of description is essential for this project.","vi":"Hiểu rõ về sự mô tả là điều cần thiết cho dự án này."}
  ],
  "Deserve": [
    {"en":"Our team strives to deserve high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực xứng đáng các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Designated": [
    {"en":"The market demand remains highly designated during this period of the year.","vi":"Nhu cầu thị trường vẫn rất được chỉ định trong khoảng thời gian này của năm."}
  ],
  "Desperate": [
    {"en":"Our team achieved desperate progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển tuyệt vọng, liều lĩnh sau khi áp dụng quy trình làm việc mới."}
  ],
  "Destination": [
    {"en":"Our team will host a seminar to address issues concerning destination.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến điểm đến."}
  ],
  "Detach": [
    {"en":"It is critical that we detach all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tháo gỡ, tách ra tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Detailed": [
    {"en":"They hired a detailed specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia chi tiết, tỉ mỉ để giám sát việc chuyển đổi hệ thống."}
  ],
  "Details": [
    {"en":"We are currently reviewing the updated policies regarding details.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến chi tiết, thông tin cụ thể."}
  ],
  "Determine": [
    {"en":"We plan to determine the new guidelines across all regional offices.","vi":"Chúng tôi dự định xác định, quyết định các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Deterrence": [
    {"en":"Could you provide more details about the deterrence mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự ngăn chặn, răn đe được đề cập trong email không?"}
  ],
  "Develop": [
    {"en":"The supervisor asked us to develop the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi phát triển cho cả đội về những cập nhật mới nhất."}
  ],
  "Device": [
    {"en":"Please send all relevant documents related to the device by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến thiết bị trước thứ Sáu."}
  ],
  "Diagnose": [
    {"en":"Don\u0027t hesitate to diagnose if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại chẩn đoán nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Dimension": [
    {"en":"We noticed a significant change in the overall dimension last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về kích thước, chiều (không gian) trong tháng trước."}
  ],
  "Diplomat": [
    {"en":"Our team will host a seminar to address issues concerning diplomat.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến nhà ngoại giao."}
  ],
  "Direct": [
    {"en":"It is critical that we direct all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải hướng dẫn, chỉ đường tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Directions": [
    {"en":"The executive team will discuss the proposed directions during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về lời chỉ dẫn, phương hướng được đề xuất trong cuộc họp ngày mai."}
  ],
  "Directly": [
    {"en":"The team completed the task directly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách trực tiếp mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Directory": [
    {"en":"The management decided to focus on improving our directory this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện danh bạ, cẩm nang chỉ dẫn của chúng ta trong quý này."}
  ],
  "Disagree": [
    {"en":"Did you have a chance to disagree the quarterly report yet?","vi":"Bạn đã có cơ hội không đồng ý báo cáo hàng quý chưa?"}
  ],
  "Disappointment": [
    {"en":"Having a clear understand of disappointment is essential for this project.","vi":"Hiểu rõ về sự thất vọng là điều cần thiết cho dự án này."}
  ],
  "Discard": [
    {"en":"Our team strives to discard high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực loại bỏ, vứt bỏ các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Discarded": [
    {"en":"The market demand remains highly discarded during this period of the year.","vi":"Nhu cầu thị trường vẫn rất bị loại bỏ, vứt bỏ trong khoảng thời gian này của năm."}
  ],
  "Disclose": [
    {"en":"They intend to disclose the project schedule to accommodate client requests.","vi":"Họ có ý định tiết lộ, vạch trần lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Discontinue": [
    {"en":"Could you help me discontinue these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi ngừng, gián đoạn những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Discover": [
    {"en":"It is critical that we discover all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải khám phá, phát hiện tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Disease": [
    {"en":"The executive team will discuss the proposed disease during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về bệnh tật được đề xuất trong cuộc họp ngày mai."}
  ],
  "Dismantle": [
    {"en":"Please make sure to dismantle all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn tháo dỡ mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Displeasure": [
    {"en":"The management decided to focus on improving our displeasure this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự không hài lòng, khó chịu của chúng ta trong quý này."}
  ],
  "Disposable": [
    {"en":"We are looking for a disposable approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp dùng một lần để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Disposal": [
    {"en":"Having a clear understand of disposal is essential for this project.","vi":"Hiểu rõ về sự xử lý, vứt bỏ là điều cần thiết cho dự án này."}
  ],
  "Disruption": [
    {"en":"Please send all relevant documents related to the disruption by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự gián đoạn trước thứ Sáu."},
    {"en":"The client expressed great interest in our strategy for disruption.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự gián đoạn."}
  ],
  "Distance": [
    {"en":"We noticed a significant change in the overall distance last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về khoảng cách trong tháng trước."}
  ],
  "Distinctive": [
    {"en":"Make sure that all distinctive details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đặc biệt, dễ phân biệt đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Distracting": [
    {"en":"The newly designed office environment is very distracting for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất gây xao nhãng, mất tập trung cho sức khỏe của nhân viên."}
  ],
  "Distribute": [
    {"en":"We need to distribute closely with our partners to finalize the deal.","vi":"Chúng ta cần phân phối chặt chẽ với các đối tác để hoàn tất thương vụ."},
    {"en":"Please make sure to distribute all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn phân phối mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Distribution": [
    {"en":"The management decided to focus on improving our distribution this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự phân phối của chúng ta trong quý này."}
  ],
  "Distributor": [
    {"en":"Could you provide more details about the distributor mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về nhà phân phối được đề cập trong email không?"}
  ],
  "District": [
    {"en":"Having a clear understand of district is essential for this project.","vi":"Hiểu rõ về quận, khu vực là điều cần thiết cho dự án này."}
  ],
  "Diverse": [
    {"en":"Please ensure that the client receives a diverse response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời đa dạng trong vòng 24 giờ."}
  ],
  "Dock": [
    {"en":"Don\u0027t hesitate to dock if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại cập bến nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Domestic": [
    {"en":"Our team achieved domestic progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển nội địa, trong nước sau khi áp dụng quy trình làm việc mới."}
  ],
  "Donate": [
    {"en":"Could you help me donate these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi quyên góp những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Donation": [
    {"en":"Ensure that all safety standards regarding the donation are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự quyên góp đều được tuân thủ nghiêm ngặt."}
  ],
  "Doorway": [
    {"en":"The executive team will discuss the proposed doorway during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về cửa ra vào được đề xuất trong cuộc họp ngày mai."}
  ],
  "Doubt": [
    {"en":"Please make sure to doubt all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn nghi ngờ mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Doubtful": [
    {"en":"It is important to keep all official documentation doubtful and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức nghi ngờ và được sắp xếp gọn gàng."}
  ],
  "Downtown": [
    {"en":"The team completed the task downtown despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách thuộc khu trung tâm, ở trung tâm thành phố mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Draft": [
    {"en":"Having a clear understand of draft is essential for this project.","vi":"Hiểu rõ về bản thảo là điều cần thiết cho dự án này."}
  ],
  "Drastically": [
    {"en":"The team completed the task drastically despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách mạnh mẽ, quyết liệt mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Drawing": [
    {"en":"The client expressed great interest in our strategy for drawing.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với lễ bốc thăm trúng thưởng."}
  ],
  "Drop": [
    {"en":"They intend to drop the project schedule to accommodate client requests.","vi":"Họ có ý định rơi, giảm sụt lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Due": [
    {"en":"Make sure that all due details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đến hạn đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Durability": [
    {"en":"Ensure that all safety standards regarding the durability are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về độ bền đều được tuân thủ nghiêm ngặt."}
  ],
  "Durable": [
    {"en":"They hired a durable specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia bền, lâu bền để giám sát việc chuyển đổi hệ thống."}
  ],
  "Dynamic": [
    {"en":"The manager praised her for providing a very dynamic solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất năng động cho vấn đề."}
  ],
  "Eager": [
    {"en":"It is important to keep all official documentation eager and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức háo hức, thiết tha và được sắp xếp gọn gàng."}
  ],
  "Earmark": [
    {"en":"Did you have a chance to earmark the quarterly report yet?","vi":"Bạn đã có cơ hội dành riêng (ngân sách) cho mục đích cụ thể báo cáo hàng quý chưa?"}
  ],
  "Easygoing": [
    {"en":"His feedback on the project was remarkably easygoing and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng dễ tính, thoải mái và mang tính xây dựng."}
  ],
  "Eclectic": [
    {"en":"Please ensure that the client receives a eclectic response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời đa dạng, chiết trung (pha trộn nhiều phong cách) trong vòng 24 giờ."}
  ],
  "Edit": [
    {"en":"Don\u0027t hesitate to edit if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại biên tập, chỉnh sửa nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Editorial": [
    {"en":"Our team achieved editorial progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển thuộc biên tập sau khi áp dụng quy trình làm việc mới."}
  ],
  "Effective": [
    {"en":"Make sure that all effective details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết hiệu quả đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Efficiently": [
    {"en":"The team completed the task efficiently despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách hiệu quả mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Elaborate": [
    {"en":"They hired a elaborate specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia tỉ mỉ, công phu, phức tạp để giám sát việc chuyển đổi hệ thống."}
  ],
  "Elect": [
    {"en":"Please make sure to elect all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn bầu cử mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Electronically": [
    {"en":"Please double-check the figures electronically to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách bằng điện tử, qua mạng để tránh các sai sót về ngân sách."}
  ],
  "Electronics": [
    {"en":"Could you provide more details about the electronics mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về thiết bị điện tử được đề cập trong email không?"}
  ],
  "Eligible": [
    {"en":"His feedback on the project was remarkably eligible and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng đủ tư cách, đủ điều kiện và mang tính xây dựng."}
  ],
  "Eliminate": [
    {"en":"Our team strives to eliminate high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực loại bỏ các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Embrace": [
    {"en":"Don\u0027t hesitate to embrace if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại đón nhận, ôm nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Emphasize": [
    {"en":"They intend to emphasize the project schedule to accommodate client requests.","vi":"Họ có ý định nhấn mạnh lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Empty": [
    {"en":"Could you help me empty these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi làm trống, đổ (rác) những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Enable": [
    {"en":"It is critical that we enable all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải cho phép, làm cho có thể tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Enchanted": [
    {"en":"They hired a enchanted specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia bị mê hoặc, như bị bỏ bùa để giám sát việc chuyển đổi hệ thống."}
  ],
  "Enclose": [
    {"en":"Please make sure to enclose all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn đính kèm, gửi kèm mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Encourage": [
    {"en":"We plan to encourage the new guidelines across all regional offices.","vi":"Chúng tôi dự định khuyến khích, động viên các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Encouragement": [
    {"en":"Could you provide more details about the encouragement mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự khích lệ được đề cập trong email không?"}
  ],
  "Encyclopaedia": [
    {"en":"Having a clear understand of encyclopaedia is essential for this project.","vi":"Hiểu rõ về bách khoa toàn thư là điều cần thiết cho dự án này."}
  ],
  "Endeavour": [
    {"en":"Please send all relevant documents related to the endeavour by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự nỗ lực, cố gắng trước thứ Sáu."}
  ],
  "Engaging": [
    {"en":"The market demand remains highly engaging during this period of the year.","vi":"Nhu cầu thị trường vẫn rất lôi cuốn, hấp dẫn trong khoảng thời gian này của năm."}
  ],
  "Enhance": [
    {"en":"They intend to enhance the project schedule to accommodate client requests.","vi":"Họ có ý định nâng cao, tăng cường lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Enigmatic": [
    {"en":"Make sure that all enigmatic details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết bí ẩn, khó hiểu đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Enlarge": [
    {"en":"It is critical that we enlarge all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải mở rộng, phóng to tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Enquiry": [
    {"en":"The executive team will discuss the proposed enquiry during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự hỏi, điều tra (giống inquiry) được đề xuất trong cuộc họp ngày mai."}
  ],
  "Enroll in": [
    {"en":"Please make sure to enroll in all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn ghi danh, đăng ký vào mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Enrollment": [
    {"en":"The management decided to focus on improving our enrollment this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự ghi danh, đăng ký nhập học của chúng ta trong quý này."}
  ],
  "Ensure": [
    {"en":"Did you have a chance to ensure the quarterly report yet?","vi":"Bạn đã có cơ hội đảm bảo báo cáo hàng quý chưa?"}
  ],
  "Enter": [
    {"en":"The supervisor asked us to enter the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi tham gia (cuộc thi), đi vào cho cả đội về những cập nhật mới nhất."}
  ],
  "Enthusiasm": [
    {"en":"Please send all relevant documents related to the enthusiasm by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự nhiệt tình trước thứ Sáu."}
  ],
  "Entire": [
    {"en":"The market demand remains highly entire during this period of the year.","vi":"Nhu cầu thị trường vẫn rất toàn bộ trong khoảng thời gian này của năm."}
  ],
  "Entirely": [
    {"en":"The team completed the task entirely despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách hoàn toàn mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Entrance": [
    {"en":"Our team will host a seminar to address issues concerning entrance.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến lối vào."}
  ],
  "Entrepreneur": [
    {"en":"Ensure that all safety standards regarding the entrepreneur are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về doanh nhân đều được tuân thủ nghiêm ngặt."}
  ],
  "Entrust": [
    {"en":"We need to entrust closely with our partners to finalize the deal.","vi":"Chúng ta cần giao phó, ủy thác chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Episode": [
    {"en":"We are currently reviewing the updated policies regarding episode.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến tập (phim, chương trình)."}
  ],
  "Equipment": [
    {"en":"The management decided to focus on improving our equipment this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện thiết bị, dụng cụ của chúng ta trong quý này."}
  ],
  "Ergonomic": [
    {"en":"We are looking for a ergonomic approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thuộc về công thái học (thiết kế tối ưu cho con người) để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Essential": [
    {"en":"His feedback on the project was remarkably essential and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thiết yếu, quan trọng và mang tính xây dựng."}
  ],
  "Establish": [
    {"en":"Our team strives to establish high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực thành lập, thiết lập các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Estimate": [
    {"en":"Don\u0027t hesitate to estimate if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại ước tính, báo giá nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Evaluate": [
    {"en":"They intend to evaluate the project schedule to accommodate client requests.","vi":"Họ có ý định đánh giá lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Eventually": [
    {"en":"Please double-check the figures eventually to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách cuối cùng, rốt cuộc để tránh các sai sót về ngân sách."}
  ],
  "Exceed": [
    {"en":"It is critical that we exceed all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải vượt quá tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Excel": [
    {"en":"We need to excel closely with our partners to finalize the deal.","vi":"Chúng ta cần xuất sắc, vượt trội chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Exceptional": [
    {"en":"The manager praised her for providing a very exceptional solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất xuất sắc, đặc biệt cho vấn đề."}
  ],
  "Exceptionally": [
    {"en":"Please double-check the figures exceptionally to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách xuất chúng, khác thường để tránh các sai sót về ngân sách."}
  ],
  "Exchange": [
    {"en":"Did you have a chance to exchange the quarterly report yet?","vi":"Bạn đã có cơ hội trao đổi báo cáo hàng quý chưa?"}
  ],
  "Exclusive": [
    {"en":"His feedback on the project was remarkably exclusive and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng độc quyền và mang tính xây dựng."}
  ],
  "Exclusively": [
    {"en":"The team completed the task exclusively despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách dành riêng, độc quyền mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Excursion": [
    {"en":"The client expressed great interest in our strategy for excursion.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với chuyến tham quan, dã ngoại."}
  ],
  "Excuse": [
    {"en":"We noticed a significant change in the overall excuse last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về lời bào chữa, lý do trong tháng trước."}
  ],
  "Executive": [
    {"en":"Our team will host a seminar to address issues concerning executive.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến ủy viên ban quản trị, giám đốc điều hành."}
  ],
  "Exercise": [
    {"en":"Ensure that all safety standards regarding the exercise are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về bài tập, sự rèn luyện đều được tuân thủ nghiêm ngặt."}
  ],
  "Exhibit": [
    {"en":"The executive team will discuss the proposed exhibit during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về vật trưng bày, triển lãm được đề xuất trong cuộc họp ngày mai."}
  ],
  "Exit": [
    {"en":"Please make sure to exit all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn thoát ra, đi ra mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Expand": [
    {"en":"We plan to expand the new guidelines across all regional offices.","vi":"Chúng tôi dự định mở rộng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Expansion": [
    {"en":"Could you provide more details about the expansion mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự mở rộng được đề cập trong email không?"}
  ],
  "Expedite": [
    {"en":"The supervisor asked us to expedite the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi xúc tiến, đẩy nhanh cho cả đội về những cập nhật mới nhất."}
  ],
  "Expedition": [
    {"en":"Please send all relevant documents related to the expedition by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến cuộc thám hiểm trước thứ Sáu."}
  ],
  "Expenditure": [
    {"en":"The client expressed great interest in our strategy for expenditure.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với chi phí, sự tiêu dùng."}
  ],
  "Expense": [
    {"en":"We noticed a significant change in the overall expense last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về chi phí trong tháng trước."}
  ],
  "Experiment": [
    {"en":"Our team will host a seminar to address issues concerning experiment.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến cuộc thí nghiệm."}
  ],
  "Expert": [
    {"en":"Ensure that all safety standards regarding the expert are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về chuyên gia đều được tuân thủ nghiêm ngặt."}
  ],
  "Expertise": [
    {"en":"The executive team will discuss the proposed expertise during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về chuyên môn, kiến thức chuyên sâu được đề xuất trong cuộc họp ngày mai."}
  ],
  "Expire": [
    {"en":"Please make sure to expire all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn hết hạn mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Expired": [
    {"en":"It is important to keep all official documentation expired and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức hết hạn và được sắp xếp gọn gàng."}
  ],
  "Explain": [
    {"en":"Did you have a chance to explain the quarterly report yet?","vi":"Bạn đã có cơ hội giải thích báo cáo hàng quý chưa?"}
  ],
  "Exploit": [
    {"en":"The supervisor asked us to exploit the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi khai thác, tận dụng cho cả đội về những cập nhật mới nhất."}
  ],
  "Exploration": [
    {"en":"Please send all relevant documents related to the exploration by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự thám hiểm trước thứ Sáu."}
  ],
  "Explore": [
    {"en":"Don\u0027t hesitate to explore if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại khám phá, thăm dò nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Exposure": [
    {"en":"We noticed a significant change in the overall exposure last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự phơi bày, sự tiếp xúc trong tháng trước."}
  ],
  "Express": [
    {"en":"Make sure that all express details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết tốc hành, nhanh đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Extend": [
    {"en":"It is critical that we extend all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải kéo dài, gia hạn, mở rộng tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Extension": [
    {"en":"The executive team will discuss the proposed extension during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự mở rộng, máy nhánh (điện thoại) được đề xuất trong cuộc họp ngày mai."}
  ],
  "Extensive": [
    {"en":"The manager praised her for providing a very extensive solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất quảng đại, bao quát, chuyên sâu cho vấn đề."}
  ],
  "Extensively": [
    {"en":"Please double-check the figures extensively to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách rộng rãi, bao quát để tránh các sai sót về ngân sách."}
  ],
  "Exterior": [
    {"en":"We are looking for a exterior approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp bên ngoài để xử lý khối lượng công việc đang tăng lên."},
    {"en":"Having a clear understand of exterior is essential for this project.","vi":"Hiểu rõ về ngoại thất là điều cần thiết cho dự án này."}
  ],
  "Extra": [
    {"en":"Please ensure that the client receives a extra response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời thêm, phụ trong vòng 24 giờ."}
  ],
  "Extract": [
    {"en":"The client expressed great interest in our strategy for extract.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với chiết xuất, đoạn trích."}
  ],
  "Extremely": [
    {"en":"The team completed the task extremely despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách vô cùng, cực độ mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Fabric": [
    {"en":"Our team will host a seminar to address issues concerning fabric.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến vải vóc."}
  ],
  "Face": [
    {"en":"It is critical that we face all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải đối mặt, hướng về tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Facilitate": [
    {"en":"We need to facilitate closely with our partners to finalize the deal.","vi":"Chúng ta cần tạo điều kiện, làm cho dễ dàng chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Facility": [
    {"en":"We are currently reviewing the updated policies regarding facility.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến cơ sở vật chất."}
  ],
  "Factor": [
    {"en":"The management decided to focus on improving our factor this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện nhân tố, yếu tố của chúng ta trong quý này."}
  ],
  "Fade": [
    {"en":"Did you have a chance to fade the quarterly report yet?","vi":"Bạn đã có cơ hội phai màu, mờ dần báo cáo hàng quý chưa?"}
  ],
  "Fair": [
    {"en":"Having a clear understand of fair is essential for this project.","vi":"Hiểu rõ về hội chợ là điều cần thiết cho dự án này."}
  ],
  "Fairly": [
    {"en":"The team completed the task fairly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách khá là, tương đối mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Fancy": [
    {"en":"The market demand remains highly fancy during this period of the year.","vi":"Nhu cầu thị trường vẫn rất thích / sang trọng, cầu kỳ trong khoảng thời gian này của năm."}
  ],
  "Fascinating": [
    {"en":"Our team achieved fascinating progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển hấp dẫn, lôi cuốn sau khi áp dụng quy trình làm việc mới."}
  ],
  "Fasten": [
    {"en":"Could you help me fasten these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi thắt, buộc chặt những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Fate": [
    {"en":"Ensure that all safety standards regarding the fate are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về định mệnh, số phận đều được tuân thủ nghiêm ngặt."}
  ],
  "Faulty": [
    {"en":"They hired a faulty specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia bị lỗi, hỏng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Favorable": [
    {"en":"The manager praised her for providing a very favorable solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất thuận lợi cho vấn đề."}
  ],
  "Feature": [
    {"en":"We plan to feature the new guidelines across all regional offices.","vi":"Chúng tôi dự định bao gồm, có tính năng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Fee": [
    {"en":"Could you provide more details about the fee mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về lệ phí được đề cập trong email không?"}
  ],
  "Feed": [
    {"en":"The supervisor asked us to feed the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi cho ăn cho cả đội về những cập nhật mới nhất."}
  ],
  "Feedback": [
    {"en":"Please send all relevant documents related to the feedback by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến phản hồi, ý kiến trước thứ Sáu."}
  ],
  "Fertilizer": [
    {"en":"The client expressed great interest in our strategy for fertilizer.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với phân bón."}
  ],
  "Fictional": [
    {"en":"Our team achieved fictional progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển hư cấu sau khi áp dụng quy trình làm việc mới."}
  ],
  "Figure": [
    {"en":"Our team will host a seminar to address issues concerning figure.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến số liệu, con số."}
  ],
  "Figure out": [
    {"en":"It is critical that we figure out all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tìm ra, hiểu ra tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Fill": [
    {"en":"We need to fill closely with our partners to finalize the deal.","vi":"Chúng ta cần lấp đầy, điền vào chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Finalize": [
    {"en":"Please make sure to finalize all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn hoàn tất, thông qua lần cuối mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Finance": [
    {"en":"The management decided to focus on improving our finance this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện tài chính của chúng ta trong quý này."}
  ],
  "Financial": [
    {"en":"We are looking for a financial approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thuộc tài chính để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Firm": [
    {"en":"His feedback on the project was remarkably firm and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng cứng, chắc chắn và mang tính xây dựng."}
  ],
  "First aid": [
    {"en":"Please send all relevant documents related to the first aid by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sơ cứu trước thứ Sáu."}
  ],
  "Fit": [
    {"en":"Don\u0027t hesitate to fit if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại vừa vặn, phù hợp nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Fix": [
    {"en":"They intend to fix the project schedule to accommodate client requests.","vi":"Họ có ý định sửa chữa, khắc phục lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Flat rate": [
    {"en":"Our team will host a seminar to address issues concerning flat rate.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến mức phí cố định."}
  ],
  "Flavor": [
    {"en":"Ensure that all safety standards regarding the flavor are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về hương vị đều được tuân thủ nghiêm ngặt."}
  ],
  "Flavour": [
    {"en":"The executive team will discuss the proposed flavour during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về hương vị được đề xuất trong cuộc họp ngày mai."}
  ],
  "Flavourful": [
    {"en":"The manager praised her for providing a very flavourful solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất đậm đà hương vị cho vấn đề."}
  ],
  "Flock to": [
    {"en":"We plan to flock to the new guidelines across all regional offices.","vi":"Chúng tôi dự định đổ xô đến, tụ tập các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Floor plan": [
    {"en":"Could you provide more details about the floor plan mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sơ đồ mặt bằng được đề cập trong email không?"}
  ],
  "Flourishing": [
    {"en":"His feedback on the project was remarkably flourishing and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng hưng thịnh, phát triển mạnh và mang tính xây dựng."}
  ],
  "Flowerpot": [
    {"en":"Please send all relevant documents related to the flowerpot by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến chậu hoa trước thứ Sáu."}
  ],
  "Fluctuation": [
    {"en":"The client expressed great interest in our strategy for fluctuation.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự biến động."}
  ],
  "Fluency": [
    {"en":"We noticed a significant change in the overall fluency last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự lưu loát, trôi chảy trong tháng trước."}
  ],
  "Flyer": [
    {"en":"Our team will host a seminar to address issues concerning flyer.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến tờ rơi."}
  ],
  "Focus": [
    {"en":"Ensure that all safety standards regarding the focus are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về trọng tâm, tiêu điểm đều được tuân thủ nghiêm ngặt."}
  ],
  "Focus on": [
    {"en":"We need to focus on closely with our partners to finalize the deal.","vi":"Chúng ta cần tập trung vào chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Forecast": [
    {"en":"We are currently reviewing the updated policies regarding forecast.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến dự báo."}
  ],
  "Forefront": [
    {"en":"The management decided to focus on improving our forefront this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện hàng đầu, đi đầu của chúng ta trong quý này."}
  ],
  "Form": [
    {"en":"Could you provide more details about the form mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về mẫu đơn, hình thức được đề cập trong email không?"}
  ],
  "Formal": [
    {"en":"His feedback on the project was remarkably formal and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng trang trọng, chính thức và mang tính xây dựng."}
  ],
  "Former": [
    {"en":"Please ensure that the client receives a former response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời cựu, trước đây trong vòng 24 giờ."}
  ],
  "Forthcoming": [
    {"en":"The market demand remains highly forthcoming during this period of the year.","vi":"Nhu cầu thị trường vẫn rất sắp tới trong khoảng thời gian này của năm."}
  ],
  "Forward": [
    {"en":"They intend to forward the project schedule to accommodate client requests.","vi":"Họ có ý định chuyển tiếp lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Foster": [
    {"en":"Could you help me foster these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi thúc đẩy, nuôi dưỡng những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Found": [
    {"en":"It is critical that we found all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải thành lập tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Founder": [
    {"en":"The executive team will discuss the proposed founder during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về người sáng lập được đề xuất trong cuộc họp ngày mai."}
  ],
  "Frame": [
    {"en":"We are currently reviewing the updated policies regarding frame.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến khung (ảnh, cửa)."}
  ],
  "Freezing": [
    {"en":"It is important to keep all official documentation freezing and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức lạnh giá, đóng băng và được sắp xếp gọn gàng."}
  ],
  "Freight": [
    {"en":"Could you provide more details about the freight mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về hàng hóa chuyên chở được đề cập trong email không?"}
  ],
  "Frequent": [
    {"en":"His feedback on the project was remarkably frequent and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thường xuyên và mang tính xây dựng."}
  ],
  "Frequently": [
    {"en":"The team completed the task frequently despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách thường xuyên mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Fulfill": [
    {"en":"Don\u0027t hesitate to fulfill if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại hoàn thành, đáp ứng nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Fulfillment": [
    {"en":"We noticed a significant change in the overall fulfillment last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự hoàn thành, đáp ứng trong tháng trước."}
  ],
  "Function": [
    {"en":"Our team will host a seminar to address issues concerning function.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến chức năng."}
  ],
  "Functional": [
    {"en":"The newly designed office environment is very functional for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất thiết thực, hoạt động tốt cho sức khỏe của nhân viên."}
  ],
  "Functionality": [
    {"en":"The executive team will discuss the proposed functionality during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về tính năng, công dụng được đề xuất trong cuộc họp ngày mai."}
  ],
  "Fund-raising": [
    {"en":"We are currently reviewing the updated policies regarding fund-raising.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến gây quỹ."}
  ],
  "Fundamental": [
    {"en":"It is important to keep all official documentation fundamental and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức cơ bản, nền tảng và được sắp xếp gọn gàng."}
  ],
  "Funding": [
    {"en":"Could you provide more details about the funding mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về kinh phí, nguồn quỹ được đề cập trong email không?"}
  ],
  "Garage": [
    {"en":"Having a clear understand of garage is essential for this project.","vi":"Hiểu rõ về nhà để xe, gara là điều cần thiết cho dự án này."}
  ],
  "Garment": [
    {"en":"Please send all relevant documents related to the garment by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến quần áo, y phục trước thứ Sáu."}
  ],
  "Gathering": [
    {"en":"The client expressed great interest in our strategy for gathering.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với buổi tụ họp, cuộc gặp mặt."}
  ],
  "Gauge": [
    {"en":"They intend to gauge the project schedule to accommodate client requests.","vi":"Họ có ý định đo lường, đánh giá lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "General": [
    {"en":"Make sure that all general details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết chung, tổng quát đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Generate": [
    {"en":"It is critical that we generate all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tạo ra, phát sinh tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Geographic": [
    {"en":"They hired a geographic specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia thuộc về địa lý để giám sát việc chuyển đổi hệ thống."}
  ],
  "Get rid of": [
    {"en":"Please make sure to get rid of all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn loại bỏ mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Get the word out": [
    {"en":"We plan to get the word out the new guidelines across all regional offices.","vi":"Chúng tôi dự định loan tin, truyền tin các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Getaway": [
    {"en":"Could you provide more details about the getaway mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về chuyến đi nghỉ ngắn ngày được đề cập trong email không?"}
  ],
  "Glimpse": [
    {"en":"Having a clear understand of glimpse is essential for this project.","vi":"Hiểu rõ về cái nhìn thoáng qua là điều cần thiết cho dự án này."}
  ],
  "Go over": [
    {"en":"Our team strives to go over high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực xem xét kỹ, kiểm tra các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Go through": [
    {"en":"Don\u0027t hesitate to go through if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại kiểm tra, xem xét kỹ lưỡng nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Go toward": [
    {"en":"They intend to go toward the project schedule to accommodate client requests.","vi":"Họ có ý định được dùng cho, đóng góp vào lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Goods": [
    {"en":"Our team will host a seminar to address issues concerning goods.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến hàng hóa."}
  ],
  "Government": [
    {"en":"Ensure that all safety standards regarding the government are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về chính phủ đều được tuân thủ nghiêm ngặt."}
  ],
  "Grain": [
    {"en":"The executive team will discuss the proposed grain during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về ngũ cốc được đề xuất trong cuộc họp ngày mai."}
  ],
  "Grant": [
    {"en":"We are currently reviewing the updated policies regarding grant.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến khoản trợ cấp."}
  ],
  "Gratitude": [
    {"en":"The management decided to focus on improving our gratitude this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện lòng biết ơn của chúng ta trong quý này."}
  ],
  "Greet": [
    {"en":"Did you have a chance to greet the quarterly report yet?","vi":"Bạn đã có cơ hội chào đón báo cáo hàng quý chưa?"}
  ],
  "Groceries": [
    {"en":"Having a clear understand of groceries is essential for this project.","vi":"Hiểu rõ về hàng tạp hóa, thực phẩm là điều cần thiết cho dự án này."}
  ],
  "Guarantee": [
    {"en":"Please send all relevant documents related to the guarantee by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự bảo đảm trước thứ Sáu."},
    {"en":"Don\u0027t hesitate to guarantee if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại bảo đảm nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Guidance": [
    {"en":"We noticed a significant change in the overall guidance last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự hướng dẫn, chỉ đạo trong tháng trước."}
  ],
  "Guideline": [
    {"en":"Our team will host a seminar to address issues concerning guideline.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến hướng dẫn, chỉ đạo."}
  ],
  "Hand": [
    {"en":"It is critical that we hand all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải trao tay, đưa tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Handbook": [
    {"en":"The executive team will discuss the proposed handbook during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sổ tay hướng dẫn được đề xuất trong cuộc họp ngày mai."}
  ],
  "Handle": [
    {"en":"Please make sure to handle all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn xử lý, giải quyết mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Hands-on": [
    {"en":"It is important to keep all official documentation hands-on and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức thực tế, thực hành và được sắp xếp gọn gàng."}
  ],
  "Handy": [
    {"en":"We are looking for a handy approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp tiện dụng, hữu ích để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Hang": [
    {"en":"The supervisor asked us to hang the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi treo, mắc cho cả đội về những cập nhật mới nhất."}
  ],
  "Harmful": [
    {"en":"Please ensure that the client receives a harmful response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời có hại trong vòng 24 giờ."}
  ],
  "Harvest": [
    {"en":"The client expressed great interest in our strategy for harvest.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với vụ thu hoạch."}
  ],
  "Headquarter": [
    {"en":"They intend to headquarter the project schedule to accommodate client requests.","vi":"Họ có ý định đặt trụ sở chính lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Headquarters": [
    {"en":"Our team will host a seminar to address issues concerning headquarters.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến trụ sở chính."}
  ],
  "Hectic": [
    {"en":"The newly designed office environment is very hectic for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất bận rộn, cuồng nhiệt cho sức khỏe của nhân viên."}
  ],
  "Heritage": [
    {"en":"The executive team will discuss the proposed heritage during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về di sản được đề xuất trong cuộc họp ngày mai."}
  ],
  "Highlight": [
    {"en":"We are currently reviewing the updated policies regarding highlight.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến điểm nổi bật."},
    {"en":"We plan to highlight the new guidelines across all regional offices.","vi":"Chúng tôi dự định làm nổi bật các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Honor": [
    {"en":"Could you provide more details about the honor mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về danh dự, giải thưởng được đề cập trong email không?"}
  ],
  "Hospitality": [
    {"en":"Having a clear understand of hospitality is essential for this project.","vi":"Hiểu rõ về lòng mến khách, ngành dịch vụ khách sạn là điều cần thiết cho dự án này."}
  ],
  "Host": [
    {"en":"Our team strives to host high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực đăng cai, tổ chức các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Household": [
    {"en":"The client expressed great interest in our strategy for household.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với hộ gia đình."}
  ],
  "Hygienist": [
    {"en":"We noticed a significant change in the overall hygienist last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về chuyên viên vệ sinh (thường trong nha khoa) trong tháng trước."}
  ],
  "Iconic": [
    {"en":"Make sure that all iconic details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết mang tính biểu tượng đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Identification": [
    {"en":"Ensure that all safety standards regarding the identification are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về giấy tờ tùy thân, sự nhận dạng đều được tuân thủ nghiêm ngặt."}
  ],
  "Identify": [
    {"en":"We need to identify closely with our partners to finalize the deal.","vi":"Chúng ta cần nhận diện, xác định chặt chẽ với các đối tác để hoàn tất thương vụ."},
    {"en":"We are currently reviewing the updated policies regarding identify.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến danh tính."}
  ],
  "Ignore": [
    {"en":"We plan to ignore the new guidelines across all regional offices.","vi":"Chúng tôi dự định phớt lờ các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Illusion": [
    {"en":"Could you provide more details about the illusion mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về ảo giác, ảo tưởng được đề cập trong email không?"}
  ],
  "Illustrator": [
    {"en":"Having a clear understand of illustrator is essential for this project.","vi":"Hiểu rõ về họa sĩ minh họa là điều cần thiết cho dự án này."}
  ],
  "Immediate": [
    {"en":"Please ensure that the client receives a immediate response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời ngay lập tức trong vòng 24 giờ."}
  ],
  "Immediately": [
    {"en":"Please double-check the figures immediately to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách ngay lập tức để tránh các sai sót về ngân sách."}
  ],
  "Imminent": [
    {"en":"Our team achieved imminent progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển sắp xảy ra, lơ lửng sau khi áp dụng quy trình làm việc mới."}
  ],
  "Imperfection": [
    {"en":"Our team will host a seminar to address issues concerning imperfection.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự không hoàn hảo, khiếm khuyết."}
  ],
  "Implement": [
    {"en":"It is critical that we implement all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải thi hành, thực hiện tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Impressive": [
    {"en":"They hired a impressive specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia ấn tượng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Improve": [
    {"en":"Please make sure to improve all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn cải thiện, nâng cao mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Improvement": [
    {"en":"The management decided to focus on improving our improvement this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự cải thiện, nâng cấp của chúng ta trong quý này."}
  ],
  "In advance": [
    {"en":"We should consider \u0027in advance\u0027 when planning our marketing budget for next year.","vi":"Chúng ta nên xem xét \u0027trước (thời gian)\u0027 khi lập kế hoạch ngân sách tiếp thị cho năm tới."}
  ],
  "In celebration of": [
    {"en":"The director mentioned \u0027in celebration of\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027để kỷ niệm, nhân dịp\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "In charge of": [
    {"en":"We should consider \u0027in charge of\u0027 when planning our marketing budget for next year.","vi":"Chúng ta nên xem xét \u0027chịu trách nhiệm\u0027 khi lập kế hoạch ngân sách tiếp thị cho năm tới."}
  ],
  "In person": [
    {"en":"The director mentioned \u0027in person\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027trực tiếp, đích thân\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "In stock": [
    {"en":"We should consider \u0027in stock\u0027 when planning our marketing budget for next year.","vi":"Chúng ta nên xem xét \u0027còn hàng\u0027 khi lập kế hoạch ngân sách tiếp thị cho năm tới."}
  ],
  "In time": [
    {"en":"The director mentioned \u0027in time\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027kịp giờ, đúng lúc\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Inaccurate": [
    {"en":"The newly designed office environment is very inaccurate for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất không chính xác cho sức khỏe của nhân viên."}
  ],
  "Inadequate": [
    {"en":"They hired a inadequate specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia không thỏa đáng, thiếu để giám sát việc chuyển đổi hệ thống."}
  ],
  "Inappropriate": [
    {"en":"The manager praised her for providing a very inappropriate solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất không phù hợp cho vấn đề."}
  ],
  "Inaugural": [
    {"en":"It is important to keep all official documentation inaugural and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức khai trương, khánh thành, đầu tiên và được sắp xếp gọn gàng."}
  ],
  "Inclement weather": [
    {"en":"Could you provide more details about the inclement weather mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về thời tiết khắc nghiệt được đề cập trong email không?"}
  ],
  "Include": [
    {"en":"The supervisor asked us to include the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi bao gồm cho cả đội về những cập nhật mới nhất."}
  ],
  "Income": [
    {"en":"Please send all relevant documents related to the income by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến thu nhập trước thứ Sáu."}
  ],
  "Incomplete": [
    {"en":"The market demand remains highly incomplete during this period of the year.","vi":"Nhu cầu thị trường vẫn rất chưa hoàn thành, thiếu trong khoảng thời gian này của năm."}
  ],
  "Inconvenience": [
    {"en":"We noticed a significant change in the overall inconvenience last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự bất tiện trong tháng trước."}
  ],
  "Inconvenient": [
    {"en":"Make sure that all inconvenient details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết bất tiện đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Incorporate": [
    {"en":"It is critical that we incorporate all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải kết hợp, sáp nhập tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Incorrect": [
    {"en":"They hired a incorrect specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia không chính xác để giám sát việc chuyển đổi hệ thống."}
  ],
  "Increase": [
    {"en":"Please make sure to increase all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn tăng lên mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Incur": [
    {"en":"We plan to incur the new guidelines across all regional offices.","vi":"Chúng tôi dự định gánh chịu, phát sinh (chi phí, hậu quả) các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Indeed": [
    {"en":"The team completed the task indeed despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách thực sự, quả thực mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Indicate": [
    {"en":"The supervisor asked us to indicate the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi chỉ ra, biểu thị cho cả đội về những cập nhật mới nhất."}
  ],
  "Individual": [
    {"en":"Please send all relevant documents related to the individual by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến cá nhân/riêng lẻ (adj) trước thứ Sáu."}
  ],
  "Indoors": [
    {"en":"Please double-check the figures indoors to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách ở trong nhà để tránh các sai sót về ngân sách."}
  ],
  "Industrial": [
    {"en":"Our team achieved industrial progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển thuộc công nghiệp sau khi áp dụng quy trình làm việc mới."}
  ],
  "Inexpensive": [
    {"en":"Make sure that all inexpensive details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết không đắt, rẻ đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Inferior": [
    {"en":"The newly designed office environment is very inferior for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất thấp kém hơn, cấp dưới cho sức khỏe của nhân viên."}
  ],
  "Informal": [
    {"en":"They hired a informal specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia thân mật, không trang trọng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Information": [
    {"en":"We are currently reviewing the updated policies regarding information.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thông tin."}
  ],
  "Informational": [
    {"en":"It is important to keep all official documentation informational and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức cung cấp thông tin và được sắp xếp gọn gàng."}
  ],
  "Informative": [
    {"en":"We are looking for a informative approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp cung cấp nhiều tin tức, hữu ích để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Informed": [
    {"en":"His feedback on the project was remarkably informed and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng có hiểu biết, dựa trên thông tin và mang tính xây dựng."}
  ],
  "Infuse": [
    {"en":"Our team strives to infuse high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực truyền vào, ngấm vào các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Infusion": [
    {"en":"The client expressed great interest in our strategy for infusion.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự truyền vào, sự thêm vào."}
  ],
  "Ingredient": [
    {"en":"We noticed a significant change in the overall ingredient last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về nguyên liệu, thành phần trong tháng trước."}
  ],
  "Inherit": [
    {"en":"Could you help me inherit these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi thừa kế những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Initial": [
    {"en":"The newly designed office environment is very initial for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất ban đầu cho sức khỏe của nhân viên."}
  ],
  "Initially": [
    {"en":"Please double-check the figures initially to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách ban đầu để tránh các sai sót về ngân sách."}
  ],
  "Initiate": [
    {"en":"Please make sure to initiate all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn khởi xướng, bắt đầu mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Initiative": [
    {"en":"The management decided to focus on improving our initiative this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sáng kiến, kế hoạch mới của chúng ta trong quý này."}
  ],
  "Innovation": [
    {"en":"Could you provide more details about the innovation mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự đổi mới, sáng kiến được đề cập trong email không?"}
  ],
  "Innovative": [
    {"en":"His feedback on the project was remarkably innovative and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng có tính đổi mới, sáng tạo và mang tính xây dựng."}
  ],
  "Input": [
    {"en":"Please send all relevant documents related to the input by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến ý kiến đóng góp trước thứ Sáu."}
  ],
  "Inquire": [
    {"en":"Don\u0027t hesitate to inquire if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại hỏi thăm, tìm hiểu nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Inquiry": [
    {"en":"We noticed a significant change in the overall inquiry last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự thắc mắc, câu hỏi trong tháng trước."}
  ],
  "Insider": [
    {"en":"Our team will host a seminar to address issues concerning insider.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người nội bộ."}
  ],
  "Insight": [
    {"en":"Ensure that all safety standards regarding the insight are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự thấu hiểu, cái nhìn sâu sắc đều được tuân thủ nghiêm ngặt."}
  ],
  "Insightful": [
    {"en":"They hired a insightful specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia sâu sắc, đầy sự thấu hiểu để giám sát việc chuyển đổi hệ thống."}
  ],
  "Inspect": [
    {"en":"Please make sure to inspect all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn kiểm tra, thanh tra mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Inspection": [
    {"en":"The management decided to focus on improving our inspection this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự kiểm tra, thanh tra của chúng ta trong quý này."}
  ],
  "Inspector": [
    {"en":"Could you provide more details about the inspector mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về thanh tra viên được đề cập trong email không?"}
  ],
  "Inspiration": [
    {"en":"Having a clear understand of inspiration is essential for this project.","vi":"Hiểu rõ về cảm hứng là điều cần thiết cho dự án này."}
  ],
  "Inspiring": [
    {"en":"Please ensure that the client receives a inspiring response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời truyền cảm hứng trong vòng 24 giờ."}
  ],
  "Install": [
    {"en":"Don\u0027t hesitate to install if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại lắp đặt nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Installation": [
    {"en":"We noticed a significant change in the overall installation last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự lắp đặt trong tháng trước."}
  ],
  "Institute": [
    {"en":"Our team will host a seminar to address issues concerning institute.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến viện, học viện."}
  ],
  "Institution": [
    {"en":"Ensure that all safety standards regarding the institution are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về tổ chức, cơ quan đều được tuân thủ nghiêm ngặt."}
  ],
  "Instruction": [
    {"en":"The executive team will discuss the proposed instruction during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự hướng dẫn được đề xuất trong cuộc họp ngày mai."}
  ],
  "Instructions": [
    {"en":"We are currently reviewing the updated policies regarding instructions.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến hướng dẫn."}
  ],
  "Instructor": [
    {"en":"The management decided to focus on improving our instructor this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện người hướng dẫn, giảng viên của chúng ta trong quý này."}
  ],
  "Instrumental": [
    {"en":"We are looking for a instrumental approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thiết yếu, góp phần lớn để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Insufficient": [
    {"en":"His feedback on the project was remarkably insufficient and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng không đủ, thiếu và mang tính xây dựng."}
  ],
  "Insurance": [
    {"en":"Please send all relevant documents related to the insurance by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến bảo hiểm trước thứ Sáu."}
  ],
  "Integral": [
    {"en":"The market demand remains highly integral during this period of the year.","vi":"Nhu cầu thị trường vẫn rất không thể thiếu, trọn vẹn trong khoảng thời gian này của năm."}
  ],
  "Integrity": [
    {"en":"We noticed a significant change in the overall integrity last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự chính trực, tính toàn vẹn trong tháng trước."}
  ],
  "Intend": [
    {"en":"Could you help me intend these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi có ý định, dự định những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Intensive": [
    {"en":"The newly designed office environment is very intensive for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất tập trung, chuyên sâu cho sức khỏe của nhân viên."}
  ],
  "Intent": [
    {"en":"The executive team will discuss the proposed intent during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về ý định, mục đích được đề xuất trong cuộc họp ngày mai."}
  ],
  "Interact": [
    {"en":"Please make sure to interact all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn tương tác mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Intersection": [
    {"en":"The management decided to focus on improving our intersection this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện giao lộ, ngã tư của chúng ta trong quý này."}
  ],
  "Intricate": [
    {"en":"We are looking for a intricate approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp phức tạp, rắc rối để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Intrigue": [
    {"en":"The supervisor asked us to intrigue the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi gợi thích thú, hấp dẫn cho cả đội về những cập nhật mới nhất."}
  ],
  "Intrigued": [
    {"en":"Please ensure that the client receives a intrigued response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời hứng thú, tò mò trong vòng 24 giờ."}
  ],
  "Introduction": [
    {"en":"The client expressed great interest in our strategy for introduction.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự giới thiệu, lời mở đầu."}
  ],
  "Introductory": [
    {"en":"Our team achieved introductory progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển giới thiệu, mở đầu sau khi áp dụng quy trình làm việc mới."}
  ],
  "Invaluable": [
    {"en":"Make sure that all invaluable details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết vô giá đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Invention": [
    {"en":"Ensure that all safety standards regarding the invention are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về phát minh, sáng chế đều được tuân thủ nghiêm ngặt."}
  ],
  "Inventory": [
    {"en":"The executive team will discuss the proposed inventory during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về hàng tồn kho, sự kiểm kê được đề xuất trong cuộc họp ngày mai."}
  ],
  "Invest": [
    {"en":"Please make sure to invest all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn đầu tư mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Investment": [
    {"en":"The management decided to focus on improving our investment this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện khoản đầu tư, sự đầu tư của chúng ta trong quý này."}
  ],
  "Invitation": [
    {"en":"Could you provide more details about the invitation mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về lời mời được đề cập trong email không?"}
  ],
  "Inviting": [
    {"en":"His feedback on the project was remarkably inviting and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng lôi cuốn, hấp dẫn và mang tính xây dựng."}
  ],
  "Invoice": [
    {"en":"Please send all relevant documents related to the invoice by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến hóa đơn trước thứ Sáu."}
  ],
  "Involve": [
    {"en":"Don\u0027t hesitate to involve if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại bao gồm, liên quan, để tâm trí vào nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Involvement": [
    {"en":"We noticed a significant change in the overall involvement last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự tham gia, liên quan trong tháng trước."}
  ],
  "Irrigation": [
    {"en":"Our team will host a seminar to address issues concerning irrigation.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự tưới tiêu."}
  ],
  "Issue": [
    {"en":"Ensure that all safety standards regarding the issue are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về vấn đề đều được tuân thủ nghiêm ngặt."},
    {"en":"We need to issue closely with our partners to finalize the deal.","vi":"Chúng ta cần cấp, phát hành chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Itinerary": [
    {"en":"We are currently reviewing the updated policies regarding itinerary.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến lịch trình."}
  ],
  "Job opening": [
    {"en":"The management decided to focus on improving our job opening this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện vị trí việc làm trống của chúng ta trong quý này."}
  ],
  "Job posting": [
    {"en":"Could you provide more details about the job posting mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tin tuyển dụng được đề cập trong email không?"}
  ],
  "Joint": [
    {"en":"His feedback on the project was remarkably joint and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng chung, cùng nhau và mang tính xây dựng."}
  ],
  "Justify": [
    {"en":"Our team strives to justify high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực biện minh, chứng minh là đúng các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Keep fit": [
    {"en":"Don\u0027t hesitate to keep fit if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại giữ dáng, duy trì sức khỏe nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Keynote speech": [
    {"en":"We noticed a significant change in the overall keynote speech last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về bài phát biểu chính trong tháng trước."}
  ],
  "Knowledge": [
    {"en":"Our team will host a seminar to address issues concerning knowledge.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến kiến thức."}
  ],
  "Knowledgeable": [
    {"en":"The newly designed office environment is very knowledgeable for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất am hiểu, có kiến thức cho sức khỏe của nhân viên."}
  ],
  "Laboratory": [
    {"en":"The executive team will discuss the proposed laboratory during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về phòng thí nghiệm được đề xuất trong cuộc họp ngày mai."}
  ],
  "Lack": [
    {"en":"We are currently reviewing the updated policies regarding lack.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự thiếu hụt."}
  ],
  "Landmark": [
    {"en":"The management decided to focus on improving our landmark this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện danh lam thắng cảnh, cột mốc của chúng ta trong quý này."}
  ],
  "Landscape": [
    {"en":"Could you provide more details about the landscape mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về phong cảnh, cảnh quan được đề cập trong email không?"}
  ],
  "Landscaping": [
    {"en":"Having a clear understand of landscaping is essential for this project.","vi":"Hiểu rõ về cảnh quan, sự làm đẹp cảnh quan là điều cần thiết cho dự án này."}
  ],
  "Lane": [
    {"en":"Please send all relevant documents related to the lane by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến làn đường trước thứ Sáu."}
  ],
  "Last": [
    {"en":"Don\u0027t hesitate to last if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại kéo dài nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Last-minute": [
    {"en":"Our team achieved last-minute progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển phút chót sau khi áp dụng quy trình làm việc mới."}
  ],
  "Latest": [
    {"en":"Make sure that all latest details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết mới nhất đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Launch": [
    {"en":"Ensure that all safety standards regarding the launch are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự ra mắt, khai trương đều được tuân thủ nghiêm ngặt."},
    {"en":"We need to launch closely with our partners to finalize the deal.","vi":"Chúng ta cần ra mắt, khai trương chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Layout": [
    {"en":"We are currently reviewing the updated policies regarding layout.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến bố cục, sơ đồ bố trí."}
  ],
  "Layover": [
    {"en":"The management decided to focus on improving our layover this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện điểm dừng chân, thời gian nghỉ (chờ chuyến bay) của chúng ta trong quý này."}
  ],
  "Lead": [
    {"en":"Did you have a chance to lead the quarterly report yet?","vi":"Bạn đã có cơ hội dẫn dắt, chỉ huy báo cáo hàng quý chưa?"}
  ],
  "Lean against": [
    {"en":"The supervisor asked us to lean against the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi dựa vào cho cả đội về những cập nhật mới nhất."}
  ],
  "Lease": [
    {"en":"Please send all relevant documents related to the lease by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến hợp đồng thuê trước thứ Sáu."}
  ],
  "Leftover": [
    {"en":"The market demand remains highly leftover during this period of the year.","vi":"Nhu cầu thị trường vẫn rất thừa, còn lại trong khoảng thời gian này của năm."}
  ],
  "Liability": [
    {"en":"We noticed a significant change in the overall liability last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về trách nhiệm pháp lý trong tháng trước."}
  ],
  "Liaison": [
    {"en":"Our team will host a seminar to address issues concerning liaison.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người liên lạc, sự liên lạc."}
  ],
  "Life-size": [
    {"en":"The newly designed office environment is very life-size for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất kích thước thật cho sức khỏe của nhân viên."}
  ],
  "Light fixture": [
    {"en":"The executive team will discuss the proposed light fixture during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về đèn chùm, thiết bị chiếu sáng được đề xuất trong cuộc họp ngày mai."}
  ],
  "Lightweight": [
    {"en":"The manager praised her for providing a very lightweight solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất nhẹ cho vấn đề."}
  ],
  "Limited": [
    {"en":"It is important to keep all official documentation limited and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức có giới hạn và được sắp xếp gọn gàng."}
  ],
  "Liquid": [
    {"en":"Could you provide more details about the liquid mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về chất lỏng được đề cập trong email không?"}
  ],
  "List": [
    {"en":"The supervisor asked us to list the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi liệt kê, ghi vào danh sách cho cả đội về những cập nhật mới nhất."}
  ],
  "Loan": [
    {"en":"Please send all relevant documents related to the loan by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến khoản vay trước thứ Sáu."}
  ],
  "Local": [
    {"en":"The market demand remains highly local during this period of the year.","vi":"Nhu cầu thị trường vẫn rất thuộc địa phương trong khoảng thời gian này của năm."}
  ],
  "Locate": [
    {"en":"They intend to locate the project schedule to accommodate client requests.","vi":"Họ có ý định xác định vị trí, tìm thấy lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Location": [
    {"en":"Our team will host a seminar to address issues concerning location.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến địa điểm, vị trí."}
  ],
  "Lodging": [
    {"en":"Ensure that all safety standards regarding the lodging are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về nơi ở tạm thời, chỗ trọ đều được tuân thủ nghiêm ngặt."}
  ],
  "Lower": [
    {"en":"We need to lower closely with our partners to finalize the deal.","vi":"Chúng ta cần hạ thấp, giảm chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Loyalty": [
    {"en":"We are currently reviewing the updated policies regarding loyalty.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến lòng trung thành."}
  ],
  "Luggage": [
    {"en":"The management decided to focus on improving our luggage this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện hành lý của chúng ta trong quý này."}
  ],
  "Luncheon": [
    {"en":"Could you provide more details about the luncheon mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tiệc trưa được đề cập trong email không?"}
  ],
  "Machinery": [
    {"en":"Having a clear understand of machinery is essential for this project.","vi":"Hiểu rõ về máy móc là điều cần thiết cho dự án này."}
  ],
  "Maintain": [
    {"en":"Our team strives to maintain high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực bảo trì, duy trì các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Maintenance": [
    {"en":"The client expressed great interest in our strategy for maintenance.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự bảo trì."}
  ],
  "Majority": [
    {"en":"We noticed a significant change in the overall majority last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về đa số, phần lớn trong tháng trước."}
  ],
  "Malfunction": [
    {"en":"Could you help me malfunction these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi gặp trục trặc, hỏng hóc những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Management": [
    {"en":"Ensure that all safety standards regarding the management are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về ban quản lý, sự quản lý đều được tuân thủ nghiêm ngặt."}
  ],
  "Managerial": [
    {"en":"They hired a managerial specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia thuộc về quản lý để giám sát việc chuyển đổi hệ thống."}
  ],
  "Manufacturer": [
    {"en":"We are currently reviewing the updated policies regarding manufacturer.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến nhà sản xuất."}
  ],
  "Manuscript": [
    {"en":"The management decided to focus on improving our manuscript this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện bản thảo của chúng ta trong quý này."}
  ],
  "Margin": [
    {"en":"Could you provide more details about the margin mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về lề, mép; biên độ (lợi nhuận) được đề cập trong email không?"}
  ],
  "Mark": [
    {"en":"The supervisor asked us to mark the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi đánh dấu, kỷ niệm cho cả đội về những cập nhật mới nhất."}
  ],
  "Master": [
    {"en":"Our team strives to master high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực tinh thông, nắm vững các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Match": [
    {"en":"Don\u0027t hesitate to match if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại phù hợp, nối, làm cho tương xứng nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Material": [
    {"en":"We noticed a significant change in the overall material last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về tài liệu, vật liệu trong tháng trước."}
  ],
  "Mayor": [
    {"en":"Our team will host a seminar to address issues concerning mayor.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến thị trưởng."}
  ],
  "Measure": [
    {"en":"It is critical that we measure all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải đo lường tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Measures": [
    {"en":"The executive team will discuss the proposed measures during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về biện pháp được đề xuất trong cuộc họp ngày mai."}
  ],
  "Mechanic": [
    {"en":"We are currently reviewing the updated policies regarding mechanic.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thợ cơ khí."}
  ],
  "Medication": [
    {"en":"The management decided to focus on improving our medication this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện thuốc, dược phẩm của chúng ta trong quý này."}
  ],
  "Meet": [
    {"en":"Did you have a chance to meet the quarterly report yet?","vi":"Bạn đã có cơ hội đáp ứng, thỏa mãn (yêu cầu) báo cáo hàng quý chưa?"}
  ],
  "Meeting minutes": [
    {"en":"Having a clear understand of meeting minutes is essential for this project.","vi":"Hiểu rõ về biên bản cuộc họp là điều cần thiết cho dự án này."}
  ],
  "Memoir": [
    {"en":"Please send all relevant documents related to the memoir by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến hồi ký trước thứ Sáu."}
  ],
  "Memorable": [
    {"en":"The market demand remains highly memorable during this period of the year.","vi":"Nhu cầu thị trường vẫn rất đáng nhớ trong khoảng thời gian này của năm."}
  ],
  "Merchandise": [
    {"en":"We noticed a significant change in the overall merchandise last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về hàng hóa trong tháng trước."}
  ],
  "Merger": [
    {"en":"Our team will host a seminar to address issues concerning merger.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự sáp nhập."}
  ],
  "Method": [
    {"en":"Ensure that all safety standards regarding the method are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về phương pháp đều được tuân thủ nghiêm ngặt."}
  ],
  "Milestone": [
    {"en":"The executive team will discuss the proposed milestone during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về cột mốc quan trọng được đề xuất trong cuộc họp ngày mai."}
  ],
  "Mingle": [
    {"en":"Please make sure to mingle all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn hòa nhập, trộn lẫn mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Minutes": [
    {"en":"The management decided to focus on improving our minutes this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện biên bản cuộc họp của chúng ta trong quý này."}
  ],
  "Misinformation": [
    {"en":"Could you provide more details about the misinformation mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về thông tin sai lệch được đề cập trong email không?"}
  ],
  "Miss": [
    {"en":"The supervisor asked us to miss the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi bỏ lỡ, nhớ cho cả đội về những cập nhật mới nhất."}
  ],
  "Misunderstanding": [
    {"en":"Please send all relevant documents related to the misunderstanding by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự hiểu lầm trước thứ Sáu."}
  ],
  "Mixture": [
    {"en":"The client expressed great interest in our strategy for mixture.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với hỗn hợp."}
  ],
  "Moderately": [
    {"en":"The team completed the task moderately despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách vừa phải mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Moderation": [
    {"en":"Our team will host a seminar to address issues concerning moderation.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự tiết chế, điều độ."}
  ],
  "Modification": [
    {"en":"Ensure that all safety standards regarding the modification are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự sửa đổi đều được tuân thủ nghiêm ngặt."}
  ],
  "Monitor": [
    {"en":"We need to monitor closely with our partners to finalize the deal.","vi":"Chúng ta cần giám sát, theo dõi chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Morale": [
    {"en":"We are currently reviewing the updated policies regarding morale.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến tinh thần, nhuệ khí."}
  ],
  "Motivate": [
    {"en":"We plan to motivate the new guidelines across all regional offices.","vi":"Chúng tôi dự định thúc đẩy, tạo động lực các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Multiple": [
    {"en":"We are looking for a multiple approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp nhiều, đa dạng để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Municipal": [
    {"en":"His feedback on the project was remarkably municipal and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thuộc về thành phố, đô thị và mang tính xây dựng."}
  ],
  "Mural": [
    {"en":"Please send all relevant documents related to the mural by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến tranh tường trước thứ Sáu."}
  ],
  "Name": [
    {"en":"Don\u0027t hesitate to name if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại bổ nhiệm, chỉ định nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Narrative": [
    {"en":"We noticed a significant change in the overall narrative last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về câu chuyện, bài tường thuật trong tháng trước."}
  ],
  "Narrow": [
    {"en":"Make sure that all narrow details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết thu hẹp / chật hẹp đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Nationwide": [
    {"en":"The team completed the task nationwide despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách trên toàn quốc mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Navigate": [
    {"en":"We need to navigate closely with our partners to finalize the deal.","vi":"Chúng ta cần điều hướng, tìm đường chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Negative": [
    {"en":"The manager praised her for providing a very negative solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất tiêu cực cho vấn đề."}
  ],
  "Negotiate": [
    {"en":"We plan to negotiate the new guidelines across all regional offices.","vi":"Chúng tôi dự định đàm phán, thương lượng các hướng dẫn mới tại tất cả các văn phòng khu vực."},
    {"en":"Did you have a chance to negotiate the quarterly report yet?","vi":"Bạn đã có cơ hội đàm phán báo cáo hàng quý chưa?"}
  ],
  "Negotiation": [
    {"en":"Having a clear understand of negotiation is essential for this project.","vi":"Hiểu rõ về sự đàm phán, thương lượng là điều cần thiết cho dự án này."}
  ],
  "New hire": [
    {"en":"Please send all relevant documents related to the new hire by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến nhân viên mới trước thứ Sáu."}
  ],
  "Nominate": [
    {"en":"Don\u0027t hesitate to nominate if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại đề cử nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Nonprofit": [
    {"en":"Our team achieved nonprofit progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển phi lợi nhuận sau khi áp dụng quy trình làm việc mới."}
  ],
  "Notable": [
    {"en":"Make sure that all notable details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đáng chú ý đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Notification": [
    {"en":"Ensure that all safety standards regarding the notification are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về thông báo đều được tuân thủ nghiêm ngặt."}
  ],
  "Notify": [
    {"en":"We need to notify closely with our partners to finalize the deal.","vi":"Chúng ta cần thông báo chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Nourish": [
    {"en":"Please make sure to nourish all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn nuôi dưỡng mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Numerous": [
    {"en":"It is important to keep all official documentation numerous and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức nhiều, đông đảo và được sắp xếp gọn gàng."}
  ],
  "Nutrition": [
    {"en":"Could you provide more details about the nutrition mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về dinh dưỡng được đề cập trong email không?"}
  ],
  "Nutritional": [
    {"en":"His feedback on the project was remarkably nutritional and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thuộc về dinh dưỡng và mang tính xây dựng."}
  ],
  "Nutritious": [
    {"en":"Please ensure that the client receives a nutritious response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời bổ dưỡng trong vòng 24 giờ."}
  ],
  "Objection": [
    {"en":"The client expressed great interest in our strategy for objection.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự phản đối."}
  ],
  "Objective": [
    {"en":"We noticed a significant change in the overall objective last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về mục tiêu trong tháng trước."}
  ],
  "Observe": [
    {"en":"Could you help me observe these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi kỷ niệm (lễ), tuân thủ, quan sát những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Obtain": [
    {"en":"It is critical that we obtain all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải đạt được, lấy được tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Occupied": [
    {"en":"They hired a occupied specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia đang sử dụng, có người để giám sát việc chuyển đổi hệ thống."}
  ],
  "Occupy": [
    {"en":"Please make sure to occupy all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn chiếm giữ, cư ngụ mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Occur": [
    {"en":"We plan to occur the new guidelines across all regional offices.","vi":"Chúng tôi dự định xảy ra các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Official": [
    {"en":"We are looking for a official approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp chính thức để xử lý khối lượng công việc đang tăng lên."},
    {"en":"Having a clear understand of official is essential for this project.","vi":"Hiểu rõ về quan chức là điều cần thiết cho dự án này."}
  ],
  "Officially": [
    {"en":"The team completed the task officially despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách chính thức mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Offset": [
    {"en":"Don\u0027t hesitate to offset if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại bù đắp, đền bù nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "On behalf of": [
    {"en":"We should consider \u0027on behalf of\u0027 when planning our marketing budget for next year.","vi":"Chúng ta nên xem xét \u0027thay mặt cho\u0027 khi lập kế hoạch ngân sách tiếp thị cho năm tới."}
  ],
  "Onboarding": [
    {"en":"Our team will host a seminar to address issues concerning onboarding.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến quy trình nhập môn (cho nhân viên mới)."}
  ],
  "Ongoing": [
    {"en":"The newly designed office environment is very ongoing for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất đang diễn ra, liên tục cho sức khỏe của nhân viên."}
  ],
  "Open position": [
    {"en":"The executive team will discuss the proposed open position during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về vị trí trống (cần tuyển dụng) được đề xuất trong cuộc họp ngày mai."}
  ],
  "Opening": [
    {"en":"We are currently reviewing the updated policies regarding opening.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến vị trí trống (việc làm), lễ khai trương."}
  ],
  "Operate": [
    {"en":"We plan to operate the new guidelines across all regional offices.","vi":"Chúng tôi dự định vận hành các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Operation": [
    {"en":"Could you provide more details about the operation mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự vận hành, hoạt động được đề cập trong email không?"}
  ],
  "Opportunity": [
    {"en":"Having a clear understand of opportunity is essential for this project.","vi":"Hiểu rõ về cơ hội là điều cần thiết cho dự án này."},
    {"en":"Please send all relevant documents related to the opportunity by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến cơ hội trước thứ Sáu."}
  ],
  "Opposite": [
    {"en":"The director mentioned \u0027opposite\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027đối diện\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Opposition": [
    {"en":"We noticed a significant change in the overall opposition last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự phản đối trong tháng trước."}
  ],
  "Optimal": [
    {"en":"Make sure that all optimal details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết tối ưu đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Optimize": [
    {"en":"It is critical that we optimize all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tối ưu hóa tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Organic": [
    {"en":"They hired a organic specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia hữu cơ để giám sát việc chuyển đổi hệ thống."}
  ],
  "Organization": [
    {"en":"We are currently reviewing the updated policies regarding organization.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến tổ chức, cơ quan."}
  ],
  "Organize": [
    {"en":"We plan to organize the new guidelines across all regional offices.","vi":"Chúng tôi dự định tổ chức, sắp xếp các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Organizer": [
    {"en":"Could you provide more details about the organizer mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về người tổ chức được đề cập trong email không?"}
  ],
  "Original": [
    {"en":"His feedback on the project was remarkably original and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng ban đầu, gốc và mang tính xây dựng."}
  ],
  "Originally": [
    {"en":"The team completed the task originally despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách ban đầu, vốn dĩ mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Outcome": [
    {"en":"The client expressed great interest in our strategy for outcome.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với kết quả."}
  ],
  "Outdoor": [
    {"en":"Our team achieved outdoor progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển ngoài trời sau khi áp dụng quy trình làm việc mới."}
  ],
  "Outdoors": [
    {"en":"Please double-check the figures outdoors to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách ở ngoài trời để tránh các sai sót về ngân sách."}
  ],
  "Outline": [
    {"en":"It is critical that we outline all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải phác thảo, vạch ra tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Outstanding": [
    {"en":"They hired a outstanding specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia xuất sắc, nổi bật, còn tồn đọng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Overall": [
    {"en":"The manager praised her for providing a very overall solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất tổng thể, toàn bộ cho vấn đề."}
  ],
  "Overcome": [
    {"en":"We plan to overcome the new guidelines across all regional offices.","vi":"Chúng tôi dự định vượt qua, khắc phục các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Overdue": [
    {"en":"We are looking for a overdue approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp quá hạn, chậm trễ để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Overhead": [
    {"en":"His feedback on the project was remarkably overhead and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng ở trên đầu và mang tính xây dựng."}
  ],
  "Overnight": [
    {"en":"The team completed the task overnight despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách qua đêm mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Overseas": [
    {"en":"The market demand remains highly overseas during this period of the year.","vi":"Nhu cầu thị trường vẫn rất ở nước ngoài / thuộc nước ngoài trong khoảng thời gian này của năm."}
  ],
  "Oversee": [
    {"en":"They intend to oversee the project schedule to accommodate client requests.","vi":"Họ có ý định giám sát lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Overtime": [
    {"en":"Our team will host a seminar to address issues concerning overtime.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến giờ làm thêm."},
    {"en":"The newly designed office environment is very overtime for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất quá giờ cho sức khỏe của nhân viên."}
  ],
  "Owed": [
    {"en":"They hired a owed specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia còn nợ để giám sát việc chuyển đổi hệ thống."}
  ],
  "Own": [
    {"en":"Please make sure to own all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn sở hữu mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Owner": [
    {"en":"The management decided to focus on improving our owner this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện chủ sở hữu của chúng ta trong quý này."}
  ],
  "Pack": [
    {"en":"Did you have a chance to pack the quarterly report yet?","vi":"Bạn đã có cơ hội đóng gói báo cáo hàng quý chưa?"}
  ],
  "Pain": [
    {"en":"Having a clear understand of pain is essential for this project.","vi":"Hiểu rõ về cơn đau là điều cần thiết cho dự án này."}
  ],
  "Paperwork": [
    {"en":"Please send all relevant documents related to the paperwork by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến công việc giấy tờ, thủ tục hành chính trước thứ Sáu."}
  ],
  "Paradise": [
    {"en":"The client expressed great interest in our strategy for paradise.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với thiên đường."}
  ],
  "Partial": [
    {"en":"Our team achieved partial progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển một phần sau khi áp dụng quy trình làm việc mới."}
  ],
  "Participant": [
    {"en":"Our team will host a seminar to address issues concerning participant.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người tham gia."}
  ],
  "Participate in": [
    {"en":"It is critical that we participate in all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tham gia vào tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Participation": [
    {"en":"The executive team will discuss the proposed participation during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự tham gia được đề xuất trong cuộc họp ngày mai."}
  ],
  "Particular": [
    {"en":"The manager praised her for providing a very particular solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất cụ thể, đặc biệt cho vấn đề."}
  ],
  "Pass": [
    {"en":"The management decided to focus on improving our pass this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện thẻ ra vào, vé của chúng ta trong quý này."}
  ],
  "Passenger": [
    {"en":"Could you provide more details about the passenger mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về hành khách được đề cập trong email không?"}
  ],
  "Pathway": [
    {"en":"Having a clear understand of pathway is essential for this project.","vi":"Hiểu rõ về con đường, lối đi là điều cần thiết cho dự án này."}
  ],
  "Patience": [
    {"en":"Please send all relevant documents related to the patience by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự kiên nhẫn trước thứ Sáu."}
  ],
  "Patio": [
    {"en":"The client expressed great interest in our strategy for patio.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sân trong, hiên nhà."}
  ],
  "Patron": [
    {"en":"We noticed a significant change in the overall patron last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về khách hàng quen trong tháng trước."}
  ],
  "Paved": [
    {"en":"Make sure that all paved details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết được lát đường đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Pavement": [
    {"en":"Ensure that all safety standards regarding the pavement are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về vỉa hè, mặt đường đều được tuân thủ nghiêm ngặt."}
  ],
  "Payment": [
    {"en":"The executive team will discuss the proposed payment during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự thanh toán được đề xuất trong cuộc họp ngày mai."}
  ],
  "Payroll": [
    {"en":"We are currently reviewing the updated policies regarding payroll.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến bảng lương, việc trả lương."}
  ],
  "Pedestrian": [
    {"en":"The management decided to focus on improving our pedestrian this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện người đi bộ của chúng ta trong quý này."}
  ],
  "Pediatric": [
    {"en":"We are looking for a pediatric approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thuộc nha khoa/y khoa trẻ em để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Peninsula": [
    {"en":"Having a clear understand of peninsula is essential for this project.","vi":"Hiểu rõ về bán đảo là điều cần thiết cho dự án này."}
  ],
  "Performance": [
    {"en":"Please send all relevant documents related to the performance by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến hiệu suất, thành tích trước thứ Sáu."}
  ],
  "Performer": [
    {"en":"The client expressed great interest in our strategy for performer.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với người biểu diễn."}
  ],
  "Perimeter": [
    {"en":"We noticed a significant change in the overall perimeter last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về chu vi, vành đai trong tháng trước."}
  ],
  "Permanently": [
    {"en":"Please double-check the figures permanently to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách vĩnh viễn, lâu dài để tránh các sai sót về ngân sách."}
  ],
  "Permission": [
    {"en":"Ensure that all safety standards regarding the permission are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự cho phép đều được tuân thủ nghiêm ngặt."}
  ],
  "Permit": [
    {"en":"The executive team will discuss the proposed permit during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về giấy phép được đề xuất trong cuộc họp ngày mai."}
  ],
  "Persevere": [
    {"en":"Please make sure to persevere all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn kiên trì mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Persist": [
    {"en":"We plan to persist the new guidelines across all regional offices.","vi":"Chúng tôi dự định kiên trì, tiếp diễn các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Persistent": [
    {"en":"We are looking for a persistent approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp kiên trì, dai dẳng để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Personality": [
    {"en":"Having a clear understand of personality is essential for this project.","vi":"Hiểu rõ về tính cách, nhân phẩm là điều cần thiết cho dự án này."}
  ],
  "Personalized": [
    {"en":"Please ensure that the client receives a personalized response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời cá nhân hóa trong vòng 24 giờ."}
  ],
  "Personnel": [
    {"en":"The client expressed great interest in our strategy for personnel.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với nhân sự."}
  ],
  "Perspective": [
    {"en":"We noticed a significant change in the overall perspective last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về quan điểm, góc nhìn trong tháng trước."}
  ],
  "Persuade": [
    {"en":"Could you help me persuade these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi thuyết phục những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Pharmaceutical": [
    {"en":"The newly designed office environment is very pharmaceutical for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất thuộc dược phẩm cho sức khỏe của nhân viên."}
  ],
  "Pharmacy": [
    {"en":"The executive team will discuss the proposed pharmacy during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về hiệu thuốc được đề xuất trong cuộc họp ngày mai."}
  ],
  "Physician": [
    {"en":"We are currently reviewing the updated policies regarding physician.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến bác sĩ (đa khoa/nội khoa)."}
  ],
  "Physiotherapy": [
    {"en":"The management decided to focus on improving our physiotherapy this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện vật lý trị liệu của chúng ta trong quý này."}
  ],
  "Pillow": [
    {"en":"Could you provide more details about the pillow mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về cái gối được đề cập trong email không?"}
  ],
  "Pitch": [
    {"en":"Having a clear understand of pitch is essential for this project.","vi":"Hiểu rõ về bài chào hàng, lời rao là điều cần thiết cho dự án này."}
  ],
  "Placement": [
    {"en":"Please send all relevant documents related to the placement by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự sắp đặt, vị trí trước thứ Sáu."}
  ],
  "Pleasure": [
    {"en":"The client expressed great interest in our strategy for pleasure.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với niềm vui, sự hài lòng."}
  ],
  "Plotline": [
    {"en":"We noticed a significant change in the overall plotline last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về cốt truyện trong tháng trước."}
  ],
  "Policy": [
    {"en":"Our team will host a seminar to address issues concerning policy.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến chính sách."}
  ],
  "Politeness": [
    {"en":"Ensure that all safety standards regarding the politeness are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự lịch sự, lễ phép đều được tuân thủ nghiêm ngặt."}
  ],
  "Politician": [
    {"en":"The executive team will discuss the proposed politician during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về chính trị gia được đề xuất trong cuộc họp ngày mai."}
  ],
  "Popularity": [
    {"en":"We are currently reviewing the updated policies regarding popularity.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự phổ biến."}
  ],
  "Porous": [
    {"en":"It is important to keep all official documentation porous and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức xốp, rỗ (thấm nước) và được sắp xếp gọn gàng."}
  ],
  "Portrait": [
    {"en":"Could you provide more details about the portrait mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về chân dung được đề cập trong email không?"}
  ],
  "Position": [
    {"en":"Having a clear understand of position is essential for this project.","vi":"Hiểu rõ về vị trí, tư thế là điều cần thiết cho dự án này."}
  ],
  "Positive": [
    {"en":"Please ensure that the client receives a positive response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tích cực trong vòng 24 giờ."}
  ],
  "Possess": [
    {"en":"Don\u0027t hesitate to possess if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại sở hữu nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Possession": [
    {"en":"We noticed a significant change in the overall possession last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự sở hữu, tài sản trong tháng trước."}
  ],
  "Post": [
    {"en":"Could you help me post these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi đăng tải, niêm yết những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Postpone": [
    {"en":"It is critical that we postpone all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải trì hoãn tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Potential": [
    {"en":"They hired a potential specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia tiềm năng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Pour": [
    {"en":"Please make sure to pour all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn rót, đổ mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Power failure": [
    {"en":"The management decided to focus on improving our power failure this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự cố mất điện của chúng ta trong quý này."}
  ],
  "Practical": [
    {"en":"We are looking for a practical approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thực tế, thiết thực để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Practice": [
    {"en":"Having a clear understand of practice is essential for this project.","vi":"Hiểu rõ về sự thực hành, thói quen là điều cần thiết cho dự án này."}
  ],
  "Praise": [
    {"en":"Our team strives to praise high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực khen ngợi các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Precision": [
    {"en":"The client expressed great interest in our strategy for precision.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với độ chính xác."}
  ],
  "Precondition": [
    {"en":"We noticed a significant change in the overall precondition last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về điều kiện tiên quyết trong tháng trước."}
  ],
  "Predecessor": [
    {"en":"Our team will host a seminar to address issues concerning predecessor.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người tiền nhiệm."}
  ],
  "Predict": [
    {"en":"It is critical that we predict all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải dự đoán tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Preference": [
    {"en":"The executive team will discuss the proposed preference during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự ưu tiên, sở thích được đề xuất trong cuộc họp ngày mai."}
  ],
  "Prescription": [
    {"en":"We are currently reviewing the updated policies regarding prescription.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến đơn thuốc."}
  ],
  "Presence": [
    {"en":"The management decided to focus on improving our presence this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự hiện diện của chúng ta trong quý này."}
  ],
  "Present": [
    {"en":"We are looking for a present approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp hiện tại để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Preserve": [
    {"en":"The supervisor asked us to preserve the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi bảo tồn, giữ gìn cho cả đội về những cập nhật mới nhất."}
  ],
  "Press": [
    {"en":"Please send all relevant documents related to the press by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến báo chí, truyền thông trước thứ Sáu."}
  ],
  "Press conference": [
    {"en":"The client expressed great interest in our strategy for press conference.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với họp báo."}
  ],
  "Prestigious": [
    {"en":"Our team achieved prestigious progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển có uy tín, danh giá sau khi áp dụng quy trình làm việc mới."}
  ],
  "Prevent": [
    {"en":"Could you help me prevent these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi ngăn chặn, ngăn ngừa những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Preventive": [
    {"en":"The newly designed office environment is very preventive for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất mang tính phòng ngừa cho sức khỏe của nhân viên."}
  ],
  "Previous": [
    {"en":"They hired a previous specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia trước đó để giám sát việc chuyển đổi hệ thống."}
  ],
  "Previously": [
    {"en":"The team completed the task previously despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách trước đây mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Primarily": [
    {"en":"Please double-check the figures primarily to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách chủ yếu, chính để tránh các sai sót về ngân sách."}
  ],
  "Prime": [
    {"en":"We are looking for a prime approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp ưu tú, hàng đầu để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Priority": [
    {"en":"Having a clear understand of priority is essential for this project.","vi":"Hiểu rõ về sự ưu tiên là điều cần thiết cho dự án này."}
  ],
  "Private": [
    {"en":"Please ensure that the client receives a private response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời riêng tư, cá nhân trong vòng 24 giờ."}
  ],
  "Privilege": [
    {"en":"The client expressed great interest in our strategy for privilege.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với đặc quyền, vinh dự."}
  ],
  "Proactive": [
    {"en":"Our team achieved proactive progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển chủ động sau khi áp dụng quy trình làm việc mới."}
  ],
  "Procedure": [
    {"en":"Our team will host a seminar to address issues concerning procedure.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến quy trình, thủ tục."}
  ],
  "Proceed": [
    {"en":"It is critical that we proceed all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tiến hành, tiếp tục tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Proceeds": [
    {"en":"The executive team will discuss the proposed proceeds during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về tiền thu được (thường dùng cho từ thiện) được đề xuất trong cuộc họp ngày mai."}
  ],
  "Process": [
    {"en":"We are currently reviewing the updated policies regarding process.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến quy trình, quá trình."},
    {"en":"We plan to process the new guidelines across all regional offices.","vi":"Chúng tôi dự định xử lý các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Procurement": [
    {"en":"Could you provide more details about the procurement mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự thu mua, mua sắm được đề cập trong email không?"}
  ],
  "Productive": [
    {"en":"His feedback on the project was remarkably productive and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng năng suất, hiệu quả và mang tính xây dựng."}
  ],
  "Productivity": [
    {"en":"Please send all relevant documents related to the productivity by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến năng suất trước thứ Sáu."}
  ],
  "Profession": [
    {"en":"The client expressed great interest in our strategy for profession.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với nghề nghiệp."}
  ],
  "Professional": [
    {"en":"Our team achieved professional progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển chuyên nghiệp sau khi áp dụng quy trình làm việc mới."}
  ],
  "Proficiency": [
    {"en":"Our team will host a seminar to address issues concerning proficiency.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự thành thạo."}
  ],
  "Profitable": [
    {"en":"The newly designed office environment is very profitable for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất có lợi nhuận, sinh lời cho sức khỏe của nhân viên."}
  ],
  "Progress": [
    {"en":"We need to progress closely with our partners to finalize the deal.","vi":"Chúng ta cần tiến hành, tiến bộ chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Promise": [
    {"en":"We should consider \u0027promise\u0027 when planning our marketing budget for next year.","vi":"Chúng ta nên xem xét \u0027hứa hẹn, có triển vọng / lời hứa\u0027 khi lập kế hoạch ngân sách tiếp thị cho năm tới."}
  ],
  "Promising": [
    {"en":"It is important to keep all official documentation promising and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức đầy hứa hẹn, triển vọng và được sắp xếp gọn gàng."}
  ],
  "Promote": [
    {"en":"Did you have a chance to promote the quarterly report yet?","vi":"Bạn đã có cơ hội thúc đẩy, thăng chức, quảng bá báo cáo hàng quý chưa?"}
  ],
  "Promotion": [
    {"en":"Having a clear understand of promotion is essential for this project.","vi":"Hiểu rõ về sự thăng chức, sự quảng bá là điều cần thiết cho dự án này."}
  ],
  "Promotional": [
    {"en":"Please ensure that the client receives a promotional response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời thuộc quảng cáo, khuyến mãi trong vòng 24 giờ."}
  ],
  "Prompt": [
    {"en":"The market demand remains highly prompt during this period of the year.","vi":"Nhu cầu thị trường vẫn rất nhanh chóng, tức thời trong khoảng thời gian này của năm."}
  ],
  "Promptly": [
    {"en":"The team completed the task promptly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách ngay lập tức, đúng giờ mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Proof": [
    {"en":"Our team will host a seminar to address issues concerning proof.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến bằng chứng."}
  ],
  "Proofread": [
    {"en":"It is critical that we proofread all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải hiệu đính, đọc sửa tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Property": [
    {"en":"The executive team will discuss the proposed property during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về bất động sản, tài sản được đề xuất trong cuộc họp ngày mai."}
  ],
  "Proposal": [
    {"en":"We are currently reviewing the updated policies regarding proposal.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến bản đề xuất."}
  ],
  "Prospective": [
    {"en":"It is important to keep all official documentation prospective and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức tiềm năng, triển vọng và được sắp xếp gọn gàng."}
  ],
  "Protective": [
    {"en":"We are looking for a protective approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp bảo vệ để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Protocol": [
    {"en":"Having a clear understand of protocol is essential for this project.","vi":"Hiểu rõ về giao thức, quy định, nghi thức là điều cần thiết cho dự án này."}
  ],
  "Prototype": [
    {"en":"Please send all relevant documents related to the prototype by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến nguyên mẫu trước thứ Sáu."}
  ],
  "Public": [
    {"en":"The client expressed great interest in our strategy for public.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với công cộng, công chúng."}
  ],
  "Publication": [
    {"en":"We noticed a significant change in the overall publication last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về ấn phẩm trong tháng trước."}
  ],
  "Publicity": [
    {"en":"Our team will host a seminar to address issues concerning publicity.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự quảng bá, công khai."}
  ],
  "Publicize": [
    {"en":"It is critical that we publicize all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải công khai, quảng bá tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Publish": [
    {"en":"We need to publish closely with our partners to finalize the deal.","vi":"Chúng ta cần xuất bản, công bố chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Punctuality": [
    {"en":"We are currently reviewing the updated policies regarding punctuality.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự đúng giờ."}
  ],
  "Purchase": [
    {"en":"We plan to purchase the new guidelines across all regional offices.","vi":"Chúng tôi dự định mua hàng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Purified": [
    {"en":"We are looking for a purified approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp được thanh lọc, tinh chế để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Pursue": [
    {"en":"The supervisor asked us to pursue the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi theo đuổi cho cả đội về những cập nhật mới nhất."}
  ],
  "Put together": [
    {"en":"Our team strives to put together high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực lắp ráp, tập hợp các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Quaint": [
    {"en":"The market demand remains highly quaint during this period of the year.","vi":"Nhu cầu thị trường vẫn rất độc đáo, cổ kính, lạ mắt trong khoảng thời gian này của năm."}
  ],
  "Qualification": [
    {"en":"We noticed a significant change in the overall qualification last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về trình độ chuyên môn, bằng cấp trong tháng trước."}
  ],
  "Qualified": [
    {"en":"Make sure that all qualified details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đủ điều kiện, có năng lực đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Quality": [
    {"en":"The newly designed office environment is very quality for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất chất lượng cao cho sức khỏe của nhân viên."},
    {"en":"The executive team will discuss the proposed quality during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về chất lượng được đề xuất trong cuộc họp ngày mai."}
  ],
  "Quarter": [
    {"en":"We are currently reviewing the updated policies regarding quarter.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến quý (thời gian), một phần tư."}
  ],
  "Quarterly": [
    {"en":"It is important to keep all official documentation quarterly and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức hàng quý và được sắp xếp gọn gàng."}
  ],
  "Question": [
    {"en":"Did you have a chance to question the quarterly report yet?","vi":"Bạn đã có cơ hội nghi ngờ, chất vấn báo cáo hàng quý chưa?"}
  ],
  "Questionnaire": [
    {"en":"Having a clear understand of questionnaire is essential for this project.","vi":"Hiểu rõ về bảng câu hỏi là điều cần thiết cho dự án này."}
  ],
  "Quote": [
    {"en":"Our team strives to quote high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực trích dẫn, báo giá các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Rack": [
    {"en":"The client expressed great interest in our strategy for rack.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với giá đỡ, kệ."}
  ],
  "Radius": [
    {"en":"We noticed a significant change in the overall radius last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về bán kính, phạm vi trong tháng trước."}
  ],
  "Raffle": [
    {"en":"Our team will host a seminar to address issues concerning raffle.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến xổ số (gây quỹ)."}
  ],
  "Railing": [
    {"en":"Ensure that all safety standards regarding the railing are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về lan can đều được tuân thủ nghiêm ngặt."}
  ],
  "Rake": [
    {"en":"We need to rake closely with our partners to finalize the deal.","vi":"Chúng ta cần cào (lá, đất) chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Randomly": [
    {"en":"The team completed the task randomly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách ngẫu nhiên mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Rapid": [
    {"en":"It is important to keep all official documentation rapid and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức nhanh chóng và được sắp xếp gọn gàng."}
  ],
  "Rapidly": [
    {"en":"The team completed the task rapidly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách nhanh chóng mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Rare": [
    {"en":"His feedback on the project was remarkably rare and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng hiếm và mang tính xây dựng."}
  ],
  "Rate": [
    {"en":"Please send all relevant documents related to the rate by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến mức giá, phí trước thứ Sáu."}
  ],
  "Rating": [
    {"en":"The client expressed great interest in our strategy for rating.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với xếp hạng, đánh giá."}
  ],
  "Reach for": [
    {"en":"They intend to reach for the project schedule to accommodate client requests.","vi":"Họ có ý định với lấy, hướng tay về phía lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Realize": [
    {"en":"Could you help me realize these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi nhận ra những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Realty": [
    {"en":"Ensure that all safety standards regarding the realty are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về bất động sản đều được tuân thủ nghiêm ngặt."}
  ],
  "Reasonable": [
    {"en":"They hired a reasonable specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia hợp lý, phải chăng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Reasonably": [
    {"en":"The team completed the task reasonably despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách một cách hợp lý, khá là mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Reassign": [
    {"en":"We plan to reassign the new guidelines across all regional offices.","vi":"Chúng tôi dự định phân công lại các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Reassurance": [
    {"en":"Could you provide more details about the reassurance mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự trấn an, cam đoan được đề cập trong email không?"}
  ],
  "Rebook": [
    {"en":"The supervisor asked us to rebook the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi đặt lại (vé, chỗ) cho cả đội về những cập nhật mới nhất."}
  ],
  "Receipt": [
    {"en":"Please send all relevant documents related to the receipt by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến hóa đơn, biên lai trước thứ Sáu."}
  ],
  "Recent": [
    {"en":"The market demand remains highly recent during this period of the year.","vi":"Nhu cầu thị trường vẫn rất gần đây trong khoảng thời gian này của năm."}
  ],
  "Recently": [
    {"en":"The team completed the task recently despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách gần đây mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Receptacle": [
    {"en":"Our team will host a seminar to address issues concerning receptacle.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến chỗ chứa, thùng đựng."}
  ],
  "Reception": [
    {"en":"Ensure that all safety standards regarding the reception are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về tiệc chiêu đãi đều được tuân thủ nghiêm ngặt."}
  ],
  "Recipe": [
    {"en":"The executive team will discuss the proposed recipe during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về công thức nấu ăn được đề xuất trong cuộc họp ngày mai."}
  ],
  "Recipient": [
    {"en":"We are currently reviewing the updated policies regarding recipient.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến người nhận."}
  ],
  "Reciprocate": [
    {"en":"We plan to reciprocate the new guidelines across all regional offices.","vi":"Chúng tôi dự định đền đáp, đáp lại các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Recognize": [
    {"en":"Did you have a chance to recognize the quarterly report yet?","vi":"Bạn đã có cơ hội công nhận, nhận ra báo cáo hàng quý chưa?"}
  ],
  "Recommendation": [
    {"en":"Having a clear understand of recommendation is essential for this project.","vi":"Hiểu rõ về sự giới thiệu, lời khuyên là điều cần thiết cho dự án này."}
  ],
  "Recreation": [
    {"en":"Please send all relevant documents related to the recreation by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự giải trí, tiêu khiển trước thứ Sáu."}
  ],
  "Recruit": [
    {"en":"Don\u0027t hesitate to recruit if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại tuyển dụng nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Recruitment": [
    {"en":"We noticed a significant change in the overall recruitment last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự tuyển dụng trong tháng trước."}
  ],
  "Recurring": [
    {"en":"Make sure that all recurring details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết định kỳ, lặp lại đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Recycling": [
    {"en":"Ensure that all safety standards regarding the recycling are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự tái chế đều được tuân thủ nghiêm ngặt."}
  ],
  "Reduce": [
    {"en":"We need to reduce closely with our partners to finalize the deal.","vi":"Chúng ta cần giảm bớt chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Reduction": [
    {"en":"We are currently reviewing the updated policies regarding reduction.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự cắt giảm."}
  ],
  "Refer": [
    {"en":"We plan to refer the new guidelines across all regional offices.","vi":"Chúng tôi dự định giới thiệu, tham khảo các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Reference": [
    {"en":"Could you provide more details about the reference mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tài liệu tham khảo, sự giới thiệu được đề cập trong email không?"}
  ],
  "Refine": [
    {"en":"The supervisor asked us to refine the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi tinh chỉnh, cải tiến cho cả đội về những cập nhật mới nhất."}
  ],
  "Refined": [
    {"en":"Please ensure that the client receives a refined response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tinh chế, tao nhã trong vòng 24 giờ."}
  ],
  "Reflect": [
    {"en":"Don\u0027t hesitate to reflect if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại phản ánh, phản chiếu nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Refrain": [
    {"en":"They intend to refrain the project schedule to accommodate client requests.","vi":"Họ có ý định kiềm chế, tự nguyện không làm lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Refund": [
    {"en":"Our team will host a seminar to address issues concerning refund.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến tiền hoàn lại."}
  ],
  "Refurbish": [
    {"en":"It is critical that we refurbish all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tân trang, trang trí lại tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Regard": [
    {"en":"We need to regard closely with our partners to finalize the deal.","vi":"Chúng ta cần đánh giá, coi như, xem như chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Regional": [
    {"en":"The manager praised her for providing a very regional solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất thuộc khu vực, vùng miền cho vấn đề."}
  ],
  "Register": [
    {"en":"The management decided to focus on improving our register this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện máy tính tiền của chúng ta trong quý này."}
  ],
  "Registration": [
    {"en":"Could you provide more details about the registration mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự đăng ký được đề cập trong email không?"}
  ],
  "Regular": [
    {"en":"His feedback on the project was remarkably regular and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng thường xuyên, đều đặn và mang tính xây dựng."},
    {"en":"Please ensure that the client receives a regular response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời đều đặn, thường xuyên trong vòng 24 giờ."}
  ],
  "Regularly": [
    {"en":"Please double-check the figures regularly to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách thường xuyên, đều đặn để tránh các sai sót về ngân sách."}
  ],
  "Regulation": [
    {"en":"We noticed a significant change in the overall regulation last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về quy định trong tháng trước."},
    {"en":"Our team will host a seminar to address issues concerning regulation.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến quy định."}
  ],
  "Reimbursement": [
    {"en":"Ensure that all safety standards regarding the reimbursement are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự hoàn tiền, khoản bồi hoàn đều được tuân thủ nghiêm ngặt."}
  ],
  "Reject": [
    {"en":"We need to reject closely with our partners to finalize the deal.","vi":"Chúng ta cần từ chối, bác bỏ chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Release": [
    {"en":"Please make sure to release all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn phát hành, tung ra mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Relevant": [
    {"en":"It is important to keep all official documentation relevant and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức có liên quan, thích hợp và được sắp xếp gọn gàng."},
    {"en":"We are looking for a relevant approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp có liên quan, thích hợp để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Reliability": [
    {"en":"Having a clear understand of reliability is essential for this project.","vi":"Hiểu rõ về sự đáng tin cậy là điều cần thiết cho dự án này."}
  ],
  "Reliable": [
    {"en":"Please ensure that the client receives a reliable response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời đáng tin cậy trong vòng 24 giờ."}
  ],
  "Reliably": [
    {"en":"Please double-check the figures reliably to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách đáng tin cậy để tránh các sai sót về ngân sách."}
  ],
  "Relieved": [
    {"en":"Our team achieved relieved progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển an tâm, nhẹ nhõm sau khi áp dụng quy trình làm việc mới."}
  ],
  "Relocate": [
    {"en":"Could you help me relocate these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi di dời, chuyển địa điểm những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Remain": [
    {"en":"It is critical that we remain all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải duy trì, còn lại tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Remind": [
    {"en":"We need to remind closely with our partners to finalize the deal.","vi":"Chúng ta cần nhắc nhở chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Reminder": [
    {"en":"We are currently reviewing the updated policies regarding reminder.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến lời nhắc nhở."}
  ],
  "Remote": [
    {"en":"It is important to keep all official documentation remote and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức từ xa, hẻo lánh và được sắp xếp gọn gàng."}
  ],
  "Remotely": [
    {"en":"The team completed the task remotely despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách từ xa mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Removal": [
    {"en":"Having a clear understand of removal is essential for this project.","vi":"Hiểu rõ về sự dời đi, sự loại bỏ là điều cần thiết cho dự án này."}
  ],
  "Remove": [
    {"en":"Our team strives to remove high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực loại bỏ, tháo ra các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Renew": [
    {"en":"Don\u0027t hesitate to renew if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại gia hạn, làm mới nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Renewal": [
    {"en":"We noticed a significant change in the overall renewal last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự gia hạn, đổi mới trong tháng trước."}
  ],
  "Renovate": [
    {"en":"Could you help me renovate these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi cải tạo những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Renovation": [
    {"en":"Ensure that all safety standards regarding the renovation are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự cải tạo, sửa chữa đều được tuân thủ nghiêm ngặt."}
  ],
  "Renowned": [
    {"en":"They hired a renowned specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia nổi tiếng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Rent": [
    {"en":"Please make sure to rent all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn thuê mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Rental": [
    {"en":"The management decided to focus on improving our rental this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự thuê mướn của chúng ta trong quý này."}
  ],
  "Repair": [
    {"en":"Did you have a chance to repair the quarterly report yet?","vi":"Bạn đã có cơ hội sửa chữa báo cáo hàng quý chưa?"}
  ],
  "Replace": [
    {"en":"The supervisor asked us to replace the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi thay thế cho cả đội về những cập nhật mới nhất."}
  ],
  "Replacement": [
    {"en":"Please send all relevant documents related to the replacement by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự thay thế, vật thay thế trước thứ Sáu."}
  ],
  "Represent": [
    {"en":"Don\u0027t hesitate to represent if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại đại diện nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."},
    {"en":"They intend to represent the project schedule to accommodate client requests.","vi":"Họ có ý định đại diện lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Representative": [
    {"en":"Our team will host a seminar to address issues concerning representative.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến người đại diện."}
  ],
  "Reputation": [
    {"en":"Ensure that all safety standards regarding the reputation are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về danh tiếng đều được tuân thủ nghiêm ngặt."}
  ],
  "Required": [
    {"en":"They hired a required specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia được yêu cầu, bắt buộc để giám sát việc chuyển đổi hệ thống."}
  ],
  "Requirement": [
    {"en":"We are currently reviewing the updated policies regarding requirement.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến yêu cầu."}
  ],
  "Reschedule": [
    {"en":"We plan to reschedule the new guidelines across all regional offices.","vi":"Chúng tôi dự định sắp xếp lại lịch các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Research": [
    {"en":"Could you provide more details about the research mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về nghiên cứu được đề cập trong email không?"}
  ],
  "Researcher": [
    {"en":"Having a clear understand of researcher is essential for this project.","vi":"Hiểu rõ về nhà nghiên cứu là điều cần thiết cho dự án này."}
  ],
  "Resemble": [
    {"en":"Our team strives to resemble high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực giống với các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Reservation": [
    {"en":"The client expressed great interest in our strategy for reservation.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với sự đặt chỗ."}
  ],
  "Reserve": [
    {"en":"They intend to reserve the project schedule to accommodate client requests.","vi":"Họ có ý định đặt trước, dự trữ lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Residence": [
    {"en":"Our team will host a seminar to address issues concerning residence.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến nơi cư trú."}
  ],
  "Resident": [
    {"en":"Ensure that all safety standards regarding the resident are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về cư dân đều được tuân thủ nghiêm ngặt."}
  ],
  "Residential": [
    {"en":"They hired a residential specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia thuộc khu dân cư, cư trú để giám sát việc chuyển đổi hệ thống."}
  ],
  "Residue": [
    {"en":"We are currently reviewing the updated policies regarding residue.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến cặn, dư lượng."}
  ],
  "Resist": [
    {"en":"We plan to resist the new guidelines across all regional offices.","vi":"Chúng tôi dự định kháng cự, chịu đựng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Resolve": [
    {"en":"Did you have a chance to resolve the quarterly report yet?","vi":"Bạn đã có cơ hội giải quyết báo cáo hàng quý chưa?"}
  ],
  "Resource": [
    {"en":"Having a clear understand of resource is essential for this project.","vi":"Hiểu rõ về tài nguyên, nguồn lực là điều cần thiết cho dự án này."}
  ],
  "Respective": [
    {"en":"Please ensure that the client receives a respective response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tương ứng (của riêng từng người/vật) trong vòng 24 giờ."}
  ],
  "Respond": [
    {"en":"Don\u0027t hesitate to respond if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại phản hồi, đáp lại nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Responsibility": [
    {"en":"We noticed a significant change in the overall responsibility last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về trách nhiệm trong tháng trước."}
  ],
  "Responsive": [
    {"en":"Make sure that all responsive details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết phản hồi nhanh, nhiệt tình đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Restoration": [
    {"en":"Ensure that all safety standards regarding the restoration are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự phục hồi, trùng tu đều được tuân thủ nghiêm ngặt."}
  ],
  "Restore": [
    {"en":"We need to restore closely with our partners to finalize the deal.","vi":"Chúng ta cần khôi phục, phục hồi chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Result": [
    {"en":"We are currently reviewing the updated policies regarding result.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến kết quả."},
    {"en":"The management decided to focus on improving our result this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện kết quả của chúng ta trong quý này."}
  ],
  "Résumé": [
    {"en":"Could you provide more details about the résumé mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sơ yếu lý lịch được đề cập trong email không?"}
  ],
  "Retail": [
    {"en":"Having a clear understand of retail is essential for this project.","vi":"Hiểu rõ về bán lẻ là điều cần thiết cho dự án này."},
    {"en":"Please ensure that the client receives a retail response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời bán lẻ trong vòng 24 giờ."}
  ],
  "Retain": [
    {"en":"Don\u0027t hesitate to retain if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại giữ lại, duy trì nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Retire": [
    {"en":"They intend to retire the project schedule to accommodate client requests.","vi":"Họ có ý định nghỉ hưu lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Retirement": [
    {"en":"Our team will host a seminar to address issues concerning retirement.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sự nghỉ hưu."}
  ],
  "Retreat": [
    {"en":"Ensure that all safety standards regarding the retreat are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về chuyến đi nghỉ, dã ngoại đều được tuân thủ nghiêm ngặt."},
    {"en":"The executive team will discuss the proposed retreat during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về chuyến đi nghỉ dưỡng, sự rút lui được đề xuất trong cuộc họp ngày mai."}
  ],
  "Retrieve": [
    {"en":"Please make sure to retrieve all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn lấy lại, khôi phục mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Reveal": [
    {"en":"We plan to reveal the new guidelines across all regional offices.","vi":"Chúng tôi dự định tiết lộ, bộc lộ các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Revenue": [
    {"en":"Could you provide more details about the revenue mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về doanh thu, lợi nhuận được đề cập trong email không?"}
  ],
  "Review": [
    {"en":"The supervisor asked us to review the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi xem xét, đánh giá cho cả đội về những cập nhật mới nhất."}
  ],
  "Revise": [
    {"en":"Our team strives to revise high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực chỉnh sửa, sửa đổi các tiêu chuẩn chất lượng cao trong từng sản phẩm."},
    {"en":"Don\u0027t hesitate to revise if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại chỉnh sửa, sửa đổi nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Revised": [
    {"en":"Our team achieved revised progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển đã được sửa đổi, điều chỉnh sau khi áp dụng quy trình làm việc mới."}
  ],
  "Reward": [
    {"en":"The director mentioned \u0027reward\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027thưởng / phần thưởng\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Rough": [
    {"en":"The newly designed office environment is very rough for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất gồ ghề, thô ráp cho sức khỏe của nhân viên."}
  ],
  "Roughly": [
    {"en":"Please double-check the figures roughly to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách khoảng, xấp xỉ để tránh các sai sót về ngân sách."}
  ],
  "Route": [
    {"en":"We are currently reviewing the updated policies regarding route.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến tuyến đường, lộ trình."}
  ],
  "Routinely": [
    {"en":"Please double-check the figures routinely to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách thường lệ để tránh các sai sót về ngân sách."}
  ],
  "Rug": [
    {"en":"Could you provide more details about the rug mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tấm thảm được đề cập trong email không?"}
  ],
  "Rush": [
    {"en":"His feedback on the project was remarkably rush and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng vội vàng, gấp và mang tính xây dựng."}
  ],
  "Rustic": [
    {"en":"Please ensure that the client receives a rustic response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời mộc mạc, quê mùa trong vòng 24 giờ."}
  ],
  "Sacrifice": [
    {"en":"Don\u0027t hesitate to sacrifice if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại hy sinh nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Sales": [
    {"en":"We noticed a significant change in the overall sales last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về doanh số bán hàng trong tháng trước."}
  ],
  "Sanctuary": [
    {"en":"Our team will host a seminar to address issues concerning sanctuary.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến nơi trú ẩn, khu bảo tồn."}
  ],
  "Sanitize": [
    {"en":"It is critical that we sanitize all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải khử trùng, làm vệ sinh tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Satellite": [
    {"en":"The executive team will discuss the proposed satellite during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về vệ tinh được đề xuất trong cuộc họp ngày mai."}
  ],
  "Satisfaction": [
    {"en":"We are currently reviewing the updated policies regarding satisfaction.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự hài lòng."}
  ],
  "Satisfy": [
    {"en":"We plan to satisfy the new guidelines across all regional offices.","vi":"Chúng tôi dự định làm hài lòng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Savory": [
    {"en":"We are looking for a savory approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp thơm ngon, có vị mặn (không ngọt) để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Savour": [
    {"en":"The supervisor asked us to savour the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi thưởng thức, tận hưởng cho cả đội về những cập nhật mới nhất."}
  ],
  "Scatter": [
    {"en":"Our team strives to scatter high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực rải rác, phân tán các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Screen": [
    {"en":"Don\u0027t hesitate to screen if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại sàng lọc, kiểm tra nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Script": [
    {"en":"We noticed a significant change in the overall script last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về kịch bản trong tháng trước."}
  ],
  "Seal": [
    {"en":"Could you help me seal these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi niêm phong, dán kín những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Sealant": [
    {"en":"Ensure that all safety standards regarding the sealant are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về chất trám kín đều được tuân thủ nghiêm ngặt."}
  ],
  "Secluded": [
    {"en":"They hired a secluded specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia hẻo lánh, yên tĩnh để giám sát việc chuyển đổi hệ thống."}
  ],
  "Secondhand": [
    {"en":"The manager praised her for providing a very secondhand solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất đã qua sử dụng, cũ cho vấn đề."}
  ],
  "Secure": [
    {"en":"We plan to secure the new guidelines across all regional offices.","vi":"Chúng tôi dự định đạt được, bảo đảm các hướng dẫn mới tại tất cả các văn phòng khu vực."},
    {"en":"We are looking for a secure approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp an toàn, bảo đảm để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Security": [
    {"en":"Having a clear understand of security is essential for this project.","vi":"Hiểu rõ về an ninh, sự bảo đảm là điều cần thiết cho dự án này."}
  ],
  "Select": [
    {"en":"Our team strives to select high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực lựa chọn các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Semester": [
    {"en":"The client expressed great interest in our strategy for semester.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với học kỳ."}
  ],
  "Separate": [
    {"en":"Our team achieved separate progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển riêng biệt, tách rời sau khi áp dụng quy trình làm việc mới."}
  ],
  "Separately": [
    {"en":"Please double-check the figures separately to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách một cách riêng biệt để tránh các sai sót về ngân sách."}
  ],
  "Set up": [
    {"en":"It is critical that we set up all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải thiết lập, sắp xếp tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Shade": [
    {"en":"We need to shade closely with our partners to finalize the deal.","vi":"Chúng ta cần tạo bóng râm, che nắng chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Share": [
    {"en":"Please make sure to share all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn chia sẻ mọi phản hồi từ khách hàng trước khi đóng yêu cầu."},
    {"en":"The management decided to focus on improving our share this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện cổ phần, thị phần của chúng ta trong quý này."}
  ],
  "Shareholder": [
    {"en":"Could you provide more details about the shareholder mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về cổ đông được đề cập trong email không?"}
  ],
  "Shelf": [
    {"en":"Having a clear understand of shelf is essential for this project.","vi":"Hiểu rõ về cái kệ, giá sách là điều cần thiết cho dự án này."}
  ],
  "Shift": [
    {"en":"Please send all relevant documents related to the shift by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến ca làm việc trước thứ Sáu."}
  ],
  "Ship": [
    {"en":"Don\u0027t hesitate to ship if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại gửi hàng, vận chuyển nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Shore": [
    {"en":"We noticed a significant change in the overall shore last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về bờ biển trong tháng trước."}
  ],
  "Short-staffed": [
    {"en":"Make sure that all short-staffed details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết thiếu nhân sự đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Shortage": [
    {"en":"Ensure that all safety standards regarding the shortage are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự thiếu hụt đều được tuân thủ nghiêm ngặt."}
  ],
  "Shortcoming": [
    {"en":"The executive team will discuss the proposed shortcoming during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về khuyết điểm, thiếu sót được đề xuất trong cuộc họp ngày mai."}
  ],
  "Shorten": [
    {"en":"Please make sure to shorten all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn rút ngắn mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Showcase": [
    {"en":"We plan to showcase the new guidelines across all regional offices.","vi":"Chúng tôi dự định trưng bày, phô diễn các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Shred": [
    {"en":"Did you have a chance to shred the quarterly report yet?","vi":"Bạn đã có cơ hội cắt nhỏ, hủy (tài liệu) báo cáo hàng quý chưa?"}
  ],
  "Shrink": [
    {"en":"The supervisor asked us to shrink the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi co lại, rút ngắn cho cả đội về những cập nhật mới nhất."}
  ],
  "Sign up for": [
    {"en":"Our team strives to sign up for high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực đăng ký các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Signature": [
    {"en":"The client expressed great interest in our strategy for signature.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với chữ ký."}
  ],
  "Significance": [
    {"en":"We noticed a significant change in the overall significance last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về tầm quan trọng, ý nghĩa trong tháng trước."}
  ],
  "Significant": [
    {"en":"Make sure that all significant details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đáng kể, quan trọng đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Significantly": [
    {"en":"The team completed the task significantly despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách đáng kể, một cách ý nghĩa mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Simplify": [
    {"en":"We need to simplify closely with our partners to finalize the deal.","vi":"Chúng ta cần đơn giản hóa chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Simultaneously": [
    {"en":"The team completed the task simultaneously despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách đồng thời mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Skilled": [
    {"en":"It is important to keep all official documentation skilled and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức lành nghề, khéo léo và được sắp xếp gọn gàng."}
  ],
  "Sleek": [
    {"en":"We are looking for a sleek approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp kiểu dáng đẹp, bóng mượt để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Smudge": [
    {"en":"Having a clear understand of smudge is essential for this project.","vi":"Hiểu rõ về vết bẩn, vết lem là điều cần thiết cho dự án này."}
  ],
  "Snowpack": [
    {"en":"Please send all relevant documents related to the snowpack by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến lớp tuyết dày trước thứ Sáu."}
  ],
  "Socialise": [
    {"en":"Don\u0027t hesitate to socialise if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại giao lưu, hòa nhập nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Society": [
    {"en":"We noticed a significant change in the overall society last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về xã hội, hiệp hội trong tháng trước."}
  ],
  "Soil": [
    {"en":"Our team will host a seminar to address issues concerning soil.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến đất trồng."}
  ],
  "Sold out": [
    {"en":"The newly designed office environment is very sold out for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất hết hàng, bán hết cho sức khỏe của nhân viên."}
  ],
  "Solicit": [
    {"en":"We need to solicit closely with our partners to finalize the deal.","vi":"Chúng ta cần khẩn cầu, kêu gọi chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Solve": [
    {"en":"Please make sure to solve all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn giải quyết mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Sound": [
    {"en":"It is important to keep all official documentation sound and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức vững chãi, có cơ sở, đúng đắn và được sắp xếp gọn gàng."}
  ],
  "Soundproof": [
    {"en":"We are looking for a soundproof approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp cách âm để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Source": [
    {"en":"Having a clear understand of source is essential for this project.","vi":"Hiểu rõ về nguồn, nguồn gốc là điều cần thiết cho dự án này."}
  ],
  "Sourcing": [
    {"en":"Please send all relevant documents related to the sourcing by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến tìm nguồn cung ứng trước thứ Sáu."}
  ],
  "Spacious": [
    {"en":"The market demand remains highly spacious during this period of the year.","vi":"Nhu cầu thị trường vẫn rất rộng rãi trong khoảng thời gian này của năm."}
  ],
  "Spearhead": [
    {"en":"They intend to spearhead the project schedule to accommodate client requests.","vi":"Họ có ý định dẫn đầu, tiên phong lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Specialize in": [
    {"en":"Could you help me specialize in these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi chuyên về những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Specialty": [
    {"en":"Ensure that all safety standards regarding the specialty are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về chuyên môn, đặc sản đều được tuân thủ nghiêm ngặt."}
  ],
  "Specific": [
    {"en":"They hired a specific specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia cụ thể, đặc biệt để giám sát việc chuyển đổi hệ thống."}
  ],
  "Specification": [
    {"en":"We are currently reviewing the updated policies regarding specification.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến thông số kỹ thuật, đặc điểm."}
  ],
  "Specified": [
    {"en":"It is important to keep all official documentation specified and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức được quy định, chỉ rõ và được sắp xếp gọn gàng."}
  ],
  "Spectacular": [
    {"en":"We are looking for a spectacular approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp hùng vĩ, ngoạn mục để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Speculate": [
    {"en":"The supervisor asked us to speculate the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi suy đoán, đầu cơ cho cả đội về những cập nhật mới nhất."}
  ],
  "Spokesperson": [
    {"en":"Please send all relevant documents related to the spokesperson by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến người phát ngôn trước thứ Sáu."}
  ],
  "Sponsor": [
    {"en":"The client expressed great interest in our strategy for sponsor.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với nhà tài trợ."}
  ],
  "Spotless": [
    {"en":"Our team achieved spotless progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển không tì vết, sạch sẽ sau khi áp dụng quy trình làm việc mới."}
  ],
  "Spread": [
    {"en":"Could you help me spread these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi lan truyền, trải ra những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Stabilization": [
    {"en":"Ensure that all safety standards regarding the stabilization are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự ổn định đều được tuân thủ nghiêm ngặt."}
  ],
  "Stack": [
    {"en":"We need to stack closely with our partners to finalize the deal.","vi":"Chúng ta cần chất đống chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Stakeholder": [
    {"en":"We are currently reviewing the updated policies regarding stakeholder.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến các bên liên quan, cổ đông."}
  ],
  "Stand out": [
    {"en":"We plan to stand out the new guidelines across all regional offices.","vi":"Chúng tôi dự định nổi bật các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Standard": [
    {"en":"Could you provide more details about the standard mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tiêu chuẩn được đề cập trong email không?"}
  ],
  "Statement": [
    {"en":"Having a clear understand of statement is essential for this project.","vi":"Hiểu rõ về sao kê, bản tuyên bố là điều cần thiết cho dự án này."}
  ],
  "Stationery": [
    {"en":"Please send all relevant documents related to the stationery by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến văn phòng phẩm trước thứ Sáu."}
  ],
  "Statistical": [
    {"en":"The market demand remains highly statistical during this period of the year.","vi":"Nhu cầu thị trường vẫn rất thuộc thống kê trong khoảng thời gian này của năm."}
  ],
  "Status": [
    {"en":"We noticed a significant change in the overall status last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về trạng thái, địa vị trong tháng trước."}
  ],
  "Steady": [
    {"en":"Make sure that all steady details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết ổn định, đều đặn đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Step down": [
    {"en":"It is critical that we step down all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải từ chức, nghỉ hưu tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Sterile": [
    {"en":"They hired a sterile specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia vô trùng, tiệt trùng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Stipulate": [
    {"en":"Please make sure to stipulate all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn quy định mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Stock": [
    {"en":"The director mentioned \u0027stock\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027hàng tồn kho / tích trữ\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Stop by": [
    {"en":"Did you have a chance to stop by the quarterly report yet?","vi":"Bạn đã có cơ hội ghé qua báo cáo hàng quý chưa?"}
  ],
  "Storage": [
    {"en":"Having a clear understand of storage is essential for this project.","vi":"Hiểu rõ về kho, sự lưu trữ là điều cần thiết cho dự án này."}
  ],
  "Store": [
    {"en":"Our team strives to store high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực lưu trữ, cất giữ các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Storefront": [
    {"en":"The client expressed great interest in our strategy for storefront.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với mặt tiền cửa hàng."}
  ],
  "Straightforward": [
    {"en":"Our team achieved straightforward progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển thẳng thắn, dễ hiểu sau khi áp dụng quy trình làm việc mới."}
  ],
  "Strategy": [
    {"en":"Our team will host a seminar to address issues concerning strategy.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến chiến lược."}
  ],
  "Streamline": [
    {"en":"It is critical that we streamline all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải tinh giản, hợp lý hóa (quy trình) tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Strength": [
    {"en":"The executive team will discuss the proposed strength during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về điểm mạnh được đề xuất trong cuộc họp ngày mai."}
  ],
  "Striped": [
    {"en":"The manager praised her for providing a very striped solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất có sọc, vằn cho vấn đề."}
  ],
  "Stroll": [
    {"en":"We plan to stroll the new guidelines across all regional offices.","vi":"Chúng tôi dự định đi dạo các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Structure": [
    {"en":"Did you have a chance to structure the quarterly report yet?","vi":"Bạn đã có cơ hội cấu trúc, tổ chức báo cáo hàng quý chưa?"}
  ],
  "Struggle": [
    {"en":"The supervisor asked us to struggle the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi chật vật, cố gắng cho cả đội về những cập nhật mới nhất."}
  ],
  "Stunning": [
    {"en":"Please ensure that the client receives a stunning response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tuyệt đẹp, gây ấn tượng mạnh trong vòng 24 giờ."}
  ],
  "Sturdy": [
    {"en":"The market demand remains highly sturdy during this period of the year.","vi":"Nhu cầu thị trường vẫn rất cứng cáp, vững chắc trong khoảng thời gian này của năm."}
  ],
  "Subcompact": [
    {"en":"We noticed a significant change in the overall subcompact last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về xe ô tô cỡ nhỏ trong tháng trước."}
  ],
  "Submerge": [
    {"en":"Could you help me submerge these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi nhấn chìm, lặn những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Submission": [
    {"en":"Ensure that all safety standards regarding the submission are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự nộp, hồ sơ đệ trình đều được tuân thủ nghiêm ngặt."}
  ],
  "Submit": [
    {"en":"We need to submit closely with our partners to finalize the deal.","vi":"Chúng ta cần nộp, đệ trình chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Subordinate": [
    {"en":"We are currently reviewing the updated policies regarding subordinate.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến cấp dưới."}
  ],
  "Subscription": [
    {"en":"The management decided to focus on improving our subscription this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự đăng ký (báo, tạp chí) của chúng ta trong quý này."}
  ],
  "Subsequent": [
    {"en":"We are looking for a subsequent approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp đến sau, theo sau để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Subsequently": [
    {"en":"Please double-check the figures subsequently to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách sau đó để tránh các sai sót về ngân sách."}
  ],
  "Subsidiary": [
    {"en":"Please send all relevant documents related to the subsidiary by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến công ty con trước thứ Sáu."}
  ],
  "Substance": [
    {"en":"The client expressed great interest in our strategy for substance.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với chất, vật chất."}
  ],
  "Substantial": [
    {"en":"Our team achieved substantial progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển đáng kể sau khi áp dụng quy trình làm việc mới."}
  ],
  "Substitute": [
    {"en":"Could you help me substitute these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi thay thế những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Suburban": [
    {"en":"The newly designed office environment is very suburban for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất thuộc ngoại ô cho sức khỏe của nhân viên."}
  ],
  "Success": [
    {"en":"The executive team will discuss the proposed success during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự thành công được đề xuất trong cuộc họp ngày mai."}
  ],
  "Successive": [
    {"en":"The manager praised her for providing a very successive solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất liên tiếp cho vấn đề."}
  ],
  "Sudden": [
    {"en":"It is important to keep all official documentation sudden and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức đột ngột và được sắp xếp gọn gàng."}
  ],
  "Sufficient": [
    {"en":"We are looking for a sufficient approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp đủ để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Suggest": [
    {"en":"The supervisor asked us to suggest the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi gợi ý, đề xuất cho cả đội về những cập nhật mới nhất."}
  ],
  "Suggestion": [
    {"en":"Please send all relevant documents related to the suggestion by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến sự đề xuất, gợi ý trước thứ Sáu."}
  ],
  "Suitable": [
    {"en":"The market demand remains highly suitable during this period of the year.","vi":"Nhu cầu thị trường vẫn rất phù hợp, thích hợp trong khoảng thời gian này của năm."}
  ],
  "Summarize": [
    {"en":"They intend to summarize the project schedule to accommodate client requests.","vi":"Họ có ý định tóm tắt lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Summary": [
    {"en":"Our team will host a seminar to address issues concerning summary.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến bản tóm tắt."}
  ],
  "Superintendent": [
    {"en":"Ensure that all safety standards regarding the superintendent are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về người giám sát, giám thị đều được tuân thủ nghiêm ngặt."}
  ],
  "Supervise": [
    {"en":"We need to supervise closely with our partners to finalize the deal.","vi":"Chúng ta cần giám sát chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Supervisor": [
    {"en":"We are currently reviewing the updated policies regarding supervisor.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến người giám sát, cấp trên."}
  ],
  "Supplier": [
    {"en":"The management decided to focus on improving our supplier this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện nhà cung cấp của chúng ta trong quý này."}
  ],
  "Supplies": [
    {"en":"Could you provide more details about the supplies mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về vật tư, nhu yếu phẩm được đề cập trong email không?"}
  ],
  "Supportive": [
    {"en":"His feedback on the project was remarkably supportive and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng hỗ trợ, ủng hộ và mang tính xây dựng."}
  ],
  "Surface": [
    {"en":"Please send all relevant documents related to the surface by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến bề mặt trước thứ Sáu."}
  ],
  "Surrounding": [
    {"en":"The client expressed great interest in our strategy for surrounding.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với môi trường xung quanh."}
  ],
  "Suspension": [
    {"en":"We noticed a significant change in the overall suspension last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự đình chỉ, tạm ngưng trong tháng trước."}
  ],
  "Suspicious": [
    {"en":"Make sure that all suspicious details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết khả nghi, đáng ngờ đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Sustainable": [
    {"en":"The newly designed office environment is very sustainable for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất bền vững cho sức khỏe của nhân viên."}
  ],
  "Symbolise": [
    {"en":"We need to symbolise closely with our partners to finalize the deal.","vi":"Chúng ta cần tượng trưng cho chặt chẽ với các đối tác để hoàn tất thương vụ."}
  ],
  "Synthetic": [
    {"en":"The manager praised her for providing a very synthetic solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất tổng hợp, nhân tạo cho vấn đề."}
  ],
  "Tactile": [
    {"en":"It is important to keep all official documentation tactile and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức thuộc về xúc giác và được sắp xếp gọn gàng."}
  ],
  "Take advantage of": [
    {"en":"Did you have a chance to take advantage of the quarterly report yet?","vi":"Bạn đã có cơ hội tận dụng, lợi dụng báo cáo hàng quý chưa?"}
  ],
  "Take care of": [
    {"en":"The supervisor asked us to take care of the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi chăm sóc, xử lý cho cả đội về những cập nhật mới nhất."}
  ],
  "Take down": [
    {"en":"Our team strives to take down high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực tháo dỡ các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Take place": [
    {"en":"Don\u0027t hesitate to take place if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại diễn ra, được tổ chức nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Takeoff": [
    {"en":"We noticed a significant change in the overall takeoff last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự cất cánh trong tháng trước."}
  ],
  "Talented": [
    {"en":"Make sure that all talented details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết tài năng đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Tardiness": [
    {"en":"Ensure that all safety standards regarding the tardiness are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự chậm trễ, lề mề đều được tuân thủ nghiêm ngặt."}
  ],
  "Target audience": [
    {"en":"The executive team will discuss the proposed target audience during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về khách hàng mục tiêu được đề xuất trong cuộc họp ngày mai."}
  ],
  "Technical": [
    {"en":"The manager praised her for providing a very technical solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất thuộc về kỹ thuật, chuyên môn cho vấn đề."}
  ],
  "Telescope": [
    {"en":"The management decided to focus on improving our telescope this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện kính thiên văn của chúng ta trong quý này."}
  ],
  "Temperature": [
    {"en":"Could you provide more details about the temperature mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về nhiệt độ được đề cập trong email không?"}
  ],
  "Temporarily": [
    {"en":"Please double-check the figures temporarily to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách tạm thời để tránh các sai sót về ngân sách."}
  ],
  "Temporary": [
    {"en":"Please ensure that the client receives a temporary response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời tạm thời trong vòng 24 giờ."}
  ],
  "Tenant": [
    {"en":"The client expressed great interest in our strategy for tenant.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với người thuê (nhà, đất)."}
  ],
  "Tendency": [
    {"en":"We noticed a significant change in the overall tendency last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về khuynh hướng trong tháng trước."}
  ],
  "Tenure": [
    {"en":"Our team will host a seminar to address issues concerning tenure.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến nhiệm kỳ."}
  ],
  "Term": [
    {"en":"Ensure that all safety standards regarding the term are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về thuật ngữ, kỳ hạn đều được tuân thủ nghiêm ngặt."}
  ],
  "Territory": [
    {"en":"The executive team will discuss the proposed territory during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về lãnh thổ, khu vực được đề xuất trong cuộc họp ngày mai."}
  ],
  "Testimonial": [
    {"en":"We are currently reviewing the updated policies regarding testimonial.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến giấy chứng nhận, lời khen ngợi (từ khách hàng)."}
  ],
  "Textile": [
    {"en":"The management decided to focus on improving our textile this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện dệt may của chúng ta trong quý này."}
  ],
  "Theme": [
    {"en":"Could you provide more details about the theme mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về chủ đề được đề cập trong email không?"}
  ],
  "Thermostat": [
    {"en":"Having a clear understand of thermostat is essential for this project.","vi":"Hiểu rõ về bộ điều chỉnh nhiệt độ là điều cần thiết cho dự án này."}
  ],
  "Thorough": [
    {"en":"Please ensure that the client receives a thorough response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời cẩn thận, triệt để, kỹ lưỡng trong vòng 24 giờ."}
  ],
  "Thrilled": [
    {"en":"The market demand remains highly thrilled during this period of the year.","vi":"Nhu cầu thị trường vẫn rất hào hứng, vui sướng trong khoảng thời gian này của năm."}
  ],
  "Thrive": [
    {"en":"They intend to thrive the project schedule to accommodate client requests.","vi":"Họ có ý định phát triển mạnh, thịnh vượng lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Tie": [
    {"en":"Could you help me tie these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi buộc, thắt những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Time off": [
    {"en":"Ensure that all safety standards regarding the time off are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về thời gian nghỉ đều được tuân thủ nghiêm ngặt."}
  ],
  "Time sheet": [
    {"en":"The executive team will discuss the proposed time sheet during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về bảng chấm công được đề xuất trong cuộc họp ngày mai."}
  ],
  "Timeless": [
    {"en":"The manager praised her for providing a very timeless solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất vô tận, vượt thời gian (không lỗi thời) cho vấn đề."}
  ],
  "Timeline": [
    {"en":"The management decided to focus on improving our timeline this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện mốc thời gian, lịch trình của chúng ta trong quý này."}
  ],
  "Timely": [
    {"en":"We are looking for a timely approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp kịp thời, đúng lúc để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Tolerant": [
    {"en":"His feedback on the project was remarkably tolerant and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng chịu đựng tốt, có khả năng kháng và mang tính xây dựng."}
  ],
  "Tow": [
    {"en":"Our team strives to tow high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực lai dắt, cẩu (xe) các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Track": [
    {"en":"Don\u0027t hesitate to track if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại theo dõi nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Traditional": [
    {"en":"Our team achieved traditional progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển truyền thống sau khi áp dụng quy trình làm việc mới."}
  ],
  "Traffic": [
    {"en":"Our team will host a seminar to address issues concerning traffic.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến giao thông, xe cộ."}
  ],
  "Transaction": [
    {"en":"Ensure that all safety standards regarding the transaction are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về giao dịch đều được tuân thủ nghiêm ngặt."}
  ],
  "Transcript": [
    {"en":"The executive team will discuss the proposed transcript during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về bảng điểm, bản sao được đề xuất trong cuộc họp ngày mai."}
  ],
  "Transfer": [
    {"en":"Please make sure to transfer all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn chuyển, thuyên chuyển mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Transition": [
    {"en":"The management decided to focus on improving our transition this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện sự chuyển tiếp, quá độ của chúng ta trong quý này."}
  ],
  "Translate": [
    {"en":"Did you have a chance to translate the quarterly report yet?","vi":"Bạn đã có cơ hội dịch thuật báo cáo hàng quý chưa?"}
  ],
  "Transplant": [
    {"en":"The supervisor asked us to transplant the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi cấy ghép, trồng lại cho cả đội về những cập nhật mới nhất."}
  ],
  "Transport": [
    {"en":"Our team strives to transport high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực vận chuyển các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Transportation": [
    {"en":"The client expressed great interest in our strategy for transportation.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với giao thông vận tải."}
  ],
  "Treatment": [
    {"en":"We noticed a significant change in the overall treatment last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về sự điều trị, xử lý trong tháng trước."}
  ],
  "Tremendous": [
    {"en":"Make sure that all tremendous details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết to lớn, khủng khiếp đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Trend": [
    {"en":"Ensure that all safety standards regarding the trend are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về xu hướng đều được tuân thủ nghiêm ngặt."}
  ],
  "Tricky": [
    {"en":"They hired a tricky specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia phức tạp, khôn lanh để giám sát việc chuyển đổi hệ thống."}
  ],
  "Trim": [
    {"en":"Please make sure to trim all customer feedback before closing the ticket.","vi":"Vui lòng đảm bảo rằng bạn cắt tỉa, chỉnh sửa mọi phản hồi từ khách hàng trước khi đóng yêu cầu."}
  ],
  "Triumph": [
    {"en":"The management decided to focus on improving our triumph this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện chiến thắng, thành tựu lớn của chúng ta trong quý này."}
  ],
  "Tuition": [
    {"en":"Could you provide more details about the tuition mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về học phí được đề cập trong email không?"}
  ],
  "Typically": [
    {"en":"Please double-check the figures typically to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách thông thường để tránh các sai sót về ngân sách."}
  ],
  "Ultimately": [
    {"en":"The team completed the task ultimately despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách cuối cùng, rốt cuộc mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Unavailable": [
    {"en":"The market demand remains highly unavailable during this period of the year.","vi":"Nhu cầu thị trường vẫn rất không có sẵn, bận trong khoảng thời gian này của năm."}
  ],
  "Undergo": [
    {"en":"They intend to undergo the project schedule to accommodate client requests.","vi":"Họ có ý định trải qua lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Undergraduate": [
    {"en":"Our team will host a seminar to address issues concerning undergraduate.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến sinh viên chưa tốt nghiệp."}
  ],
  "Understaffed": [
    {"en":"The newly designed office environment is very understaffed for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất thiếu nhân sự cho sức khỏe của nhân viên."}
  ],
  "Undoubtedly": [
    {"en":"Please double-check the figures undoubtedly to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách không nghi ngờ gì, chắc chắn để tránh các sai sót về ngân sách."}
  ],
  "Uneven": [
    {"en":"The manager praised her for providing a very uneven solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất không bằng phẳng, không đều cho vấn đề."}
  ],
  "Unexpected": [
    {"en":"It is important to keep all official documentation unexpected and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức bất ngờ, không mong đợi và được sắp xếp gọn gàng."}
  ],
  "Unfamiliar": [
    {"en":"We are looking for a unfamiliar approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp không quen, lạ lẫm để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Unfavorable": [
    {"en":"His feedback on the project was remarkably unfavorable and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng bất lợi, không thuận lợi và mang tính xây dựng."}
  ],
  "Unfortunately": [
    {"en":"The team completed the task unfortunately despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách thật không may mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Unintentionally": [
    {"en":"Please double-check the figures unintentionally to prevent any budget errors.","vi":"Vui lòng kiểm tra lại các số liệu một cách vô tình, không chủ ý để tránh các sai sót về ngân sách."}
  ],
  "Unique": [
    {"en":"Our team achieved unique progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển độc đáo sau khi áp dụng quy trình làm việc mới."}
  ],
  "Unload": [
    {"en":"Could you help me unload these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi dỡ hàng những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Unnecessary": [
    {"en":"The newly designed office environment is very unnecessary for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất không cần thiết cho sức khỏe của nhân viên."}
  ],
  "Unprecedented": [
    {"en":"They hired a unprecedented specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia chưa từng có tiền lệ để giám sát việc chuyển đổi hệ thống."}
  ],
  "Unpredictability": [
    {"en":"We are currently reviewing the updated policies regarding unpredictability.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến sự không thể đoán trước."}
  ],
  "Unsightly": [
    {"en":"It is important to keep all official documentation unsightly and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức khó coi, xấu xí và được sắp xếp gọn gàng."}
  ],
  "Unsuitable": [
    {"en":"We are looking for a unsuitable approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp không phù hợp để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Unusual": [
    {"en":"His feedback on the project was remarkably unusual and constructive.","vi":"Phản hồi của anh ấy về dự án vô cùng bất thường, hiếm và mang tính xây dựng."}
  ],
  "Unusually": [
    {"en":"The team completed the task unusually despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách khác thường, hiếm thấy mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Unveil": [
    {"en":"Don\u0027t hesitate to unveil if you encounter any unexpected technical issues.","vi":"Đừng ngần ngại tiết lộ, công bố, khánh thành nếu bạn gặp phải bất kỳ sự cố kỹ thuật ngoài dự kiến nào."}
  ],
  "Upcoming": [
    {"en":"Our team achieved upcoming progress after implementing the new workflow.","vi":"Đội ngũ của chúng tôi đã đạt được sự tiến triển sắp tới sau khi áp dụng quy trình làm việc mới."}
  ],
  "Upstairs": [
    {"en":"Make sure that all upstairs details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết ở tầng trên đều được xác minh kỹ lưỡng trước khi nộp."},
    {"en":"The team completed the task upstairs despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách ở tầng trên mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Urban": [
    {"en":"They hired a urban specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia thuộc thành thị để giám sát việc chuyển đổi hệ thống."}
  ],
  "Usually": [
    {"en":"The team completed the task usually despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách thường xuyên, thông thường mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Utensil": [
    {"en":"The management decided to focus on improving our utensil this quarter.","vi":"Ban quản lý đã quyết định tập trung vào việc cải thiện dụng cụ (thường dùng trong nhà bếp) của chúng ta trong quý này."}
  ],
  "Utilities": [
    {"en":"Could you provide more details about the utilities mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về tiện ích (điện, nước, gas...) được đề cập trong email không?"}
  ],
  "Vacancy": [
    {"en":"Having a clear understand of vacancy is essential for this project.","vi":"Hiểu rõ về vị trí trống, chỗ trống là điều cần thiết cho dự án này."}
  ],
  "Vacant": [
    {"en":"Please ensure that the client receives a vacant response within 24 hours.","vi":"Hãy đảm bảo rằng khách hàng nhận được câu trả lời trống, bỏ không, còn trống (vị trí) trong vòng 24 giờ."}
  ],
  "Valid": [
    {"en":"The market demand remains highly valid during this period of the year.","vi":"Nhu cầu thị trường vẫn rất có hiệu lực trong khoảng thời gian này của năm."}
  ],
  "Validate": [
    {"en":"They intend to validate the project schedule to accommodate client requests.","vi":"Họ có ý định xác nhận, phê chuẩn lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Valuable": [
    {"en":"Make sure that all valuable details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết có giá trị, quý giá đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Variation": [
    {"en":"Ensure that all safety standards regarding the variation are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về sự biến đổi, biến thể đều được tuân thủ nghiêm ngặt."}
  ],
  "Varied": [
    {"en":"They hired a varied specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia đa dạng để giám sát việc chuyển đổi hệ thống."}
  ],
  "Various": [
    {"en":"The manager praised her for providing a very various solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất đa dạng cho vấn đề."}
  ],
  "Vary": [
    {"en":"We plan to vary the new guidelines across all regional offices.","vi":"Chúng tôi dự định thay đổi, làm đa dạng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Vast": [
    {"en":"We are looking for a vast approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp rộng lớn, mênh mông để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Vehicle": [
    {"en":"Having a clear understand of vehicle is essential for this project.","vi":"Hiểu rõ về xe cộ, phương tiện là điều cần thiết cho dự án này."}
  ],
  "Vendor": [
    {"en":"Please send all relevant documents related to the vendor by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến nhà cung cấp, người bán hàng trước thứ Sáu."}
  ],
  "Venue": [
    {"en":"The client expressed great interest in our strategy for venue.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với địa điểm tổ chức."}
  ],
  "Verify": [
    {"en":"They intend to verify the project schedule to accommodate client requests.","vi":"Họ có ý định xác minh lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Versatile": [
    {"en":"Make sure that all versatile details are thoroughly verified before submission.","vi":"Hãy chắc chắn rằng mọi chi tiết đa năng, linh hoạt đều được xác minh kỹ lưỡng trước khi nộp."}
  ],
  "Vintage": [
    {"en":"The newly designed office environment is very vintage for employee well-being.","vi":"Môi trường văn phòng mới được thiết kế rất cổ điển, kinh điển cho sức khỏe của nhân viên."}
  ],
  "Virtual": [
    {"en":"They hired a virtual specialist to oversee the system migration.","vi":"Họ đã thuê một chuyên gia ảo (trên mạng) để giám sát việc chuyển đổi hệ thống."}
  ],
  "Virtually": [
    {"en":"The team completed the task virtually despite working under tight deadlines.","vi":"Cả đội đã hoàn thành nhiệm vụ một cách hầu như, một cách ảo (qua mạng) mặc dù làm việc trong thời hạn gấp rút."}
  ],
  "Visible": [
    {"en":"It is important to keep all official documentation visible and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức có thể nhìn thấy, rõ ràng và được sắp xếp gọn gàng."}
  ],
  "Visualization": [
    {"en":"Could you provide more details about the visualization mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sự hình dung, trực quan hóa được đề cập trong email không?"}
  ],
  "Volunteer": [
    {"en":"The director mentioned \u0027volunteer\u0027 as one of our key priorities.","vi":"Giám đốc đã đề cập đến \u0027làm tình nguyện / tình nguyện viên\u0027 như một trong những ưu tiên hàng đầu của chúng tôi."}
  ],
  "Vote": [
    {"en":"Our team strives to vote high quality standards in every product.","vi":"Đội ngũ của chúng tôi luôn nỗ lực bỏ phiếu, bình chọn các tiêu chuẩn chất lượng cao trong từng sản phẩm."}
  ],
  "Voucher": [
    {"en":"The client expressed great interest in our strategy for voucher.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với phiếu mua hàng, phiếu giảm giá."}
  ],
  "Waive": [
    {"en":"They intend to waive the project schedule to accommodate client requests.","vi":"Họ có ý định từ bỏ, miễn (phí) lịch trình dự án để đáp ứng các yêu cầu của khách hàng."}
  ],
  "Walkway": [
    {"en":"Our team will host a seminar to address issues concerning walkway.","vi":"Đội ngũ của chúng tôi sẽ tổ chức hội thảo để giải quyết các vấn đề liên quan đến lối đi bộ."}
  ],
  "Warehouse": [
    {"en":"Ensure that all safety standards regarding the warehouse are strictly met.","vi":"Hãy đảm bảo rằng mọi tiêu chuẩn an toàn về nhà kho đều được tuân thủ nghiêm ngặt."}
  ],
  "Warranty": [
    {"en":"The executive team will discuss the proposed warranty during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về sự bảo hành được đề xuất trong cuộc họp ngày mai."}
  ],
  "Watery": [
    {"en":"The manager praised her for providing a very watery solution to the problem.","vi":"Quản lý đã khen ngợi cô ấy vì đã đưa ra một giải pháp rất lõng bõng nước, nhạt cho vấn đề."}
  ],
  "Weigh": [
    {"en":"We plan to weigh the new guidelines across all regional offices.","vi":"Chúng tôi dự định cân, có trọng lượng các hướng dẫn mới tại tất cả các văn phòng khu vực."}
  ],
  "Whimsical": [
    {"en":"We are looking for a whimsical approach to handle the rising workload.","vi":"Chúng tôi đang tìm kiếm một phương pháp bất thường, kỳ dị, hay thay đổi để xử lý khối lượng công việc đang tăng lên."}
  ],
  "Whisper": [
    {"en":"The supervisor asked us to whisper the team on the latest updates.","vi":"Người giám sát đã yêu cầu chúng tôi thì thầm cho cả đội về những cập nhật mới nhất."}
  ],
  "Wholesaler": [
    {"en":"Please send all relevant documents related to the wholesaler by Friday.","vi":"Vui lòng gửi tất cả các tài liệu liên quan đến nhà bán buôn trước thứ Sáu."}
  ],
  "Wildlife": [
    {"en":"The client expressed great interest in our strategy for wildlife.","vi":"Khách hàng đã tỏ ra rất quan tâm đến chiến lược của chúng tôi đối với động vật hoang dã."}
  ],
  "Wing": [
    {"en":"We noticed a significant change in the overall wing last month.","vi":"Chúng tôi ghi nhận một sự thay đổi đáng kể về chái nhà, khu vực phụ (của tòa nhà) trong tháng trước."}
  ],
  "Withdraw": [
    {"en":"Could you help me withdraw these figures for the upcoming presentation?","vi":"Bạn có thể giúp tôi rút tiền, rút lui những số liệu này cho buổi thuyết trình sắp tới không?"}
  ],
  "Withhold": [
    {"en":"It is critical that we withhold all regulatory requirements strictly.","vi":"Điều quan trọng là chúng ta phải giữ lại, từ chối cho tất cả các yêu cầu quy định một cách nghiêm ngặt."}
  ],
  "Workplace": [
    {"en":"The executive team will discuss the proposed workplace during tomorrow\u0027s meeting.","vi":"Ban điều hành sẽ thảo luận về nơi làm việc được đề xuất trong cuộc họp ngày mai."}
  ],
  "Workstation": [
    {"en":"We are currently reviewing the updated policies regarding workstation.","vi":"Chúng tôi hiện đang xem lại các chính sách cập nhật liên quan đến khu vực làm việc, bàn làm việc."}
  ],
  "Worth": [
    {"en":"It is important to keep all official documentation worth and well organized.","vi":"Điều quan trọng là phải giữ cho tất cả hồ sơ chính thức đáng giá, có giá trị và được sắp xếp gọn gàng."}
  ],
  "Yield": [
    {"en":"Could you provide more details about the yield mentioned in the email?","vi":"Bạn có thể cung cấp thêm thông tin chi tiết về sản lượng được đề cập trong email không?"}
  ],
  "Youth": [
    {"en":"Having a clear understand of youth is essential for this project.","vi":"Hiểu rõ về tuổi trẻ, thanh xuân là điều cần thiết cho dự án này."}
  ]
};



// =========================================================================================
// SMART DYNAMIC GENERATOR (16+ Ngữ cảnh phong phú khác nhau, tránh mọi sự rập khuôn)
// =========================================================================================

// Băm từ vựng để mỗi từ luôn có bộ mẫu câu khác biệt, tự nhiên
function hashWord(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

const verbPatterns = [
  [
    (w, m) => ({ en: `Staff members were encouraged to ${w} during the workshop.`, vi: `Các nhân viên được khuyến khích ${m} trong suốt buổi hội thảo.` }),
    (w, m) => ({ en: `Can you show me how to ${w} properly?`, vi: `Bạn có thể chỉ cho tôi cách ${m} sao cho đúng không?` })
  ],
  [
    (w, m) => ({ en: `We plan to ${w} before the fiscal year ends.`, vi: `Chúng tôi dự định ${m} trước khi năm tài chính kết thúc.` }),
    (w, m) => ({ en: `Learning how to ${w} effectively will save you time.`, vi: `Học cách ${m} một cách hiệu quả sẽ giúp bạn tiết kiệm thời gian.` })
  ],
  [
    (w, m) => ({ en: `Did the supervisor instruct you to ${w} today?`, vi: `Người giám sát có hướng dẫn bạn ${m} hôm nay không?` }),
    (w, m) => ({ en: `Take your time to ${w} without rushing.`, vi: `Hãy thong thả ${m} mà không cần phải vội vã.` })
  ],
  [
    (w, m) => ({ en: `They gathered in the hall to ${w} together.`, vi: `Họ đã tập trung tại hội trường để cùng nhau ${m}.` }),
    (w, m) => ({ en: `It takes dedication to ${w} consistently each week.`, vi: `Cần có sự kiên trì để ${m} đều đặn mỗi tuần.` })
  ],
  [
    (w, m) => ({ en: `Customers appreciate it when we ${w} promptly.`, vi: `Khách hàng đánh giá rất cao khi chúng ta ${m} một cách kịp thời.` }),
    (w, m) => ({ en: `She helped the new intern ${w} step by step.`, vi: `Cô ấy đã hướng dẫn thực tập sinh mới ${m} từng bước một.` })
  ],
  [
    (w, m) => ({ en: `The team held an urgent briefing to ${w}.`, vi: `Toàn đội đã mở một cuộc họp nhanh để ${m}.` }),
    (w, m) => ({ en: `Never hesitate to ${w} whenever you encounter difficulties.`, vi: `Đừng bao giờ ngần ngại ${m} mỗi khi bạn gặp khó khăn.` })
  ]
];

const nounPatterns = [
  [
    (w, m) => ({ en: `A comprehensive guide about the ${w} is available online.`, vi: `Một cẩm nang toàn diện về ${m} hiện đã có trên mạng.` }),
    (w, m) => ({ en: `The conference focused on recent developments in ${w}.`, vi: `Hội nghị tập trung vào những phát triển gần đây trong ${m}.` })
  ],
  [
    (w, m) => ({ en: `The department invested in improving this ${w}.`, vi: `Bộ phận đã đầu tư nguồn lực vào việc nâng cấp ${m} này.` }),
    (w, m) => ({ en: `Please consult the manual for questions regarding the ${w}.`, vi: `Vui lòng tham khảo sách hướng dẫn nếu có thắc mắc về ${m}.` })
  ],
  [
    (w, m) => ({ en: `High quality ${w} plays a critical role in our success.`, vi: `${m} chất lượng cao đóng vai trò quyết định trong thành công của chúng ta.` }),
    (w, m) => ({ en: `They discussed the budget allocated for the ${w}.`, vi: `Họ đã thảo luận về khoản ngân sách được phân bổ cho ${m}.` })
  ],
  [
    (w, m) => ({ en: `Many clients praised the modern design of our ${w}.`, vi: `Nhiều khách hàng đã ngợi khen thiết kế hiện đại của ${m} chúng tôi.` }),
    (w, m) => ({ en: `Always inspect the ${w} before finalizing the shipment.`, vi: `Luôn kiểm tra ${m} cẩn thận trước khi hoàn tất việc giao hàng.` })
  ],
  [
    (w, m) => ({ en: `She brought forward an interesting perspective on ${w}.`, vi: `Cô ấy đã đưa ra một góc nhìn rất thú vị về ${m}.` }),
    (w, m) => ({ en: `Understanding the basics of this ${w} helps daily operations.`, vi: `Hiểu rõ những điểm cốt lõi của ${m} này sẽ giúp ích cho công việc vận hành hàng ngày.` })
  ]
];

const adjPatterns = [
  [
    (w, m) => ({ en: `Clients were impressed by our ${w} delivery standards.`, vi: `Khách hàng rất ấn tượng trước tiêu chuẩn giao hàng ${m} của chúng tôi.` }),
    (w, m) => ({ en: `Try to maintain a ${w} attitude during challenging meetings.`, vi: `Hãy cố gắng duy trì một thái độ ${m} trong các cuộc họp đầy thử thách.` })
  ],
  [
    (w, m) => ({ en: `The brochure highlights several ${w} features of the product.`, vi: `Tờ rơi nêu bật một số tính năng ${m} của dòng sản phẩm.` }),
    (w, m) => ({ en: `Living in a ${w} neighborhood brings peace of mind.`, vi: `Sống trong một khu dân cư ${m} mang lại sự an tâm thoải mái.` })
  ],
  [
    (w, m) => ({ en: `Engineers designed a remarkably ${w} device for commuters.`, vi: `Các kỹ sư đã thiết kế một thiết bị ${m} đáng kinh ngạc cho người đi làm.` }),
    (w, m) => ({ en: `The atmosphere in the studio felt warm and ${w}.`, vi: `Bầu không khí trong phòng thu tạo cảm giác ấm áp và ${m}.` })
  ],
  [
    (w, m) => ({ en: `Finding a ${w} solution pleased everyone on the committee.`, vi: `Việc tìm ra một giải pháp ${m} đã làm hài lòng tất cả mọi người trong ủy ban.` }),
    (w, m) => ({ en: `His explanation was clear, structured, and ${w}.`, vi: `Lời giải thích của anh ấy rất rõ ràng, mạch lạc và ${m}.` })
  ]
];

const advPatterns = [
  [
    (w, m) => ({ en: `The machinery operated ${w} throughout the test run.`, vi: `Hệ thống máy móc đã vận hành một cách ${m} trong suốt đợt chạy thử nghiệm.` }),
    (w, m) => ({ en: `She spoke ${w} to ensure all listeners understood.`, vi: `Cô ấy nói một cách ${m} để đảm bảo mọi thính giả đều hiểu rõ.` })
  ],
  [
    (w, m) => ({ en: `Orders are packed ${w} to avoid accidental damage.`, vi: `Đơn hàng được đóng gói một cách ${m} nhằm tránh hư hỏng ngoài ý muốn.` }),
    (w, m) => ({ en: `The event coordinator handled the schedule changes ${w}.`, vi: `Người điều phối sự kiện đã xử lý các thay đổi lịch trình một cách ${m}.` })
  ],
  [
    (w, m) => ({ en: `Trains arrive ${w} according to the updated timetable.`, vi: `Tàu hỏa đến nơi một cách ${m} theo đúng lịch trình mới cập nhật.` }),
    (w, m) => ({ en: `He listened ${w} before offering his thoughtful advice.`, vi: `Anh ấy đã lắng nghe một cách ${m} trước khi đưa ra lời khuyên sâu sắc.` })
  ]
];

const phrasePatterns = [
  [
    (w, m) => ({ en: `You will frequently hear "${w}" in business conferences.`, vi: `Bạn sẽ thường xuyên nghe thấy "${w}" (${m}) trong các hội nghị kinh doanh.` }),
    (w, m) => ({ en: `Remember the practical context of "${w}" when speaking.`, vi: `Hãy ghi nhớ ngữ cảnh thực tế của "${w}" (${m}) khi giao tiếp.` })
  ],
  [
    (w, m) => ({ en: `Using "${w}" makes your communication sound natural.`, vi: `Sử dụng "${w}" (${m}) sẽ giúp cách diễn đạt của bạn tự nhiên hơn.` }),
    (w, m) => ({ en: `The teacher highlighted "${w}" as a key expression.`, vi: `Giáo viên đã nhấn mạnh "${w}" (${m}) như một cách diễn đạt trọng tâm.` })
  ]
];

/**
 * Trả về 2 câu ví dụ thực tế cho bất kỳ từ vựng nào.
 * Ưu tiên ví dụ tuyển chọn chi tiết; nếu sinh tự động thì dùng 16+ ngữ cảnh phong phú, biến thiên theo hash của từng từ.
 */
function getExamplesForWord(word, type, meaning) {
  if (!word) return [];
  const cleanWord = word.trim();

  // 1. Kiểm tra kho curated examples được biên soạn riêng
  if (curatedExamples[cleanWord]) {
    return curatedExamples[cleanWord];
  }
  
  // 2. Chuẩn bị thông tin từ và nghĩa
  const lowerWord = cleanWord.toLowerCase();
  let cleanMeaning = (meaning || '').replace(/^["']|["']$/g, '').trim();
  if (cleanMeaning.includes('/')) {
    cleanMeaning = cleanMeaning.split('/')[0].trim();
  }
  cleanMeaning = cleanMeaning.toLowerCase();

  const typeStr = (type || '').toLowerCase();
  const hash = hashWord(cleanWord);

  // 3. Phân luồng sinh câu theo loại từ với nhiều ngữ cảnh đa dạng
  if (typeStr.includes('động từ') || typeStr.includes('verb')) {
    const pair = verbPatterns[hash % verbPatterns.length];
    return [pair[0](lowerWord, cleanMeaning), pair[1](lowerWord, cleanMeaning)];
  } else if (typeStr.includes('danh từ') || typeStr.includes('noun')) {
    const pair = nounPatterns[hash % nounPatterns.length];
    return [pair[0](lowerWord, cleanMeaning), pair[1](lowerWord, cleanMeaning)];
  } else if (typeStr.includes('tính từ') || typeStr.includes('adj')) {
    const pair = adjPatterns[hash % adjPatterns.length];
    return [pair[0](lowerWord, cleanMeaning), pair[1](lowerWord, cleanMeaning)];
  } else if (typeStr.includes('trạng từ') || typeStr.includes('adv')) {
    const pair = advPatterns[hash % advPatterns.length];
    return [pair[0](lowerWord, cleanMeaning), pair[1](lowerWord, cleanMeaning)];
  } else {
    const pair = phrasePatterns[hash % phrasePatterns.length];
    return [pair[0](cleanWord, cleanMeaning), pair[1](cleanWord, cleanMeaning)];
  }
}
