class App {
  constructor() {
    this.data = window.COLLOCATIONS_DATA || [];
    this.filteredData = [...this.data];
    this.cardsContainer = document.getElementById('cards-grid');
    this.searchInput = document.getElementById('search-input');
    this.categorySelect = document.getElementById('category-filter');
    this.statTotalCount = document.getElementById('stat-total-count');

    this.initTabs();
    this.initCategories();
    this.initSearch();
    this.renderCards();

    // Khởi tạo Quiz Game
    this.quiz = new window.QuizGame();
  }

  initTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const targetTab = btn.getAttribute('data-tab');

        tabBtns.forEach(b => b.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));

        btn.classList.add('active');
        document.getElementById(`tab-${targetTab}`).classList.add('active');
      });
    });
  }

  initCategories() {
    const categories = ['All', ...new Set(this.data.map(item => item.category))];
    this.categorySelect.innerHTML = categories
      .map(cat => `<option value="${cat}">${cat === 'All' ? 'Tất cả chủ đề' : cat}</option>`)
      .join('');

    this.categorySelect.addEventListener('change', () => this.handleFilter());
  }

  initSearch() {
    this.searchInput.addEventListener('input', () => this.handleFilter());
  }

  handleFilter() {
    const query = this.searchInput.value.trim().toLowerCase();
    const selectedCat = this.categorySelect.value;

    this.filteredData = this.data.filter(item => {
      const matchCat = selectedCat === 'All' || item.category === selectedCat;
      const matchQuery =
        item.collocation.toLowerCase().includes(query) ||
        item.meaning_vi.toLowerCase().includes(query) ||
        (item.examples && item.examples.some(ex => ex.en.toLowerCase().includes(query) || ex.vi.toLowerCase().includes(query)));

      return matchCat && matchQuery;
    });

    this.renderCards();
  }

  highlightWord(sentence, collocation) {
    const regex = new RegExp(`(${collocation})`, 'gi');
    return sentence.replace(regex, '<span class="highlight">$1</span>');
  }

  renderCards() {
    this.statTotalCount.textContent = `${this.filteredData.length} cụm từ`;
    this.cardsContainer.innerHTML = '';

    if (this.filteredData.length === 0) {
      this.cardsContainer.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; color: #94a3b8;">
          Không tìm thấy cụm từ nào phù hợp với tìm kiếm của bạn.
        </div>
      `;
      return;
    }

    this.filteredData.forEach(item => {
      const card = document.createElement('div');
      card.className = 'colloc-card';

      const examplesHtml = item.examples
        .map(
          (ex, idx) => `
          <div class="example-item">
            <button class="btn-speak-sentence" title="Nghe luyện nói câu này" data-sentence="${ex.en.replace(/"/g, '&quot;')}">
              🗣️
            </button>
            <div class="example-content">
              <div class="ex-en" title="Bấm để nghe">${this.highlightWord(ex.en, item.collocation)}</div>
              <div class="ex-vi">👉 ${ex.vi}</div>
            </div>
          </div>
        `
        )
        .join('');

      card.innerHTML = `
        <div>
          <div class="colloc-header">
            <div>
              <span class="badge-type">${item.type}</span>
              <div class="colloc-title">
                ${item.collocation}
              </div>
            </div>
            <button class="btn-speak" title="Nghe phát âm cụm từ" data-word="${item.collocation}">
              🔊
            </button>
          </div>

          <div class="colloc-meaning">
             ${item.meaning_vi}
          </div>
          <div class="colloc-en-meaning">
             ${item.meaning_en}
          </div>
        </div>

        <div class="colloc-examples">
          <div style="font-size: 0.78rem; color: #38bdf8; font-weight: 700; margin-bottom: 0.3rem; letter-spacing: 0.5px;">
            🎙️ MẪU CÂU THỰC HÀNH GIAO TIẾP (${item.examples.length} câu):
          </div>
          ${examplesHtml}
        </div>
      `;

      // Phát âm cả cụm từ
      const speakBtn = card.querySelector('.btn-speak');
      speakBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (window.sounds) window.sounds.speakEnglish(item.collocation);
      });

      // Phát âm từng câu ví dụ để luyện nói
      const sentenceBtns = card.querySelectorAll('.btn-speak-sentence');
      sentenceBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const sentence = btn.getAttribute('data-sentence');
          if (window.sounds) window.sounds.speakEnglish(sentence);
        });
      });

      // Click trực tiếp vào dòng tiếng Anh cũng phát âm
      const enLines = card.querySelectorAll('.ex-en');
      enLines.forEach((line, i) => {
        line.addEventListener('click', () => {
          if (item.examples[i] && window.sounds) {
            window.sounds.speakEnglish(item.examples[i].en);
          }
        });
      });

      this.cardsContainer.appendChild(card);
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new App();
});
