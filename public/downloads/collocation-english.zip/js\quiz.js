class QuizGame {
  constructor() {
    this.questions = [];
    this.currentIndex = 0;
    this.score = 0;
    this.streak = 0;
    this.maxStreak = 0;
    this.timerInterval = null;
    this.timeLeftMs = 10000;
    this.TOTAL_TIME_MS = 10000;
    this.isAnswered = false;
    this.correctCount = 0;

    // Elements
    this.screenStart = document.getElementById('quiz-screen-start');
    this.screenPlay = document.getElementById('quiz-screen-play');
    this.screenResult = document.getElementById('quiz-screen-result');

    this.timerBar = document.getElementById('quiz-timer-bar');
    this.timerSeconds = document.getElementById('quiz-timer-seconds');
    this.scoreDisplay = document.getElementById('quiz-score-val');
    this.streakDisplay = document.getElementById('quiz-streak-val');
    this.questionCountDisplay = document.getElementById('quiz-q-count');

    this.meaningDisplay = document.getElementById('quiz-meaning');
    this.contextDisplay = document.getElementById('quiz-context');
    this.optionsContainer = document.getElementById('quiz-options');
    this.feedbackBox = document.getElementById('quiz-feedback');

    // Config Elements
    this.categorySelect = document.getElementById('quiz-category-select');
    this.countOptionsContainer = document.getElementById('quiz-count-options');
    this.availableCountDisplay = document.getElementById('quiz-available-count');
    this.selectedCount = 10; // mặc định 10 câu

    this.initEvents();
    this.initFilters();
  }

  initFilters() {
    const data = window.COLLOCATIONS_DATA || [];
    const categories = ['All', ...new Set(data.map(item => item.category))];

    if (this.categorySelect) {
      this.categorySelect.innerHTML = categories
        .map(cat => `<option value="${cat}">${cat === 'All' ? '🌟 Tất cả chủ đề' : cat}</option>`)
        .join('');

      this.categorySelect.addEventListener('change', () => this.updateAvailableCount());
    }

    if (this.countOptionsContainer) {
      const countBtns = this.countOptionsContainer.querySelectorAll('.btn-count-opt');
      countBtns.forEach(btn => {
        btn.addEventListener('click', () => {
          countBtns.forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const countVal = btn.getAttribute('data-count');
          this.selectedCount = countVal === 'all' ? 'all' : parseInt(countVal, 10);
        });
      });
    }

    this.updateAvailableCount();
  }

  updateAvailableCount() {
    const data = window.COLLOCATIONS_DATA || [];
    const selectedCat = this.categorySelect ? this.categorySelect.value : 'All';
    const filtered = data.filter(item => selectedCat === 'All' || item.category === selectedCat);

    if (this.availableCountDisplay) {
      this.availableCountDisplay.textContent = `Khả dụng: ${filtered.length} cụm từ trong chủ đề`;
    }
  }

  initEvents() {
    const btnStart = document.getElementById('btn-start-quiz');
    const btnRetry = document.getElementById('btn-retry-quiz');
    const btnReconfig = document.getElementById('btn-reconfig-quiz');

    if (btnStart) btnStart.addEventListener('click', () => this.startQuiz());
    if (btnRetry) btnRetry.addEventListener('click', () => this.startQuiz());
    if (btnReconfig) {
      btnReconfig.addEventListener('click', () => {
        this.screenResult.style.display = 'none';
        this.screenStart.style.display = 'block';
      });
    }
  }

  shuffle(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  startQuiz() {
    if (window.sounds) window.sounds.getAudioContext();

    const data = window.COLLOCATIONS_DATA || [];
    const selectedCat = this.categorySelect ? this.categorySelect.value : 'All';

    // Lọc theo chủ đề được chọn
    const pool = data.filter(item => selectedCat === 'All' || item.category === selectedCat);

    if (pool.length === 0) {
      alert('Không có cụm collocation nào trong chủ đề này!');
      return;
    }

    // Chọn số lượng câu hỏi
    const targetCount = this.selectedCount === 'all' ? pool.length : Math.min(this.selectedCount, pool.length);
    this.questions = this.shuffle(pool).slice(0, targetCount);

    this.currentIndex = 0;
    this.score = 0;
    this.streak = 0;
    this.maxStreak = 0;
    this.correctCount = 0;

    this.screenStart.style.display = 'none';
    this.screenResult.style.display = 'none';
    this.screenPlay.style.display = 'block';

    this.updateStatsUI();
    this.loadQuestion();
  }

  updateStatsUI() {
    this.scoreDisplay.textContent = this.score;
    this.streakDisplay.textContent = `🔥 ${this.streak}`;
    this.questionCountDisplay.textContent = `${this.currentIndex + 1}/${this.questions.length}`;
  }

  loadQuestion() {
    if (this.currentIndex >= this.questions.length) {
      this.finishQuiz();
      return;
    }

    this.isAnswered = false;
    this.feedbackBox.className = 'feedback-box';
    this.feedbackBox.style.display = 'none';

    const currentItem = this.questions[this.currentIndex];
    this.updateStatsUI();

    this.meaningDisplay.textContent = `"${currentItem.meaning_vi}"`;

    const ex = currentItem.examples && currentItem.examples.length > 0 ? currentItem.examples[0] : null;
    if (ex) {
      const maskedEn = ex.en.replace(new RegExp(currentItem.collocation, 'gi'), '_____');
      this.contextDisplay.textContent = `Gợi ý ngữ cảnh: ${maskedEn}`;
      this.contextDisplay.style.display = 'inline-block';
    } else {
      this.contextDisplay.style.display = 'none';
    }

    const data = window.COLLOCATIONS_DATA || [];
    const distractors = data.filter(item => item.id !== currentItem.id);
    const shuffledDistractors = this.shuffle(distractors).slice(0, 3);
    const options = this.shuffle([currentItem, ...shuffledDistractors]);

    this.optionsContainer.innerHTML = '';
    options.forEach(opt => {
      const btn = document.createElement('button');
      btn.className = 'option-btn';
      btn.innerHTML = `<span>${opt.collocation}</span>`;
      btn.addEventListener('click', () => this.handleAnswer(opt, btn, currentItem));
      this.optionsContainer.appendChild(btn);
    });

    this.startTimer(currentItem);
  }

  startTimer(currentItem) {
    clearInterval(this.timerInterval);
    this.timeLeftMs = this.TOTAL_TIME_MS;
    this.renderTimer();

    let lastTickSecond = 10;

    this.timerInterval = setInterval(() => {
      this.timeLeftMs -= 50;
      this.renderTimer();

      const sec = Math.ceil(this.timeLeftMs / 1000);
      if (sec !== lastTickSecond && sec <= 10 && sec > 0) {
        lastTickSecond = sec;
        if (window.sounds) window.sounds.playTick();
      }

      if (this.timeLeftMs <= 0) {
        clearInterval(this.timerInterval);
        this.handleTimeout(currentItem);
      }
    }, 50);
  }

  renderTimer() {
    const fraction = Math.max(0, this.timeLeftMs / this.TOTAL_TIME_MS);
    const pct = fraction * 100;
    this.timerBar.style.width = `${pct}%`;

    const sec = Math.max(0, Math.ceil(this.timeLeftMs / 1000));
    this.timerSeconds.textContent = `${sec}s`;

    if (sec <= 3) {
      this.timerSeconds.className = 'timer-seconds danger';
      this.timerBar.className = 'progress-fill danger';
    } else if (sec <= 6) {
      this.timerSeconds.className = 'timer-seconds';
      this.timerBar.className = 'progress-fill warning';
    } else {
      this.timerSeconds.className = 'timer-seconds';
      this.timerBar.className = 'progress-fill';
    }
  }

  handleAnswer(selectedItem, selectedBtn, currentItem) {
    if (this.isAnswered) return;
    this.isAnswered = true;
    clearInterval(this.timerInterval);

    const buttons = this.optionsContainer.querySelectorAll('.option-btn');
    buttons.forEach(b => (b.disabled = true));

    const isCorrect = selectedItem.id === currentItem.id;

    if (isCorrect) {
      selectedBtn.classList.add('correct');
      if (window.sounds) window.sounds.playCorrect();

      this.streak++;
      if (this.streak > this.maxStreak) this.maxStreak = this.streak;
      this.correctCount++;

      const timeBonus = Math.floor((this.timeLeftMs / 1000) * 10);
      const streakBonus = this.streak * 5;
      const earned = 100 + timeBonus + streakBonus;
      this.score += earned;

      this.showFeedback(true, currentItem, `Chính xác! +${earned} điểm`);
    } else {
      selectedBtn.classList.add('wrong');
      if (window.sounds) window.sounds.playWrong();
      this.streak = 0;

      buttons.forEach(b => {
        if (b.textContent.trim() === currentItem.collocation) {
          b.classList.add('correct');
        }
      });

      this.showFeedback(false, currentItem, `Chưa đúng rồi!`);
    }

    this.updateStatsUI();
    if (window.sounds) window.sounds.speakEnglish(currentItem.collocation);

    setTimeout(() => {
      this.currentIndex++;
      this.loadQuestion();
    }, 2200);
  }

  handleTimeout(currentItem) {
    if (this.isAnswered) return;
    this.isAnswered = true;

    if (window.sounds) window.sounds.playTimeout();
    this.streak = 0;
    this.updateStatsUI();

    const buttons = this.optionsContainer.querySelectorAll('.option-btn');
    buttons.forEach(b => {
      b.disabled = true;
      if (b.textContent.trim() === currentItem.collocation) {
        b.classList.add('correct');
      }
    });

    this.showFeedback(false, currentItem, `Hết 10 giây!`);
    if (window.sounds) window.sounds.speakEnglish(currentItem.collocation);

    setTimeout(() => {
      this.currentIndex++;
      this.loadQuestion();
    }, 2200);
  }

  showFeedback(isCorrect, item, message) {
    this.feedbackBox.className = `feedback-box ${isCorrect ? 'correct' : 'wrong'}`;
    const ex = item.examples && item.examples.length > 0 ? item.examples[0] : null;

    this.feedbackBox.innerHTML = `
      <div class="feedback-title">${isCorrect ? '✅' : '❌'} ${message}</div>
      <div class="feedback-example">
        <strong>${item.collocation}</strong>: ${item.meaning_vi}
        ${ex ? `<br><em>Mẫu câu:</em> "${ex.en}" (${ex.vi})` : ''}
      </div>
    `;
    this.feedbackBox.style.display = 'block';
  }

  finishQuiz() {
    clearInterval(this.timerInterval);
    this.screenPlay.style.display = 'none';
    this.screenResult.style.display = 'block';

    document.getElementById('result-final-score').textContent = this.score;
    document.getElementById('result-correct').textContent = `${this.correctCount}/${this.questions.length}`;
    document.getElementById('result-max-streak').textContent = this.maxStreak;
  }
}

window.QuizGame = QuizGame;
