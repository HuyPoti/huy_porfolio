const COLLOCATIONS_DATA = [
  // Chủ đề 1: Công việc & Học tập (Work & Study)
  {
    id: 1,
    collocation: "make a decision",
    type: "Verb + Noun",
    meaning_vi: "đưa ra quyết định",
    meaning_en: "to choose something after thinking about several possibilities",
    category: "Work & Study",
    examples: [
      {
        en: "We need to make a decision by tomorrow morning.",
        vi: "Chúng ta cần phải đưa ra quyết định trước sáng mai."
      },
      {
        en: "It's tough to make a decision without all the data.",
        vi: "Rất khó để đưa ra quyết định khi không có đủ dữ liệu."
      },
      {
        en: "Take your time, there is no rush to make a decision right now.",
        vi: "Cứ thong thả, không cần vội đưa ra quyết định ngay lúc này đâu."
      },
      {
        en: "Have you made a decision about which university to attend?",
        vi: "Cậu đã đưa ra quyết định sẽ học trường đại học nào chưa?"
      }
    ]
  },
  {
    id: 2,
    collocation: "meet a deadline",
    type: "Verb + Noun",
    meaning_vi: "kịp hạn chót, hoàn thành đúng hạn",
    meaning_en: "to finish something at or before the required time",
    category: "Work & Study",
    examples: [
      {
        en: "Everyone worked overtime to meet the tight deadline.",
        vi: "Mọi người đã làm thêm giờ để kịp hạn chót gấp gáp."
      },
      {
        en: "Can we still meet the deadline if we skip this step?",
        vi: "Liệu chúng ta có kịp hạn chót không nếu bỏ qua bước này?"
      },
      {
        en: "I'm under a lot of pressure to meet this deadline.",
        vi: "Tôi đang chịu rất nhiều áp lực để hoàn thành kịp hạn chót này."
      },
      {
        en: "If you need extra help to meet the deadline, just let me know.",
        vi: "Nếu cậu cần thêm người hỗ trợ để kịp deadline, cứ bảo mình nhé."
      }
    ]
  },
  {
    id: 3,
    collocation: "gain experience",
    type: "Verb + Noun",
    meaning_vi: "tích lũy kinh nghiệm",
    meaning_en: "to get knowledge or skill from doing something",
    category: "Work & Study",
    examples: [
      {
        en: "This internship is a great opportunity to gain hands-on experience.",
        vi: "Kỳ thực tập này là cơ hội tuyệt vời để tích lũy kinh nghiệm thực tế."
      },
      {
        en: "Volunteering is a great way to gain experience and build connections.",
        vi: "Làm tình nguyện là cách tuyệt vời để tích lũy kinh nghiệm và xây dựng mối quan hệ."
      },
      {
        en: "She gained valuable experience working with international clients.",
        vi: "Cô ấy đã tích lũy được nhiều kinh nghiệm quý báu khi làm việc với khách hàng quốc tế."
      }
    ]
  },
  {
    id: 4,
    collocation: "pay attention",
    type: "Verb + Noun",
    meaning_vi: "chú ý, tập trung để ý",
    meaning_en: "to watch, listen to, or think about something carefully",
    category: "Work & Study",
    examples: [
      {
        en: "Please pay close attention to the instructions on screen.",
        vi: "Xin vui lòng chú ý kỹ các hướng dẫn hiển thị trên màn hình."
      },
      {
        en: "Sorry, I wasn't paying attention. Could you repeat that?",
        vi: "Xin lỗi, lúc nãy mình không để ý. Cậu nhắc lại được không?"
      },
      {
        en: "You need to pay attention when driving in heavy rain.",
        vi: "Bạn cần phải hết sức chú ý khi lái xe dưới trời mưa to."
      }
    ]
  },
  {
    id: 5,
    collocation: "take notes",
    type: "Verb + Noun",
    meaning_vi: "ghi chép nhanh, ghi chú lại",
    meaning_en: "to write down information to help you remember it",
    category: "Work & Study",
    examples: [
      {
        en: "Don't forget to take notes during the presentation.",
        vi: "Đừng quên ghi chép lại trong suốt buổi thuyết trình."
      },
      {
        en: "I always take notes during team meetings so I don't miss action items.",
        vi: "Tôi luôn ghi chú trong các cuộc họp nhóm để không bỏ sót đầu việc cần làm."
      },
      {
        en: "Can I borrow your notebook? I forgot to take notes today.",
        vi: "Cho mình mượn cuốn sổ được không? Hôm nay mình quên ghi chép rồi."
      }
    ]
  },
  {
    id: 6,
    collocation: "bear in mind",
    type: "Verb + Preposition + Noun",
    meaning_vi: "ghi nhớ trong đầu, khắc ghi",
    meaning_en: "to remember a piece of information when you are making decisions",
    category: "Work & Study",
    examples: [
      {
        en: "Bear in mind that prices may vary depending on the season.",
        vi: "Hãy nhớ rằng giá cả có thể thay đổi tùy thuộc vào mùa."
      },
      {
        en: "Bear in mind that Rome wasn't built in a day; be patient.",
        vi: "Hãy nhớ rằng thành công cần có thời gian; hãy kiên nhẫn."
      },
      {
        en: "Please bear in mind that the office will be closed on Friday.",
        vi: "Xin hãy lưu ý rằng văn phòng sẽ đóng cửa vào thứ Sáu."
      }
    ]
  },
  {
    id: 7,
    collocation: "draw a conclusion",
    type: "Verb + Noun",
    meaning_vi: "rút ra kết luận",
    meaning_en: "to consider the facts of a situation and make a decision about what is true",
    category: "Work & Study",
    examples: [
      {
        en: "It's too early to draw any definite conclusions from this test.",
        vi: "Còn quá sớm để rút ra bất kỳ kết luận dứt khoát nào từ thử nghiệm này."
      },
      {
        en: "What conclusion did you draw after reading the report?",
        vi: "Bạn đã rút ra được kết luận gì sau khi đọc bản báo cáo?"
      },
      {
        en: "Don't jump to conclusions before hearing both sides of the story.",
        vi: "Đừng vội vàng rút ra kết luận trước khi lắng nghe câu chuyện từ cả hai phía."
      }
    ]
  },

  // Chủ đề 2: Đời sống & Thói quen hàng ngày (Daily Habits & Routine)
  {
    id: 8,
    collocation: "catch a cold",
    type: "Verb + Noun",
    meaning_vi: "bị cảm lạnh",
    meaning_en: "to become sick with a common cold",
    category: "Daily Life",
    examples: [
      {
        en: "Put on your jacket or you'll catch a cold.",
        vi: "Mặc áo khoác vào không thì bạn sẽ bị cảm lạnh đấy."
      },
      {
        en: "I think I caught a cold after getting soaked in the rain yesterday.",
        vi: "Hình như tôi bị cảm lạnh sau khi dầm mưa hôm qua rồi."
      },
      {
        en: "Drink some hot ginger tea whenever you feel like you're catching a cold.",
        vi: "Hãy uống chút trà gừng nóng bất cứ khi nào bạn cảm thấy mình sắp bị cảm lạnh."
      }
    ]
  },
  {
    id: 9,
    collocation: "break a habit",
    type: "Verb + Noun",
    meaning_vi: "từ bỏ một thói quen",
    meaning_en: "to stop doing something that you do regularly",
    category: "Daily Life",
    examples: [
      {
        en: "It takes about 21 days to break an old habit.",
        vi: "Mất khoảng 21 ngày để từ bỏ một thói quen cũ."
      },
      {
        en: "Breaking a bad habit like staying up late is hard but worth it.",
        vi: "Bỏ thói quen xấu như thức khuya tuy khó nhưng rất xứng đáng."
      },
      {
        en: "How did you manage to break the habit of biting your nails?",
        vi: "Làm thế nào mà cậu từ bỏ được thói quen cắn móng tay vậy?"
      }
    ]
  },
  {
    id: 10,
    collocation: "make an effort",
    type: "Verb + Noun",
    meaning_vi: "nỗ lực, cố gắng",
    meaning_en: "to try hard to do something",
    category: "Daily Life",
    examples: [
      {
        en: "You should make an effort to exercise at least 30 minutes a day.",
        vi: "Bạn nên cố gắng tập thể dục ít nhất 30 phút mỗi ngày."
      },
      {
        en: "He really made an effort to speak Vietnamese with the locals.",
        vi: "Anh ấy đã rất nỗ lực để nói tiếng Việt với người bản xứ."
      },
      {
        en: "Even if you fail, at least you made an honest effort.",
        vi: "Dù có thất bại, ít nhất bạn cũng đã nỗ lực hết mình."
      }
    ]
  },
  {
    id: 11,
    collocation: "save time",
    type: "Verb + Noun",
    meaning_vi: "tiết kiệm thời gian",
    meaning_en: "to do something more quickly or prevent wasting time",
    category: "Daily Life",
    examples: [
      {
        en: "Taking the subway will save you a lot of time during rush hour.",
        vi: "Đi tàu điện ngầm sẽ giúp bạn tiết kiệm được nhiều thời gian trong giờ cao điểm."
      },
      {
        en: "Ordering groceries online helps me save a ton of time each week.",
        vi: "Đặt đồ tạp hóa online giúp tôi tiết kiệm hàng đống thời gian mỗi tuần."
      },
      {
        en: "To save time, we can discuss this quickly over a video call.",
        vi: "Để tiết kiệm thời gian, chúng mình có thể trao đổi nhanh qua cuộc gọi video."
      }
    ]
  },
  {
    id: 12,
    collocation: "have a seat",
    type: "Verb + Noun",
    meaning_vi: "ngồi xuống, an tọa",
    meaning_en: "polite invitation to sit down",
    category: "Daily Life",
    examples: [
      {
        en: "Please have a seat, the doctor will see you in a minute.",
        vi: "Xin mời ngồi, bác sĩ sẽ gặp bạn trong giây lát."
      },
      {
        en: "Welcome to our office! Come in and have a seat.",
        vi: "Chào mừng bạn đến văn phòng của chúng tôi! Mời vào và ngồi xuống nhé."
      },
      {
        en: "Would you like to have a seat while waiting for your order?",
        vi: "Quý khách có muốn ngồi chờ trong lúc chuẩn bị món không ạ?"
      }
    ]
  },
  {
    id: 13,
    collocation: "run out of",
    type: "Phrasal Verb",
    meaning_vi: "hết, cạn kiệt (tiền, xăng, pin, sữa,...)",
    meaning_en: "to have no more of something left",
    category: "Daily Life",
    examples: [
      {
        en: "My phone just ran out of battery on my way home.",
        vi: "Điện thoại của tôi vừa bị hết pin trên đường về nhà."
      },
      {
        en: "We've run out of milk, can you pick some up?",
        vi: "Nhà mình hết sữa rồi, bạn mua hộ ít nhé?"
      },
      {
        en: "We ran out of time before we could finish all the agenda items.",
        vi: "Chúng tôi đã hết thời gian trước khi kịp bàn hết các mục trong lịch trình."
      },
      {
        en: "I'm running out of patience with this slow internet connection.",
        vi: "Tôi sắp hết kiên nhẫn với đường truyền mạng chậm rì này rồi."
      }
    ]
  },
  {
    id: 14,
    collocation: "take a break",
    type: "Verb + Noun",
    meaning_vi: "nghỉ ngơi một lát",
    meaning_en: "to stop working for a short period of time to relax",
    category: "Daily Life",
    examples: [
      {
        en: "Let's take a 10-minute break for coffee.",
        vi: "Hãy nghỉ giải lao 10 phút uống cà phê nào."
      },
      {
        en: "You've been staring at the computer screen for hours, go take a break!",
        vi: "Cậu nhìn màn hình máy tính hàng tiếng rồi đấy, đi nghỉ một lát đi!"
      },
      {
        en: "I'm exhausted; I really need to take a break this weekend.",
        vi: "Tôi kiệt sức rồi; cuối tuần này tôi thực sự cần được nghỉ ngơi."
      }
    ]
  },
  {
    id: 15,
    collocation: "keep in touch",
    type: "Phrase",
    meaning_vi: "giữ liên lạc",
    meaning_en: "to maintain communication with someone",
    category: "Daily Life",
    examples: [
      {
        en: "It was so nice seeing you! Let's keep in touch.",
        vi: "Rất vui được gặp bạn! Hãy giữ liên lạc nhé."
      },
      {
        en: "Even though we live in different countries, we still keep in touch regularly.",
        vi: "Dù sống ở hai quốc gia khác nhau, chúng tôi vẫn giữ liên lạc thường xuyên."
      },
      {
        en: "Here is my business card, make sure to keep in touch!",
        vi: "Đây là danh thiếp của tôi, nhớ giữ liên lạc nhé!"
      }
    ]
  },

  // Chủ đề 3: Giao tiếp & Mối quan hệ (Social & Relationships)
  {
    id: 16,
    collocation: "make sense",
    type: "Verb + Noun",
    meaning_vi: "hợp lý, dễ hiểu, có ý nghĩa",
    meaning_en: "to be clear, logical, or understandable",
    category: "Social & Chat",
    examples: [
      {
        en: "Does that explanation make sense to you?",
        vi: "Lời giải thích đó có dễ hiểu đối với bạn không?"
      },
      {
        en: "It doesn't make sense to spend money on things you don't need.",
        vi: "Thật vô lý khi tiêu tiền vào những thứ bạn không cần."
      },
      {
        en: "Now that you explain it that way, it totally makes sense.",
        vi: "Giờ bạn giải thích thế thì nghe hoàn toàn hợp lý rồi."
      },
      {
        en: "What he just said didn't make any sense at all.",
        vi: "Những gì anh ta vừa nói chẳng có tí hợp lý nào cả."
      }
    ]
  },
  {
    id: 17,
    collocation: "break the ice",
    type: "Idiom",
    meaning_vi: "phá vỡ bầu không khí ngại ngùng ban đầu",
    meaning_en: "to make people feel more comfortable in a social setting",
    category: "Social & Chat",
    examples: [
      {
        en: "He told a funny joke to break the ice at the party.",
        vi: "Anh ấy kể một câu chuyện cười để phá tan bầu không khí ngại ngùng trong bữa tiệc."
      },
      {
        en: "Playing an interactive mini-game is a wonderful way to break the ice.",
        vi: "Chơi một trò chơi tương tác nhỏ là cách tuyệt vời để phá tan sự ngại ngùng ban đầu."
      },
      {
        en: "Asking someone about their hobbies can easily break the ice.",
        vi: "Hỏi ai đó về sở thích của họ có thể dễ dàng xóa tan khoảng cách ngại ngùng."
      }
    ]
  },
  {
    id: 18,
    collocation: "tell the truth",
    type: "Verb + Noun",
    meaning_vi: "nói thật, nói sự thật",
    meaning_en: "to say what is real and true, not lying",
    category: "Social & Chat",
    examples: [
      {
        en: "To tell the truth, I didn't really enjoy the movie.",
        vi: "Thành thật mà nói, tôi không thực sự thích bộ phim đó lắm."
      },
      {
        en: "Promise me that you will always tell the truth.",
        vi: "Hãy hứa với mình là cậu sẽ luôn nói sự thật nhé."
      },
      {
        en: "It takes great courage to tell the truth in difficult situations.",
        vi: "Cần rất nhiều lòng can đảm để nói sự thật trong những tình huống khó khăn."
      }
    ]
  },
  {
    id: 19,
    collocation: "catch up with",
    type: "Phrasal Verb",
    meaning_vi: "gặp gỡ hàn huyên, cập nhật tin tức của nhau",
    meaning_en: "to talk to someone you have not seen for some time to find out what they have been doing",
    category: "Social & Chat",
    examples: [
      {
        en: "We should catch up with each other over lunch this weekend.",
        vi: "Cuối tuần này chúng mình đi ăn trưa rồi hàn huyên tâm sự nhé."
      },
      {
        en: "I haven't seen you in ages! We really need to catch up soon.",
        vi: "Lâu lắm rồi không gặp cậu! Chúng mình thật sự phải sớm gặp nhau hàn huyên thôi."
      },
      {
        en: "Let's grab a coffee tomorrow and catch up on everything.",
        vi: "Ngày mai đi uống cà phê rồi kể cho nhau nghe mọi chuyện nhé."
      }
    ]
  },
  {
    id: 20,
    collocation: "give a hand",
    type: "Verb + Noun",
    meaning_vi: "giúp đỡ một tay",
    meaning_en: "to help someone with something",
    category: "Social & Chat",
    examples: [
      {
        en: "Could you give me a hand moving these heavy boxes?",
        vi: "Bạn có thể giúp tôi một tay chuyển mấy chiếc hộp nặng này được không?"
      },
      {
        en: "I'd be more than happy to give you a hand with cooking.",
        vi: "Mình rất sẵn lòng phụ bạn một tay nấu nướng."
      },
      {
        en: "Whenever someone is struggling, don't hesitate to give them a hand.",
        vi: "Bất cứ khi nào thấy ai gặp khó khăn, đừng ngần ngại giúp họ một tay."
      }
    ]
  },
  {
    id: 21,
    collocation: "make an apology",
    type: "Verb + Noun",
    meaning_vi: "đưa ra lời xin lỗi",
    meaning_en: "to say sorry to someone for doing something wrong",
    category: "Social & Chat",
    examples: [
      {
        en: "He made a sincere apology for his rude behavior.",
        vi: "Anh ấy đã đưa ra lời xin lỗi chân thành vì hành vi khiếm nhã của mình."
      },
      {
        en: "You owe her a sincere apology after what happened.",
        vi: "Cậu nợ cô ấy một lời xin lỗi chân thành sau những gì đã xảy ra đấy."
      },
      {
        en: "Making an apology is the first step toward fixing a relationship.",
        vi: "Đưa ra lời xin lỗi là bước đầu tiên để hàn gắn một mối quan hệ."
      }
    ]
  },
  {
    id: 22,
    collocation: "keep a promise",
    type: "Verb + Noun",
    meaning_vi: "giữ lời hứa",
    meaning_en: "to do what you said you would do",
    category: "Social & Chat",
    examples: [
      {
        en: "If you make a commitment, always keep your promise.",
        vi: "Nếu bạn đã cam kết, hãy luôn giữ đúng lời hứa của mình."
      },
      {
        en: "I trust him completely because he always keeps his promises.",
        vi: "Tôi hoàn toàn tin tưởng anh ấy vì anh ấy luôn giữ lời hứa."
      },
      {
        en: "It's better not to promise anything than to make a promise and break it.",
        vi: "Thà không hứa còn hơn là hứa rồi thất hứa."
      }
    ]
  },
  {
    id: 23,
    collocation: "lose touch with",
    type: "Phrase",
    meaning_vi: "mất liên lạc với ai đó",
    meaning_en: "to no longer communicate with someone",
    category: "Social & Chat",
    examples: [
      {
        en: "I unfortunately lost touch with my college roommate.",
        vi: "Thật tiếc là tôi đã mất liên lạc với bạn cùng phòng thời đại học."
      },
      {
        en: "After moving abroad, it's very easy to lose touch with old friends.",
        vi: "Sau khi ra nước ngoài định cư, rất dễ bị mất liên lạc với những người bạn cũ."
      },
      {
        en: "I don't want us to lose touch after graduation.",
        vi: "Mình không muốn chúng ta mất liên lạc sau khi tốt nghiệp đâu."
      }
    ]
  },

  // Chủ đề 4: Cảm xúc & Ý kiến (Emotions & Opinions)
  {
    id: 24,
    collocation: "change your mind",
    type: "Verb + Noun",
    meaning_vi: "đổi ý, thay đổi quyết định",
    meaning_en: "to adopt a different opinion or plan",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "If you change your mind, let me know before 5 PM.",
        vi: "Nếu bạn đổi ý, hãy báo cho tôi biết trước 5 giờ chiều nhé."
      },
      {
        en: "I was planning to stay home, but I changed my mind and went out.",
        vi: "Ban đầu tôi định ở nhà, nhưng sau đó đã đổi ý và đi chơi."
      },
      {
        en: "It is totally okay to change your mind after discovering new facts.",
        vi: "Hoàn toàn bình thường khi bạn thay đổi quyết định sau khi biết thêm dữ kiện mới."
      }
    ]
  },
  {
    id: 25,
    collocation: "lose temper",
    type: "Verb + Noun",
    meaning_vi: "mất bình tĩnh, nổi nóng",
    meaning_en: "to become suddenly angry",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "Try to stay calm and don't lose your temper during negotiations.",
        vi: "Hãy cố gắng giữ bình tĩnh và đừng nổi nóng trong lúc đàm phán."
      },
      {
        en: "He rarely loses his temper, so he must have been really upset.",
        vi: "Anh ấy rất hiếm khi nổi nóng, nên chắc hẳn là anh ấy đã rất buồn bực."
      },
      {
        en: "I apologize for losing my temper earlier; I was just stressed out.",
        vi: "Tôi xin lỗi vì lúc nãy đã nổi nóng; tôi chỉ là bị căng thẳng quá thôi."
      }
    ]
  },
  {
    id: 26,
    collocation: "feel like",
    type: "Verb + Preposition",
    meaning_vi: "thấy muốn làm gì, có hứng làm gì",
    meaning_en: "to have a desire or wish for something",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "I don't feel like cooking tonight, let's order pizza.",
        vi: "Tối nay tôi không có hứng nấu ăn, đặt pizza đi."
      },
      {
        en: "Do you feel like going for a walk? The weather is perfect.",
        vi: "Cậu có muốn đi dạo không? Thời tiết hôm nay tuyệt lắm."
      },
      {
        en: "I feel like something sweet right now. How about some dessert?",
        vi: "Giờ mình thèm ăn gì đó ngọt ngọt. Ăn tráng miệng nhé?"
      }
    ]
  },
  {
    id: 27,
    collocation: "see eye to eye",
    type: "Idiom",
    meaning_vi: "đồng quan điểm, chung ý kiến",
    meaning_en: "to agree with someone on an issue",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "My brother and I rarely see eye to eye on politics.",
        vi: "Tôi và anh trai hiếm khi đồng quan điểm về chính trị."
      },
      {
        en: "We don't always see eye to eye, but we respect each other's opinions.",
        vi: "Chúng tôi không phải lúc nào cũng đồng ý với nhau, nhưng luôn tôn trọng ý kiến của nhau."
      },
      {
        en: "It's okay if we don't see eye to eye — healthy disagreement leads to better ideas.",
        vi: "Không sao nếu chúng ta không đồng quan điểm — bất đồng lành mạnh dẫn đến ý tưởng tốt hơn."
      }
    ]
  },
  {
    id: 28,
    collocation: "speak your mind",
    type: "Verb + Noun",
    meaning_vi: "nói thẳng suy nghĩ của mình",
    meaning_en: "to say what you think frankly and directly",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "Don't be shy, feel free to speak your mind.",
        vi: "Đừng ngại, cứ thoải mái nói ra suy nghĩ thật của bạn."
      },
      {
        en: "I appreciate that she always speaks her mind, even if it's uncomfortable.",
        vi: "Tôi đánh giá cao việc cô ấy luôn nói thẳng suy nghĩ, dù đôi khi khó nghe."
      },
      {
        en: "This is a safe space — please speak your mind without hesitation.",
        vi: "Đây là không gian an toàn — xin cứ thoải mái nói thẳng suy nghĩ mà không ngần ngại."
      }
    ]
  },

  // Chủ đề 5: Mua sắm, Tiền bạc & Du lịch (Money & Travel)
  {
    id: 29,
    collocation: "make a living",
    type: "Verb + Noun",
    meaning_vi: "kiếm sống, mưu sinh",
    meaning_en: "to earn money needed to support oneself",
    category: "Money & Travel",
    examples: [
      {
        en: "He makes a good living as a freelance software developer.",
        vi: "Anh ấy kiếm sống rất tốt với nghề lập trình viên tự do."
      },
      {
        en: "It's not easy to make a living as an artist, but passion keeps her going.",
        vi: "Kiếm sống bằng nghề nghệ sĩ không hề dễ, nhưng đam mê đã giữ cô ấy tiếp tục."
      },
      {
        en: "What do you do to make a living?",
        vi: "Bạn làm nghề gì để kiếm sống vậy?"
      }
    ]
  },
  {
    id: 30,
    collocation: "pay by credit card",
    type: "Verb + Preposition",
    meaning_vi: "thanh toán bằng thẻ tín dụng",
    meaning_en: "to purchase goods using a credit card",
    category: "Money & Travel",
    examples: [
      {
        en: "Do you accept cash or can I pay by credit card?",
        vi: "Quán nhận tiền mặt hay tôi có thể thanh toán bằng thẻ tín dụng ạ?"
      },
      {
        en: "I usually pay by credit card to collect reward points.",
        vi: "Tôi thường thanh toán bằng thẻ tín dụng để tích điểm thưởng."
      },
      {
        en: "Sorry, our card machine is broken — you'll need to pay by cash.",
        vi: "Xin lỗi, máy quẹt thẻ hỏng rồi — bạn cần thanh toán bằng tiền mặt ạ."
      }
    ]
  },
  {
    id: 31,
    collocation: "catch a flight",
    type: "Verb + Noun",
    meaning_vi: "bắt chuyến bay, kịp chuyến bay",
    meaning_en: "to board a plane on time",
    category: "Money & Travel",
    examples: [
      {
        en: "Hurry up, we have to catch a flight at 7 AM!",
        vi: "Nhanh lên nào, chúng ta phải bắt chuyến bay lúc 7 giờ sáng đấy!"
      },
      {
        en: "I almost missed my connection but managed to catch the flight at the last minute.",
        vi: "Tôi suýt lỡ chuyến nối tiếp nhưng may mắn bắt được chuyến bay vào phút chót."
      },
      {
        en: "We need to leave by 5 AM to catch the early morning flight.",
        vi: "Chúng ta cần đi lúc 5 giờ sáng để kịp chuyến bay sớm."
      }
    ]
  },
  {
    id: 32,
    collocation: "book in advance",
    type: "Verb + Adverb",
    meaning_vi: "đặt trước (phòng, vé, bàn)",
    meaning_en: "to reserve something before the date it will be used",
    category: "Money & Travel",
    examples: [
      {
        en: "During the holidays, it's wise to book tickets well in advance.",
        vi: "Vào các dịp lễ, nên đặt vé trước từ sớm."
      },
      {
        en: "I always book my hotel rooms in advance to get better rates.",
        vi: "Tôi luôn đặt phòng khách sạn trước để có giá tốt hơn."
      },
      {
        en: "That restaurant is very popular, so you should book a table in advance.",
        vi: "Nhà hàng đó rất đông khách, nên bạn cần đặt bàn trước nhé."
      }
    ]
  },
  {
    id: 33,
    collocation: "waste money",
    type: "Verb + Noun",
    meaning_vi: "lãng phí tiền bạc",
    meaning_en: "to spend money unnecessarily or foolishly",
    category: "Money & Travel",
    examples: [
      {
        en: "Don't waste money on fast food every single day.",
        vi: "Đừng lãng phí tiền vào đồ ăn nhanh mỗi ngày như vậy."
      },
      {
        en: "Buying things you don't need is just wasting money.",
        vi: "Mua những thứ bạn không cần chẳng khác gì lãng phí tiền bạc."
      },
      {
        en: "I don't want to waste money on a gym membership I'll never use.",
        vi: "Tôi không muốn lãng phí tiền vào thẻ gym mà mình sẽ không bao giờ dùng tới."
      }
    ]
  },
  {
    id: 34,
    collocation: "have a good time",
    type: "Verb + Noun",
    meaning_vi: "có một khoảng thời gian vui vẻ",
    meaning_en: "to enjoy oneself greatly",
    category: "Daily Life",
    examples: [
      {
        en: "We had a really good time exploring the old town.",
        vi: "Chúng tôi đã có một khoảng thời gian vô cùng vui vẻ khi khám phá phố cổ."
      },
      {
        en: "I hope you have a good time at the concert tonight!",
        vi: "Chúc bạn có một buổi tối vui vẻ tại buổi hòa nhạc nhé!"
      },
      {
        en: "Did you have a good time at the wedding?",
        vi: "Bạn có vui không trong đám cưới vừa rồi?"
      }
    ]
  },
  {
    id: 35,
    collocation: "take advantage of",
    type: "Phrase",
    meaning_vi: "tận dụng, chớp lấy (cơ hội / lợi thế)",
    meaning_en: "to make good use of an opportunity",
    category: "Work & Study",
    examples: [
      {
        en: "You should take advantage of this free online course.",
        vi: "Bạn nên tận dụng khóa học trực tuyến miễn phí này."
      },
      {
        en: "We took advantage of the long weekend to go on a road trip.",
        vi: "Chúng tôi đã tận dụng kỳ nghỉ dài cuối tuần để đi phượt."
      },
      {
        en: "Take advantage of every networking event you can attend early in your career.",
        vi: "Hãy tận dụng mọi sự kiện kết nối mà bạn có thể tham dự trong giai đoạn đầu sự nghiệp."
      }
    ]
  },
  // Mở rộng thêm các collocations giao tiếp thường dùng
  {
    id: 36,
    collocation: "do business",
    type: "Verb + Noun",
    meaning_vi: "kinh doanh, làm ăn",
    meaning_en: "to buy, sell, or do commercial work with someone",
    category: "Work & Study",
    examples: [
      {
        en: "It is always a pleasure to do business with your company.",
        vi: "Luôn là một vinh hạnh khi được hợp tác làm ăn cùng quý công ty."
      },
      {
        en: "We have been doing business with that supplier for over ten years.",
        vi: "Chúng tôi đã làm ăn với nhà cung cấp đó hơn mười năm rồi."
      },
      {
        en: "How long have you been doing business in this industry?",
        vi: "Bạn đã làm kinh doanh trong ngành này bao lâu rồi?"
      }
    ]
  },
  {
    id: 37,
    collocation: "make a mistake",
    type: "Verb + Noun",
    meaning_vi: "mắc lỗi, phạm sai lầm",
    meaning_en: "to do something wrong or incorrectly",
    category: "Work & Study",
    examples: [
      {
        en: "Everyone makes a mistake sometimes; don't be too hard on yourself.",
        vi: "Ai cũng có lúc phạm sai lầm, đừng quá khắt khe với bản thân."
      },
      {
        en: "I made a mistake in the report and I need to correct it right away.",
        vi: "Tôi đã mắc lỗi trong bản báo cáo và cần sửa ngay bây giờ."
      },
      {
        en: "Learn from your mistakes instead of letting them hold you back.",
        vi: "Hãy học từ những sai lầm của bạn thay vì để chúng kìm hãm bạn."
      }
    ]
  },
  {
    id: 38,
    collocation: "reach an agreement",
    type: "Verb + Noun",
    meaning_vi: "đạt được thỏa thuận, thống nhất ý kiến",
    meaning_en: "to arrive at a decision that all parties accept",
    category: "Work & Study",
    examples: [
      {
        en: "After hours of discussion, both sides reached an agreement.",
        vi: "Sau nhiều giờ thảo luận, cả hai bên đã đạt được thỏa thuận."
      },
      {
        en: "We hope to reach an agreement before the end of the month.",
        vi: "Chúng tôi hy vọng đạt được thỏa thuận trước cuối tháng."
      },
      {
        en: "The two countries finally reached an agreement on trade after years of negotiations.",
        vi: "Hai nước cuối cùng đã đạt được thỏa thuận thương mại sau nhiều năm đàm phán."
      }
    ]
  },
  {
    id: 39,
    collocation: "give a presentation",
    type: "Verb + Noun",
    meaning_vi: "thuyết trình, báo cáo",
    meaning_en: "to talk before an audience about a topic",
    category: "Work & Study",
    examples: [
      {
        en: "She is going to give a presentation on climate change tomorrow.",
        vi: "Ngày mai cô ấy sẽ có buổi thuyết trình về biến đổi khí hậu."
      },
      {
        en: "I'm a bit nervous about giving a presentation in front of 200 people.",
        vi: "Tôi hơi hồi hộp khi phải thuyết trình trước 200 người."
      },
      {
        en: "He gave an impressive presentation that won the clients over immediately.",
        vi: "Anh ấy đã thuyết trình rất ấn tượng và thuyết phục được khách hàng ngay lập tức."
      }
    ]
  },
  {
    id: 40,
    collocation: "set a goal",
    type: "Verb + Noun",
    meaning_vi: "đặt ra mục tiêu",
    meaning_en: "to decide on an objective you want to achieve",
    category: "Work & Study",
    examples: [
      {
        en: "It's important to set realistic goals for your career.",
        vi: "Điều quan trọng là phải đặt ra các mục tiêu thực tế cho sự nghiệp của bạn."
      },
      {
        en: "At the start of each year, I set a goal and write it down somewhere visible.",
        vi: "Vào đầu mỗi năm, tôi đặt ra một mục tiêu và viết nó ở nơi dễ thấy."
      },
      {
        en: "Have you set any fitness goals for yourself this year?",
        vi: "Năm nay bạn có đặt ra mục tiêu về sức khỏe nào cho mình không?"
      }
    ]
  },
  {
    id: 41,
    collocation: "solve a problem",
    type: "Verb + Noun",
    meaning_vi: "giải quyết một vấn đề",
    meaning_en: "to find an answer or solution to a difficulty",
    category: "Work & Study",
    examples: [
      {
        en: "Brainstorming with colleagues helps solve complex problems faster.",
        vi: "Cùng đồng nghiệp thảo luận ý tưởng giúp giải quyết vấn đề phức tạp nhanh hơn."
      },
      {
        en: "We need to solve this problem before the client meeting tomorrow.",
        vi: "Chúng ta cần giải quyết vấn đề này trước buổi gặp khách hàng ngày mai."
      },
      {
        en: "Instead of complaining, focus your energy on solving the problem.",
        vi: "Thay vì phàn nàn, hãy tập trung năng lượng vào việc giải quyết vấn đề."
      }
    ]
  },
  {
    id: 42,
    collocation: "take responsibility",
    type: "Verb + Noun",
    meaning_vi: "chịu trách nhiệm, gánh vác trách nhiệm",
    meaning_en: "to accept that you are in charge or at fault",
    category: "Work & Study",
    examples: [
      {
        en: "A good leader is always willing to take responsibility.",
        vi: "Một người lãnh đạo tốt luôn sẵn sàng chịu trách nhiệm."
      },
      {
        en: "It was my mistake, and I'm ready to take full responsibility.",
        vi: "Đó là lỗi của tôi và tôi sẵn sàng chịu trách nhiệm hoàn toàn."
      },
      {
        en: "Taking responsibility for your actions is a sign of maturity.",
        vi: "Chịu trách nhiệm về hành động của mình là dấu hiệu của sự trưởng thành."
      }
    ]
  },
  {
    id: 43,
    collocation: "come to an end",
    type: "Phrase",
    meaning_vi: "đi đến hồi kết, kết thúc",
    meaning_en: "to finish or conclude",
    category: "Daily Life",
    examples: [
      {
        en: "Our wonderful summer vacation has finally come to an end.",
        vi: "Kỳ nghỉ hè tuyệt vời của chúng tôi cuối cùng cũng đã kết thúc."
      },
      {
        en: "All good things must come to an end — that's what makes them precious.",
        vi: "Mọi điều tốt đẹp rồi cũng phải đến hồi kết — đó là điều làm chúng trở nên quý giá."
      },
      {
        en: "The project has finally come to an end after three years of hard work.",
        vi: "Dự án cuối cùng đã kết thúc sau ba năm làm việc vất vả."
      }
    ]
  },
  {
    id: 44,
    collocation: "have a chat",
    type: "Verb + Noun",
    meaning_vi: "trò chuyện, tán gẫu một chút",
    meaning_en: "to talk informally with someone",
    category: "Social & Chat",
    examples: [
      {
        en: "Do you have a few minutes to have a quick chat?",
        vi: "Bạn có rảnh vài phút để trò chuyện nhanh một chút không?"
      },
      {
        en: "I'd love to have a chat with you over coffee sometime this week.",
        vi: "Tôi rất muốn được ngồi tán gẫu cùng bạn bên ly cà phê trong tuần này."
      },
      {
        en: "We had a lovely chat about our travel memories over dinner.",
        vi: "Chúng tôi đã có một cuộc trò chuyện thú vị về những chuyến đi trong bữa tối."
      }
    ]
  },
  {
    id: 45,
    collocation: "ask for advice",
    type: "Verb + Preposition + Noun",
    meaning_vi: "xin lời khuyên",
    meaning_en: "to request suggestions about what to do",
    category: "Social & Chat",
    examples: [
      {
        en: "Whenever I'm confused, I ask my mentor for advice.",
        vi: "Mỗi khi bối rối, tôi thường xin lời khuyên từ người hướng dẫn của mình."
      },
      {
        en: "Don't hesitate to ask for advice — most people are happy to help.",
        vi: "Đừng ngại xin lời khuyên — hầu hết mọi người đều sẵn lòng giúp đỡ."
      },
      {
        en: "He asked his parents for advice before making the big career move.",
        vi: "Anh ấy đã hỏi ý kiến cha mẹ trước khi đưa ra bước ngoặt lớn trong sự nghiệp."
      }
    ]
  },
  {
    id: 46,
    collocation: "make friends",
    type: "Verb + Noun",
    meaning_vi: "kết bạn, làm quen bạn mới",
    meaning_en: "to form new friendships",
    category: "Social & Chat",
    examples: [
      {
        en: "Joining a sports club is a great way to make friends.",
        vi: "Tham gia một câu lạc bộ thể thao là cách tuyệt vời để kết bạn."
      },
      {
        en: "It can be hard to make friends in a new city, but staying open really helps.",
        vi: "Kết bạn trong một thành phố mới có thể khó, nhưng giữ thái độ cởi mở thực sự giúp ích."
      },
      {
        en: "My daughter made a lot of friends on her first week at the new school.",
        vi: "Con gái tôi đã kết được nhiều bạn ngay trong tuần đầu tiên ở trường mới."
      }
    ]
  },
  {
    id: 47,
    collocation: "pay a visit",
    type: "Verb + Noun",
    meaning_vi: "ghé thăm, đến thăm ai",
    meaning_en: "to visit someone or some place",
    category: "Social & Chat",
    examples: [
      {
        en: "We should pay my grandparents a visit this Sunday.",
        vi: "Chủ nhật này chúng ta nên đến thăm ông bà."
      },
      {
        en: "Whenever you're in town, please pay us a visit!",
        vi: "Bất cứ khi nào bạn ghé thành phố này, hãy đến thăm chúng tôi nhé!"
      },
      {
        en: "The CEO paid an unexpected visit to the factory floor this morning.",
        vi: "Sáng nay giám đốc điều hành đã đến thăm đột xuất xưởng sản xuất."
      }
    ]
  },
  {
    id: 48,
    collocation: "tell a lie",
    type: "Verb + Noun",
    meaning_vi: "nói dối",
    meaning_en: "to say something that is not true intentionally",
    category: "Social & Chat",
    examples: [
      {
        en: "He never tells a lie to his best friends.",
        vi: "Anh ấy không bao giờ nói dối những người bạn thân nhất của mình."
      },
      {
        en: "Children sometimes tell lies to avoid getting into trouble.",
        vi: "Trẻ em đôi khi nói dối để tránh bị rắc rối."
      },
      {
        en: "I could tell she was telling a lie just by looking at her face.",
        vi: "Tôi có thể biết cô ấy đang nói dối chỉ qua nét mặt của cô ấy."
      }
    ]
  },
  {
    id: 49,
    collocation: "keep a secret",
    type: "Verb + Noun",
    meaning_vi: "giữ bí mật",
    meaning_en: "to not reveal confidential information",
    category: "Social & Chat",
    examples: [
      {
        en: "Can I trust you to keep a secret?",
        vi: "Tôi có thể tin tưởng bạn giữ kín bí mật này chứ?"
      },
      {
        en: "She's the best person to keep a secret — she's never told anyone.",
        vi: "Cô ấy là người giữ bí mật giỏi nhất — cô ấy chưa bao giờ kể với ai."
      },
      {
        en: "Promise me you'll keep this a secret between us.",
        vi: "Hứa với mình là sẽ giữ bí mật này giữa chúng ta nhé."
      }
    ]
  },
  {
    id: 50,
    collocation: "make fun of",
    type: "Phrase",
    meaning_vi: "trêu chọc, chế giễu ai",
    meaning_en: "to tease or laugh at someone unkindly",
    category: "Social & Chat",
    examples: [
      {
        en: "It is unkind to make fun of someone's mistakes.",
        vi: "Thật không tốt khi trêu chọc lỗi lầm của người khác."
      },
      {
        en: "They made fun of his accent at first, but he ignored them and proved himself.",
        vi: "Ban đầu họ chế giễu giọng nói của anh ấy, nhưng anh ấy bỏ qua và chứng minh bản thân."
      },
      {
        en: "Never make fun of someone who is trying their best.",
        vi: "Đừng bao giờ chế nhạo người đang cố gắng hết sức của mình."
      }
    ]
  },
  {
    id: 51,
    collocation: "catch fire",
    type: "Verb + Noun",
    meaning_vi: "bốc cháy, bắt lửa",
    meaning_en: "to start burning",
    category: "Daily Life",
    examples: [
      {
        en: "Dry leaves easily catch fire during the hot summer.",
        vi: "Lá khô rất dễ bắt lửa trong mùa hè nóng nực."
      },
      {
        en: "The forest caught fire quickly because of the dry weather.",
        vi: "Rừng bắt lửa rất nhanh do thời tiết khô hạn."
      },
      {
        en: "His idea suddenly caught fire and spread through the entire company.",
        vi: "Ý tưởng của anh ấy bất ngờ được lan truyền rộng rãi khắp cả công ty."
      }
    ]
  },
  {
    id: 52,
    collocation: "do the dishes",
    type: "Verb + Noun",
    meaning_vi: "rửa bát đĩa",
    meaning_en: "to wash dishes and utensils after a meal",
    category: "Daily Life",
    examples: [
      {
        en: "I'll cook dinner if you do the dishes.",
        vi: "Tôi sẽ nấu bữa tối nếu bạn chịu rửa bát đĩa."
      },
      {
        en: "We take turns doing the dishes so no one person does it every day.",
        vi: "Chúng tôi thay nhau rửa bát để không ai phải làm mỗi ngày."
      },
      {
        en: "Can you do the dishes while I put the kids to bed?",
        vi: "Bạn rửa bát giúp tôi trong khi tôi cho các con đi ngủ được không?"
      }
    ]
  },
  {
    id: 53,
    collocation: "do the laundry",
    type: "Verb + Noun",
    meaning_vi: "giặt giũ quần áo",
    meaning_en: "to wash clothes, sheets, and towels",
    category: "Daily Life",
    examples: [
      {
        en: "Sunday morning is when I usually do the laundry.",
        vi: "Sáng Chủ nhật là lúc tôi thường giặt giũ quần áo."
      }
    ]
  },
  {
    id: 54,
    collocation: "make the bed",
    type: "Verb + Noun",
    meaning_vi: "dọn dẹp, gấp chăn gối giường ngủ",
    meaning_en: "to arrange sheets and blankets neatly after getting up",
    category: "Daily Life",
    examples: [
      {
        en: "Get into the habit of making your bed every morning.",
        vi: "Hãy tạo thói quen dọn giường mỗi buổi sáng."
      }
    ]
  },
  {
    id: 55,
    collocation: "take a shower",
    type: "Verb + Noun",
    meaning_vi: "tắm vòi sen",
    meaning_en: "to wash oneself under a spray of water",
    category: "Daily Life",
    examples: [
      {
        en: "I like to take a warm shower before going to sleep.",
        vi: "Tôi thích tắm vòi sen nước ấm trước khi đi ngủ."
      }
    ]
  },
  {
    id: 56,
    collocation: "fall asleep",
    type: "Verb + Adjective",
    meaning_vi: "ngủ thiếp đi, chìm vào giấc ngủ",
    meaning_en: "to begin sleeping",
    category: "Daily Life",
    examples: [
      {
        en: "I was so tired that I fell asleep on the couch.",
        vi: "Tôi mệt đến nỗi ngủ thiếp đi ngay trên ghế sofa."
      }
    ]
  },
  {
    id: 57,
    collocation: "wake up early",
    type: "Verb + Adverb",
    meaning_vi: "thức dậy sớm",
    meaning_en: "to stop sleeping in the early morning",
    category: "Daily Life",
    examples: [
      {
        en: "Waking up early gives you extra time to plan your day.",
        vi: "Dậy sớm giúp bạn có thêm thời gian để lên kế hoạch trong ngày."
      }
    ]
  },
  {
    id: 58,
    collocation: "stay up late",
    type: "Verb + Adverb",
    meaning_vi: "thức khuya",
    meaning_en: "to remain awake until late at night",
    category: "Daily Life",
    examples: [
      {
        en: "Don't stay up late tonight, we have an early flight tomorrow.",
        vi: "Tối nay đừng thức khuya nhé, sáng mai chúng ta có chuyến bay sớm."
      }
    ]
  },
  {
    id: 59,
    collocation: "get in shape",
    type: "Phrase",
    meaning_vi: "lấy lại vóc dáng, rèn luyện thân thể cân đối",
    meaning_en: "to become physically fit through exercise",
    category: "Daily Life",
    examples: [
      {
        en: "He started jogging regularly to get in shape for the marathon.",
        vi: "Anh ấy bắt đầu chạy bộ đều đặn để lấy lại vóc dáng chuẩn bị cho giải chạy."
      }
    ]
  },
  {
    id: 60,
    collocation: "lose weight",
    type: "Verb + Noun",
    meaning_vi: "giảm cân",
    meaning_en: "to become less heavy or fat",
    category: "Daily Life",
    examples: [
      {
        en: "Eating more vegetables helped her lose weight healthily.",
        vi: "Ăn nhiều rau xanh hơn đã giúp cô ấy giảm cân một cách lành mạnh."
      }
    ]
  },
  {
    id: 61,
    collocation: "gain weight",
    type: "Verb + Noun",
    meaning_vi: "tăng cân",
    meaning_en: "to become heavier",
    category: "Daily Life",
    examples: [
      {
        en: "I always seem to gain weight during the winter holidays.",
        vi: "Tôi dường như lúc nào cũng bị tăng cân trong các kỳ nghỉ mùa đông."
      }
    ]
  },
  {
    id: 62,
    collocation: "call it a day",
    type: "Idiom",
    meaning_vi: "nghỉ tay, dừng công việc hôm nay ở đây",
    meaning_en: "to stop what you are doing because you have done enough",
    category: "Work & Study",
    examples: [
      {
        en: "We've made good progress, let's call it a day.",
        vi: "Hôm nay tiến độ rất tốt rồi, chúng ta dừng tay nghỉ thôi."
      }
    ]
  },
  {
    id: 63,
    collocation: "get down to business",
    type: "Idiom",
    meaning_vi: "bắt tay vào việc chính",
    meaning_en: "to start talking about the main subject or work",
    category: "Work & Study",
    examples: [
      {
        en: "Enough small talk, let's get down to business.",
        vi: "Nói chuyện phiếm thế đủ rồi, chúng ta bắt tay vào việc chính thôi."
      }
    ]
  },
  {
    id: 64,
    collocation: "keep in mind",
    type: "Phrase",
    meaning_vi: "lưu ý, nhớ kỹ điều gì",
    meaning_en: "to not forget an important fact or factor",
    category: "Work & Study",
    examples: [
      {
        en: "Keep in mind that the store closes early on Sundays.",
        vi: "Hãy nhớ rằng cửa hàng đóng cửa sớm vào ngày Chủ nhật."
      }
    ]
  },
  {
    id: 65,
    collocation: "change the subject",
    type: "Verb + Noun",
    meaning_vi: "đổi chủ đề nói chuyện, lảng sang chuyện khác",
    meaning_en: "to start talking about a different topic",
    category: "Social & Chat",
    examples: [
      {
        en: "She felt awkward, so she quickly changed the subject.",
        vi: "Cô ấy cảm thấy ngượng ngùng nên đã nhanh chóng đổi chủ đề nói chuyện."
      }
    ]
  },
  {
    id: 66,
    collocation: "give someone a call",
    type: "Phrase",
    meaning_vi: "gọi điện thoại cho ai",
    meaning_en: "to telephone someone",
    category: "Social & Chat",
    examples: [
      {
        en: "Give me a call when you arrive at the station.",
        vi: "Hãy gọi cho tôi khi bạn đến ga nhé."
      }
    ]
  },
  {
    id: 67,
    collocation: "drop someone a line",
    type: "Idiom",
    meaning_vi: "viết vài dòng nhắn tin / gửi thư cho ai",
    meaning_en: "to write a brief note or message to someone",
    category: "Social & Chat",
    examples: [
      {
        en: "Drop me a line whenever you find some free time.",
        vi: "Hãy nhắn cho tôi vài dòng bất cứ khi nào bạn rảnh nhé."
      }
    ]
  },
  {
    id: 68,
    collocation: "burst into tears",
    type: "Phrase",
    meaning_vi: "bật khóc nức nở",
    meaning_en: "to suddenly begin to cry intensely",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "She burst into tears when hearing the touching story.",
        vi: "Cô ấy bật khóc nức nở khi nghe câu chuyện cảm động."
      }
    ]
  },
  {
    id: 69,
    collocation: "burst out laughing",
    type: "Phrase",
    meaning_vi: "bật cười thành tiếng, phá lên cười",
    meaning_en: "to suddenly begin laughing aloud",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "Everyone burst out laughing at his hilarious joke.",
        vi: "Mọi người đều phá lên cười vì câu nói đùa hài hước của anh ấy."
      }
    ]
  },
  {
    id: 70,
    collocation: "have mixed feelings",
    type: "Phrase",
    meaning_vi: "có cảm xúc lẫn lộn, vừa vui vừa buồn",
    meaning_en: "to feel both positive and negative about something",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "I have mixed feelings about moving to a new city.",
        vi: "Tôi có cảm xúc lẫn lộn khi chuyển đến một thành phố mới."
      }
    ]
  },
  {
    id: 71,
    collocation: "take it easy",
    type: "Idiom",
    meaning_vi: "thư giãn đi, đừng căng thẳng quá",
    meaning_en: "to relax and not worry or work too hard",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "You've worked hard all week, just take it easy this weekend.",
        vi: "Bạn đã làm việc chăm chỉ cả tuần rồi, cuối tuần này cứ thư giãn đi."
      }
    ]
  },
  {
    id: 72,
    collocation: "calm down",
    type: "Phrasal Verb",
    meaning_vi: "bình tĩnh lại",
    meaning_en: "to become less agitated or upset",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "Take a deep breath and calm down before answering.",
        vi: "Hãy hít thở sâu và bình tĩnh lại trước khi trả lời."
      }
    ]
  },
  {
    id: 73,
    collocation: "make an impression",
    type: "Verb + Noun",
    meaning_vi: "tạo ấn tượng",
    meaning_en: "to produce a strong effect or opinion in others",
    category: "Social & Chat",
    examples: [
      {
        en: "Dressing neatly helps you make a great first impression.",
        vi: "Ăn mặc gọn gàng giúp bạn tạo ấn tượng đầu tiên rất tốt."
      }
    ]
  },
  {
    id: 74,
    collocation: "leave a message",
    type: "Verb + Noun",
    meaning_vi: "để lại lời nhắn",
    meaning_en: "to record or write information for someone when they are not available",
    category: "Social & Chat",
    examples: [
      {
        en: "He is in a meeting right now, would you like to leave a message?",
        vi: "Hiện anh ấy đang họp, bạn có muốn để lại lời nhắn không?"
      }
    ]
  },
  {
    id: 75,
    collocation: "pay in cash",
    type: "Verb + Preposition",
    meaning_vi: "trả bằng tiền mặt",
    meaning_en: "to pay money using paper notes or coins",
    category: "Money & Travel",
    examples: [
      {
        en: "You can get a small discount if you pay in cash.",
        vi: "Bạn có thể được giảm giá một chút nếu thanh toán bằng tiền mặt."
      }
    ]
  },
  {
    id: 76,
    collocation: "make a reservation",
    type: "Verb + Noun",
    meaning_vi: "đặt chỗ trước (nhà hàng, khách sạn)",
    meaning_en: "to book a table, room, or seat ahead of time",
    category: "Money & Travel",
    examples: [
      {
        en: "I'd like to make a reservation for two at 7 PM tonight.",
        vi: "Tôi muốn đặt chỗ trước cho 2 người vào lúc 7 giờ tối nay."
      }
    ]
  },
  {
    id: 77,
    collocation: "check in",
    type: "Phrasal Verb",
    meaning_vi: "làm thủ tục nhận phòng / lên máy bay",
    meaning_en: "to arrive and register at a hotel or airport",
    category: "Money & Travel",
    examples: [
      {
        en: "We can check in to the hotel starting at 2 PM.",
        vi: "Chúng ta có thể làm thủ tục nhận phòng khách sạn từ 2 giờ chiều."
      }
    ]
  },
  {
    id: 78,
    collocation: "check out",
    type: "Phrasal Verb",
    meaning_vi: "làm thủ tục trả phòng",
    meaning_en: "to settle bills and leave a hotel",
    category: "Money & Travel",
    examples: [
      {
        en: "Remember to check out before 12:00 noon.",
        vi: "Nhớ làm thủ tục trả phòng trước 12 giờ trưa nhé."
      }
    ]
  },
  {
    id: 79,
    collocation: "take a trip",
    type: "Verb + Noun",
    meaning_vi: "đi du lịch, đi một chuyến đi",
    meaning_en: "to journey or travel somewhere",
    category: "Money & Travel",
    examples: [
      {
        en: "We're planning to take a road trip across the country next month.",
        vi: "Chúng tôi đang lên kế hoạch làm một chuyến đi phượt xuyên đất nước vào tháng tới."
      }
    ]
  },
  {
    id: 80,
    collocation: "ask for directions",
    type: "Phrase",
    meaning_vi: "hỏi đường",
    meaning_en: "to request instructions on how to reach a destination",
    category: "Money & Travel",
    examples: [
      {
        en: "If you get lost, just stop and ask a local for directions.",
        vi: "Nếu bị lạc, cứ dừng lại hỏi đường người dân địa phương nhé."
      }
    ]
  },
  {
    id: 81,
    collocation: "exchange money",
    type: "Verb + Noun",
    meaning_vi: "đổi ngoại tệ",
    meaning_en: "to convert one currency to another",
    category: "Money & Travel",
    examples: [
      {
        en: "Where is the best place to exchange money near here?",
        vi: "Ở gần đây có chỗ nào đổi tiền ngoại tệ tốt nhất không?"
      }
    ]
  },
  {
    id: 82,
    collocation: "afford to buy",
    type: "Verb + Verb",
    meaning_vi: "đủ tiền mua, có khả năng chi trả",
    meaning_en: "to have enough money to purchase something",
    category: "Money & Travel",
    examples: [
      {
        en: "With my current salary, I can't afford to buy that luxury car.",
        vi: "Với mức lương hiện tại, tôi không đủ tiền mua chiếc xe sang đó."
      }
    ]
  },
  {
    id: 83,
    collocation: "open a bank account",
    type: "Phrase",
    meaning_vi: "mở tài khoản ngân hàng",
    meaning_en: "to start an account at a bank",
    category: "Money & Travel",
    examples: [
      {
        en: "You need your passport and proof of address to open a bank account.",
        vi: "Bạn cần hộ chiếu và giấy tờ xác nhận địa chỉ để mở tài khoản ngân hàng."
      }
    ]
  },
  {
    id: 84,
    collocation: "ask for a discount",
    type: "Phrase",
    meaning_vi: "xin giảm giá, trả giá",
    meaning_en: "to ask if a price can be reduced",
    category: "Money & Travel",
    examples: [
      {
        en: "Don't be afraid to ask for a discount when buying in bulk.",
        vi: "Đừng ngại xin giảm giá khi bạn mua số lượng lớn."
      }
    ]
  },
  {
    id: 85,
    collocation: "get a promotion",
    type: "Verb + Noun",
    meaning_vi: "được thăng chức",
    meaning_en: "to be moved to a higher job level or position",
    category: "Work & Study",
    examples: [
      {
        en: "Her hard work paid off and she got a well-deserved promotion.",
        vi: "Sự chăm chỉ của cô ấy đã được đền đáp và cô ấy được thăng chức xứng đáng."
      }
    ]
  },
  {
    id: 86,
    collocation: "apply for a job",
    type: "Verb + Preposition + Noun",
    meaning_vi: "nộp đơn xin việc, ứng tuyển",
    meaning_en: "to formally request a job position",
    category: "Work & Study",
    examples: [
      {
        en: "I decided to apply for a job at a global tech firm.",
        vi: "Tôi đã quyết định nộp đơn xin việc tại một công ty công nghệ toàn cầu."
      }
    ]
  },
  {
    id: 87,
    collocation: "look for a job",
    type: "Phrase",
    meaning_vi: "tìm kiếm việc làm",
    meaning_en: "to search for employment",
    category: "Work & Study",
    examples: [
      {
        en: "He has been looking for a job since graduating last month.",
        vi: "Anh ấy đã tìm kiếm việc làm kể từ khi tốt nghiệp vào tháng trước."
      }
    ]
  },
  {
    id: 88,
    collocation: "hand in your notice",
    type: "Idiom",
    meaning_vi: "nộp đơn thôi việc, nộp đơn từ chức",
    meaning_en: "to officially inform your employer that you are quitting",
    category: "Work & Study",
    examples: [
      {
        en: "He handed in his notice to pursue his own startup idea.",
        vi: "Anh ấy đã nộp đơn thôi việc để theo đuổi ý tưởng khởi nghiệp riêng."
      }
    ]
  },
  {
    id: 89,
    collocation: "sign a contract",
    type: "Verb + Noun",
    meaning_vi: "ký hợp đồng",
    meaning_en: "to officially agree to legal terms by signing",
    category: "Work & Study",
    examples: [
      {
        en: "Read all the fine print carefully before you sign a contract.",
        vi: "Hãy đọc kỹ tất cả các điều khoản nhỏ trước khi bạn ký hợp đồng."
      }
    ]
  },
  {
    id: 90,
    collocation: "take a look",
    type: "Verb + Noun",
    meaning_vi: "ngó qua, xem qua một chút",
    meaning_en: "to examine or check something briefly",
    category: "Daily Life",
    examples: [
      {
        en: "Could you take a quick look at this draft for me?",
        vi: "Bạn có thể xem nhanh qua bản nháp này giúp tôi được không?"
      }
    ]
  },
  {
    id: 91,
    collocation: "catch someone's eye",
    type: "Idiom",
    meaning_vi: "thu hút sự chú ý, lọt vào mắt ai",
    meaning_en: "to attract someone's visual attention",
    category: "Daily Life",
    examples: [
      {
        en: "A beautiful blue jacket in the shop window caught my eye.",
        vi: "Chiếc áo khoác xanh tuyệt đẹp trong tủ kính cửa hàng đã lọt vào mắt tôi."
      }
    ]
  },
  {
    id: 92,
    collocation: "give a compliment",
    type: "Verb + Noun",
    meaning_vi: "dành lời khen, khen ngợi ai",
    meaning_en: "to say something nice or admiring to someone",
    category: "Social & Chat",
    examples: [
      {
        en: "It costs nothing to give someone a sincere compliment.",
        vi: "Chẳng tốn gì để dành cho ai đó một lời khen chân thành."
      }
    ]
  },
  {
    id: 93,
    collocation: "accept an apology",
    type: "Verb + Noun",
    meaning_vi: "chấp nhận lời xin lỗi",
    meaning_en: "to forgive someone who apologized",
    category: "Social & Chat",
    examples: [
      {
        en: "I gladly accept your apology; let's put this behind us.",
        vi: "Tôi vui vẻ chấp nhận lời xin lỗi của bạn; hãy bỏ qua chuyện này nhé."
      }
    ]
  },
  {
    id: 94,
    collocation: "make noise",
    type: "Verb + Noun",
    meaning_vi: "làm ồn, gây ồn ào",
    meaning_en: "to produce loud or disturbing sounds",
    category: "Daily Life",
    examples: [
      {
        en: "Please don't make noise while the baby is sleeping.",
        vi: "Làm ơn đừng gây ồn ào khi em bé đang ngủ."
      }
    ]
  },
  {
    id: 95,
    collocation: "keep quiet",
    type: "Verb + Adjective",
    meaning_vi: "giữ im lặng, trật tự",
    meaning_en: "to stay silent and not make sounds",
    category: "Daily Life",
    examples: [
      {
        en: "Visitors are requested to keep quiet inside the library.",
        vi: "Khách đến được yêu cầu giữ im lặng bên trong thư viện."
      }
    ]
  },
  {
    id: 96,
    collocation: "do your best",
    type: "Phrase",
    meaning_vi: "cố gắng hết sức mình",
    meaning_en: "to try as hard as you possibly can",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "Don't worry about the final score, just do your best.",
        vi: "Đừng lo lắng về điểm số cuối cùng, chỉ cần cố gắng hết sức mình là được."
      }
    ]
  },
  {
    id: 97,
    collocation: "cross your fingers",
    type: "Idiom",
    meaning_vi: "cầu may, hy vọng điều tốt đẹp xảy ra",
    meaning_en: "to hope strongly that something will turn out well",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "I'm crossing my fingers that I get the scholarship.",
        vi: "Tôi đang cầu may để mình nhận được suất học bổng này."
      }
    ]
  },
  {
    id: 98,
    collocation: "lose your patience",
    type: "Verb + Noun",
    meaning_vi: "mất kiên nhẫn",
    meaning_en: "to become annoyed because of delays or trouble",
    category: "Emotions & Opinions",
    examples: [
      {
        en: "After waiting in line for two hours, he lost his patience.",
        vi: "Sau khi xếp hàng suốt 2 tiếng đồng hồ, anh ấy đã mất kiên nhẫn."
      }
    ]
  },
  {
    id: 99,
    collocation: "make a suggestion",
    type: "Verb + Noun",
    meaning_vi: "đưa ra một gợi ý, đề xuất",
    meaning_en: "to offer an idea for others to consider",
    category: "Social & Chat",
    examples: [
      {
        en: "May I make a suggestion regarding the weekend plan?",
        vi: "Tôi có thể đưa ra một gợi ý liên quan đến kế hoạch cuối tuần được không?"
      }
    ]
  },
  {
    id: 100,
    collocation: "reach a consensus",
    type: "Verb + Noun",
    meaning_vi: "đạt được sự đồng thuận chung",
    meaning_en: "to come to an agreement accepted by everyone in a group",
    category: "Work & Study",
    examples: [
      {
        en: "The committee finally reached a consensus on the new policy.",
        vi: "Hội đồng cuối cùng đã đạt được sự đồng thuận chung về chính sách mới."
      }
    ]
  }
];

window.COLLOCATIONS_DATA = COLLOCATIONS_DATA;

