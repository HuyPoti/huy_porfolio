/* ===================================================
   KANJI RADICALS MASTER - APPLICATION LOGIC
   - Quản lý Tabs & Chuyển đổi View
   - Thư viện bộ thủ: Tìm kiếm, lọc theo nét, modal xem 10 ví dụ
   - Trắc nghiệm phản xạ 8 giây/câu:
     + Bộ đếm 8s, progress bar đổi màu
     + Âm thanh tự phát bằng Web Audio API
     + Lựa chọn số lượng câu hỏi & phạm vi bộ thủ
     + Thống kê & ôn tập câu sai
   - Flashcard 214 bộ thủ lật thẻ sinh động
=================================================== */

// Global State
const state = {
  currentTab: 'library',
  searchKeyword: '',
  selectedStrokes: 'all',
  
  // Quiz State
  quizConfig: {
    questionCount: 20,
    range: 'top50',
    mode: 'radical-to-meaning',
    soundEnabled: true
  },
  quiz: {
    active: false,
    questions: [],
    currentIndex: 0,
    score: 0,
    timer: null,
    timeLeft: 8,
    timerInterval: null,
    wrongAnswers: []
  },

  // Flashcard State
  flashcard: {
    filteredList: [],
    currentIndex: 0,
    isFlipped: false
  }
};

// Web Audio Sound Synthesizer (Không cần tải file ngoài)
class SoundFX {
  constructor() {
    this.ctx = null;
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playCorrect() {
    if (!state.quizConfig.soundEnabled) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    const now = this.ctx.currentTime;
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(523.25, now); // C5
    osc.frequency.setValueAtTime(659.25, now + 0.08); // E5
    osc.frequency.setValueAtTime(783.99, now + 0.16); // G5

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.start(now);
    osc.stop(now + 0.35);
  }

  playWrong() {
    if (!state.quizConfig.soundEnabled) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    const now = this.ctx.currentTime;
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now); // A3
    osc.frequency.setValueAtTime(164.81, now + 0.12); // E3

    gain.gain.setValueAtTime(0.25, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.start(now);
    osc.stop(now + 0.35);
  }

  playTick() {
    if (!state.quizConfig.soundEnabled) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    const now = this.ctx.currentTime;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);

    gain.gain.setValueAtTime(0.05, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

    osc.start(now);
    osc.stop(now + 0.04);
  }

  playFinish() {
    if (!state.quizConfig.soundEnabled) return;
    this.init();
    if (!this.ctx) return;

    const notes = [523.25, 659.25, 783.99, 1046.50];
    const now = this.ctx.currentTime;
    notes.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.setValueAtTime(freq, now + idx * 0.1);
      gain.gain.setValueAtTime(0.18, now + idx * 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.25);

      osc.start(now + idx * 0.1);
      osc.stop(now + idx * 0.1 + 0.25);
    });
  }
}

const sounds = new SoundFX();

// Khởi chạy khi tài liệu sẵn sàng
document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initStrokesFilter();
  renderRadicalsGrid();
  initSearch();
  initModal();
  initQuiz();
  initFlashcard();
});

/* ===================================================
   1. TAB SWITCHING
=================================================== */
function initTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });
}

function switchTab(tabId) {
  state.currentTab = tabId;

  // Cập nhật nút tab
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabId);
  });

  // Cập nhật views
  document.querySelectorAll('.view-panel').forEach(view => {
    view.classList.toggle('active', view.id === `view-${tabId}`);
  });

  // Nếu chuyển qua Flashcard, cập nhật lại view
  if (tabId === 'flashcard') {
    updateFlashcardView();
  }
}

/* ===================================================
   2. THƯ VIỆN BỘ THỦ & TÌM KIẾM
=================================================== */
function initStrokesFilter() {
  const container = document.getElementById('stroke-chips-container');
  // Lấy các số nét có trong dữ liệu (từ 1 đến 17)
  const strokesSet = new Set(RADICALS_DATA.map(r => r.strokes));
  const sortedStrokes = Array.from(strokesSet).sort((a, b) => a - b);

  sortedStrokes.forEach(num => {
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.setAttribute('data-strokes', num);
    chip.textContent = `${num} nét`;
    chip.addEventListener('click', () => {
      document.querySelectorAll('#stroke-chips-container .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state.selectedStrokes = num;
      renderRadicalsGrid();
    });
    container.appendChild(chip);
  });

  // Nút "Tất cả"
  const allChip = container.querySelector('[data-strokes="all"]');
  allChip.addEventListener('click', () => {
    document.querySelectorAll('#stroke-chips-container .chip').forEach(c => c.classList.remove('active'));
    allChip.classList.add('active');
    state.selectedStrokes = 'all';
    renderRadicalsGrid();
  });
}

function initSearch() {
  const searchInput = document.getElementById('radical-search');
  const clearBtn = document.getElementById('clear-search');

  searchInput.addEventListener('input', (e) => {
    state.searchKeyword = e.target.value.trim().toLowerCase();
    clearBtn.style.display = state.searchKeyword ? 'block' : 'none';
    renderRadicalsGrid();
  });

  clearBtn.addEventListener('click', () => {
    searchInput.value = '';
    state.searchKeyword = '';
    clearBtn.style.display = 'none';
    renderRadicalsGrid();
    searchInput.focus();
  });
}

function getFilteredRadicals() {
  return RADICALS_DATA.filter(item => {
    // Lọc theo số nét
    if (state.selectedStrokes !== 'all' && item.strokes !== Number(state.selectedStrokes)) {
      return false;
    }

    // Lọc theo từ khóa tìm kiếm
    if (state.searchKeyword) {
      const kw = state.searchKeyword;
      const matchRadical = item.radical.toLowerCase().includes(kw);
      const matchVariants = item.variants && item.variants.some(v => v.toLowerCase().includes(kw));
      const matchHanViet = item.hanViet.toLowerCase().includes(kw);
      const matchJp = item.nameJp.toLowerCase().includes(kw);
      const matchRomaji = item.romaji.toLowerCase().includes(kw);
      const matchMeaning = item.meaning.toLowerCase().includes(kw);
      const matchExamples = item.examples && item.examples.some(ex => 
        ex.kanji.toLowerCase().includes(kw) || 
        ex.meaning.toLowerCase().includes(kw)
      );

      return matchRadical || matchVariants || matchHanViet || matchJp || matchRomaji || matchMeaning || matchExamples;
    }

    return true;
  });
}

function renderRadicalsGrid() {
  const grid = document.getElementById('radicals-grid');
  const countEl = document.getElementById('displayed-count');
  const filtered = getFilteredRadicals();

  countEl.textContent = filtered.length;
  grid.innerHTML = '';

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 48px 20px; color: var(--text-muted);">
        <p style="font-size: 32px; margin-bottom: 12px;">🔍</p>
        <p style="font-size: 16px;">Không tìm thấy bộ thủ nào phù hợp với bộ lọc.</p>
      </div>
    `;
    return;
  }

  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'radical-card';
    card.setAttribute('data-id', item.id);

    const variantText = item.variants && item.variants.length > 0 ? `(${item.variants.join(', ')})` : '';
    const exampleCount = item.examples ? item.examples.length : 0;

    card.innerHTML = `
      <div class="card-top">
        <span class="card-id-tag">#${item.id}</span>
        <span class="card-stroke-tag">${item.strokes} nét</span>
      </div>
      <div class="card-main-radical">${item.radical}</div>
      <div class="card-meta">
        <div class="card-hanviet">${item.hanViet} ${variantText}</div>
        <div class="card-jp-romaji">${item.nameJp} • ${item.romaji}</div>
        <div class="card-meaning">${item.meaning}</div>
      </div>
      <div class="card-example-count">
        <span>📖 ${exampleCount} ví dụ chữ Kanji</span>
        <span>Chi tiết ➔</span>
      </div>
    `;

    card.addEventListener('click', () => openRadicalModal(item));
    grid.appendChild(card);
  });
}

/* ===================================================
   3. MODAL CHI TIẾT BỘ THỦ
=================================================== */
function initModal() {
  const modal = document.getElementById('detail-modal');
  const closeBtn = document.getElementById('modal-close-btn');

  closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.style.display === 'flex') {
      modal.style.display = 'none';
    }
  });
}

function openRadicalModal(item) {
  const modal = document.getElementById('detail-modal');
  
  document.getElementById('modal-radical-char').textContent = item.radical;
  document.getElementById('modal-id').textContent = `Bộ #${item.id}`;
  document.getElementById('modal-strokes').textContent = `${item.strokes} Nét`;
  
  const variantsTag = document.getElementById('modal-variants');
  if (item.variants && item.variants.length > 0) {
    variantsTag.style.display = 'inline-block';
    variantsTag.textContent = `Biến thể: ${item.variants.join(' , ')}`;
  } else {
    variantsTag.style.display = 'none';
  }

  document.getElementById('modal-hanviet').textContent = `${item.hanViet} (${item.radical})`;
  document.getElementById('modal-jp').textContent = `${item.nameJp}  |  Romaji: ${item.romaji}`;
  document.getElementById('modal-meaning').textContent = item.meaning;
  
  const tbody = document.getElementById('modal-examples-tbody');
  const countBadge = document.getElementById('modal-ex-count');
  tbody.innerHTML = '';

  const examples = item.examples || [];
  countBadge.textContent = `${examples.length} ví dụ`;

  if (examples.length === 0) {
    tbody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--text-muted); padding: 20px;">Đang cập nhật ví dụ...</td></tr>`;
  } else {
    examples.forEach(ex => {
      const tr = document.createElement('tr');
      let readingFormatted = '';
      if (ex.hiragana && ex.romaji) {
        readingFormatted = `<div style="font-weight: 700; color: #f8fafc; font-size: 15px;">${ex.hiragana}</div><span style="color: var(--accent-gold); font-size: 13px; font-weight: 600;">[ ${ex.romaji} ]</span>`;
      } else if (ex.hiragana) {
        readingFormatted = `<div style="font-weight: 700; color: #f8fafc; font-size: 15px;">${ex.hiragana}</div>`;
      } else if (ex.romaji) {
        readingFormatted = `<span style="color: var(--accent-gold); font-size: 13px; font-weight: 600;">[ ${ex.romaji} ]</span>`;
      } else {
        readingFormatted = `<span style="color: var(--text-muted); font-size: 13px;">Đang cập nhật...</span>`;
      }

      tr.innerHTML = `
        <td><span class="ex-kanji">${ex.kanji}</span></td>
        <td class="ex-reading">${readingFormatted}</td>
        <td><strong>${ex.meaning}</strong></td>
      `;
      tbody.appendChild(tr);
    });
  }

  modal.style.display = 'flex';
}

/* ===================================================
   4. CHẾ ĐỘ TRẮC NGHIỆM PHẢN XẠ 8 GIÂY
=================================================== */
function initQuiz() {
  // Option Chips: Count
  setupOptionChips('quiz-count-options', (val) => {
    state.quizConfig.questionCount = val === 'all' ? 214 : parseInt(val);
  });

  // Option Chips: Range
  setupOptionChips('quiz-range-options', (val) => {
    state.quizConfig.range = val;
  });

  // Option Chips: Mode
  setupOptionChips('quiz-mode-options', (val) => {
    state.quizConfig.mode = val;
  });

  // Sound Toggle
  document.getElementById('quiz-sound-toggle').addEventListener('change', (e) => {
    state.quizConfig.soundEnabled = e.target.checked;
  });

  // Start Quiz Button
  document.getElementById('start-quiz-btn').addEventListener('click', startQuiz);

  // Quit Quiz Button
  document.getElementById('quit-quiz-btn').addEventListener('click', () => {
    if (confirm('Bạn có chắc muốn kết thúc bài trắc nghiệm này?')) {
      stopTimer();
      showQuizScreen('setup');
    }
  });

  // Retry Button
  document.getElementById('retry-quiz-btn').addEventListener('click', startQuiz);

  // Back to Library Button
  document.getElementById('back-library-btn').addEventListener('click', () => {
    showQuizScreen('setup');
    switchTab('library');
  });
}

function setupOptionChips(containerId, onChangeCallback) {
  const container = document.getElementById(containerId);
  const chips = container.querySelectorAll('.chip');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const val = chip.getAttribute('data-count') || chip.getAttribute('data-range') || chip.getAttribute('data-mode');
      onChangeCallback(val);
    });
  });
}

function showQuizScreen(screen) {
  document.getElementById('quiz-setup-screen').style.display = screen === 'setup' ? 'block' : 'none';
  document.getElementById('quiz-play-screen').style.display = screen === 'play' ? 'block' : 'none';
  document.getElementById('quiz-result-screen').style.display = screen === 'result' ? 'block' : 'none';
}

function getPoolByRange(range) {
  let pool = [...RADICALS_DATA];
  if (range === 'top50') {
    pool = pool.slice(0, 50);
  } else if (range === 'strokes_1_4') {
    pool = pool.filter(r => r.strokes <= 4);
  } else if (range === 'strokes_5_8') {
    pool = pool.filter(r => r.strokes >= 5 && r.strokes <= 8);
  }
  return pool;
}

function startQuiz() {
  const pool = getPoolByRange(state.quizConfig.range);
  if (pool.length === 0) return;

  // Xáo trộn pool
  const shuffled = [...pool].sort(() => 0.5 - Math.random());
  const count = Math.min(state.quizConfig.questionCount, shuffled.length);
  const selectedRadicals = shuffled.slice(0, count);

  // Chuẩn bị danh sách câu hỏi
  state.quiz.questions = selectedRadicals.map(target => {
    // Xác định kiểu câu hỏi
    let questionType = state.quizConfig.mode;
    if (questionType === 'mixed') {
      questionType = Math.random() > 0.5 ? 'radical-to-meaning' : 'meaning-to-radical';
    }

    // Chọn 3 đáp án sai ngẫu nhiên
    const distractorCandidates = RADICALS_DATA.filter(r => r.id !== target.id);
    const shuffledDistractors = distractorCandidates.sort(() => 0.5 - Math.random()).slice(0, 3);
    const options = [target, ...shuffledDistractors].sort(() => 0.5 - Math.random());

    return {
      type: questionType,
      target,
      options
    };
  });

  state.quiz.currentIndex = 0;
  state.quiz.score = 0;
  state.quiz.wrongAnswers = [];
  state.quiz.active = true;

  document.getElementById('total-q-num').textContent = state.quiz.questions.length;
  showQuizScreen('play');
  renderCurrentQuestion();
}

function renderCurrentQuestion() {
  const q = state.quiz.questions[state.quiz.currentIndex];
  document.getElementById('current-q-num').textContent = state.quiz.currentIndex + 1;
  document.getElementById('current-score').textContent = state.quiz.score;

  const promptEl = document.getElementById('question-prompt');
  const displayEl = document.getElementById('question-display');
  const subinfoEl = document.getElementById('question-subinfo');
  const answersGrid = document.getElementById('answers-grid');
  const feedbackEl = document.getElementById('answer-feedback');

  feedbackEl.style.display = 'none';
  answersGrid.innerHTML = '';

  const keys = ['A', 'B', 'C', 'D'];

  if (q.type === 'radical-to-meaning') {
    promptEl.textContent = 'Bộ thủ này có tên Hán Việt & ý nghĩa là gì?';
    displayEl.textContent = q.target.radical;
    subinfoEl.textContent = `${q.target.strokes} nét • ${q.target.nameJp} (${q.target.romaji})`;

    q.options.forEach((opt, idx) => {
      const btn = document.createElement('button');
      btn.className = 'ans-btn';
      btn.innerHTML = `
        <span class="ans-key">${keys[idx]}</span>
        <div class="ans-text">
          <strong>${opt.hanViet}</strong>: ${opt.meaning}
        </div>
      `;
      btn.addEventListener('click', () => handleUserAnswer(opt.id === q.target.id, btn, opt));
      answersGrid.appendChild(btn);
    });
  } else {
    // meaning-to-radical
    promptEl.textContent = `Hãy chọn bộ thủ tương ứng với nghĩa:`;
    displayEl.textContent = q.target.hanViet;
    subinfoEl.textContent = `Ý nghĩa: ${q.target.meaning} (${q.target.strokes} nét)`;

    q.options.forEach((opt, idx) => {
      const btn = document.createElement('button');
      btn.className = 'ans-btn';
      btn.innerHTML = `
        <span class="ans-key">${keys[idx]}</span>
        <div class="ans-text" style="font-family: var(--font-kanji); font-size: 28px;">
          ${opt.radical}
        </div>
      `;
      btn.addEventListener('click', () => handleUserAnswer(opt.id === q.target.id, btn, opt));
      answersGrid.appendChild(btn);
    });
  }

  // Khởi động đồng hồ 8 giây
  startQuestionTimer();
}

function startQuestionTimer() {
  stopTimer();
  state.quiz.timeLeft = 8.0;

  const timerBar = document.getElementById('timer-bar');
  const timerText = document.getElementById('timer-text');

  timerBar.className = 'timer-bar';
  timerBar.style.width = '100%';
  timerText.textContent = '8s';
  timerText.style.color = 'var(--accent-blue)';

  const intervalMs = 100;
  const decrement = 0.1;

  state.quiz.timerInterval = setInterval(() => {
    state.quiz.timeLeft -= decrement;

    if (state.quiz.timeLeft <= 0) {
      state.quiz.timeLeft = 0;
      stopTimer();
      handleTimeOut();
      return;
    }

    const percentage = (state.quiz.timeLeft / 8) * 100;
    timerBar.style.width = `${percentage}%`;
    timerText.textContent = `${Math.ceil(state.quiz.timeLeft)}s`;

    if (state.quiz.timeLeft <= 2.5) {
      timerBar.className = 'timer-bar danger';
      timerText.style.color = 'var(--accent-red)';
      // Hiệu ứng tíc tắc cảnh báo
      sounds.playTick();
    } else if (state.quiz.timeLeft <= 4.5) {
      timerBar.className = 'timer-bar warning';
      timerText.style.color = 'var(--accent-gold)';
    }
  }, intervalMs);
}

function stopTimer() {
  if (state.quiz.timerInterval) {
    clearInterval(state.quiz.timerInterval);
    state.quiz.timerInterval = null;
  }
}

function handleUserAnswer(isCorrect, clickedBtn, chosenOption) {
  stopTimer();
  disableAllAnswerButtons();

  const q = state.quiz.questions[state.quiz.currentIndex];
  const feedbackEl = document.getElementById('answer-feedback');

  if (isCorrect) {
    clickedBtn.classList.add('correct');
    state.quiz.score += 10;
    document.getElementById('current-score').textContent = state.quiz.score;
    sounds.playCorrect();

    feedbackEl.className = 'answer-feedback correct-box';
    feedbackEl.textContent = '✓ Chính xác! Rất tuyệt vời!';
    feedbackEl.style.display = 'block';
  } else {
    clickedBtn.classList.add('wrong');
    sounds.playWrong();
    highlightCorrectButton(q.target.id);

    state.quiz.wrongAnswers.push({
      target: q.target,
      userAnswer: chosenOption
    });

    feedbackEl.className = 'answer-feedback wrong-box';
    feedbackEl.textContent = `✗ Chưa chính xác! Đáp án đúng là: ${q.target.radical} (${q.target.hanViet} - ${q.target.meaning})`;
    feedbackEl.style.display = 'block';
  }

  // Chờ 1.2s rồi qua câu tiếp theo
  setTimeout(() => {
    proceedNextQuestion();
  }, 1200);
}

function handleTimeOut() {
  disableAllAnswerButtons();
  sounds.playWrong();

  const q = state.quiz.questions[state.quiz.currentIndex];
  highlightCorrectButton(q.target.id);

  state.quiz.wrongAnswers.push({
    target: q.target,
    userAnswer: null // Hết giờ
  });

  const feedbackEl = document.getElementById('answer-feedback');
  feedbackEl.className = 'answer-feedback wrong-box';
  feedbackEl.textContent = `⌛ Hết 8 giây! Đáp án đúng: ${q.target.radical} (${q.target.hanViet} - ${q.target.meaning})`;
  feedbackEl.style.display = 'block';

  setTimeout(() => {
    proceedNextQuestion();
  }, 1400);
}

function disableAllAnswerButtons() {
  const buttons = document.querySelectorAll('.ans-btn');
  buttons.forEach(btn => btn.disabled = true);
}

function highlightCorrectButton(targetId) {
  const q = state.quiz.questions[state.quiz.currentIndex];
  const buttons = document.querySelectorAll('.ans-btn');
  q.options.forEach((opt, idx) => {
    if (opt.id === targetId && buttons[idx]) {
      buttons[idx].classList.add('correct');
    }
  });
}

function proceedNextQuestion() {
  state.quiz.currentIndex++;
  if (state.quiz.currentIndex < state.quiz.questions.length) {
    renderCurrentQuestion();
  } else {
    finishQuiz();
  }
}

function finishQuiz() {
  state.quiz.active = false;
  sounds.playFinish();

  const totalQuestions = state.quiz.questions.length;
  const correctCount = totalQuestions - state.quiz.wrongAnswers.length;
  const percentage = Math.round((correctCount / totalQuestions) * 100);

  document.getElementById('result-percentage').textContent = `${percentage}%`;
  document.getElementById('res-correct-count').textContent = correctCount;
  document.getElementById('res-wrong-count').textContent = state.quiz.wrongAnswers.length;
  document.getElementById('res-total-score').textContent = state.quiz.score;

  const trophyEl = document.getElementById('result-trophy');
  const titleEl = document.getElementById('result-title');
  const subtitleEl = document.getElementById('result-subtitle');

  if (percentage === 100) {
    trophyEl.textContent = '👑';
    titleEl.textContent = 'Xuất Sắc Tuyệt Đối!';
    subtitleEl.textContent = 'Phản xạ của bạn cực kỳ nhanh nhạy và chính xác 100%!';
  } else if (percentage >= 80) {
    trophyEl.textContent = '🏆';
    titleEl.textContent = 'Kết Quả Rất Tốt!';
    subtitleEl.textContent = 'Bạn đã ghi nhớ rất vững các bộ thủ tiếng Nhật!';
  } else if (percentage >= 50) {
    trophyEl.textContent = '🎯';
    titleEl.textContent = 'Khá Tốt! Cần Luyện Thêm';
    subtitleEl.textContent = 'Hãy xem lại các câu trả lời sai bên dưới để nhớ lâu hơn nhé.';
  } else {
    trophyEl.textContent = '💪';
    titleEl.textContent = 'Đừng Nản Lòng!';
    subtitleEl.textContent = 'Học thêm qua thẻ Flashcard và thử lại một lần nữa nhé!';
  }

  // Review sai
  const reviewSection = document.getElementById('review-section');
  const reviewList = document.getElementById('review-list');
  reviewList.innerHTML = '';

  if (state.quiz.wrongAnswers.length > 0) {
    reviewSection.style.display = 'block';
    state.quiz.wrongAnswers.forEach(item => {
      const row = document.createElement('div');
      row.className = 'review-item';
      row.innerHTML = `
        <div style="display: flex; align-items: center;">
          <span class="review-radical">${item.target.radical}</span>
          <div>
            <strong>${item.target.hanViet}</strong> (${item.target.nameJp})
            <div style="color: var(--text-secondary); font-size: 12px;">${item.target.meaning}</div>
          </div>
        </div>
        <div style="text-align: right; color: var(--accent-red); font-size: 12px;">
          ${item.userAnswer ? `Bạn chọn: ${item.userAnswer.hanViet || item.userAnswer.radical}` : 'Hết 8s'}
        </div>
      `;
      reviewList.appendChild(row);
    });
  } else {
    reviewSection.style.display = 'none';
  }

  showQuizScreen('result');
}

/* ===================================================
   5. FLASHCARD LẬT THẺ
=================================================== */
function initFlashcard() {
  state.flashcard.filteredList = [...RADICALS_DATA];
  state.flashcard.currentIndex = 0;
  state.flashcard.isFlipped = false;

  const card = document.getElementById('flip-card');
  card.addEventListener('click', toggleFlashcardFlip);

  document.getElementById('fc-flip-btn').addEventListener('click', toggleFlashcardFlip);

  document.getElementById('fc-prev-btn').addEventListener('click', () => {
    if (state.flashcard.currentIndex > 0) {
      state.flashcard.currentIndex--;
      unflipAndShowCard();
    }
  });

  document.getElementById('fc-next-btn').addEventListener('click', () => {
    if (state.flashcard.currentIndex < state.flashcard.filteredList.length - 1) {
      state.flashcard.currentIndex++;
      unflipAndShowCard();
    }
  });

  // Bộ lọc nhóm nét của flashcard
  document.getElementById('fc-group-filter').addEventListener('change', (e) => {
    const val = e.target.value;
    if (val === 'all') {
      state.flashcard.filteredList = [...RADICALS_DATA];
    } else if (val === '1') {
      state.flashcard.filteredList = RADICALS_DATA.filter(r => r.strokes === 1);
    } else if (val === '2') {
      state.flashcard.filteredList = RADICALS_DATA.filter(r => r.strokes === 2);
    } else if (val === '3') {
      state.flashcard.filteredList = RADICALS_DATA.filter(r => r.strokes === 3);
    } else if (val === '4') {
      state.flashcard.filteredList = RADICALS_DATA.filter(r => r.strokes === 4);
    } else if (val === '5-6') {
      state.flashcard.filteredList = RADICALS_DATA.filter(r => r.strokes >= 5 && r.strokes <= 6);
    } else if (val === '7+') {
      state.flashcard.filteredList = RADICALS_DATA.filter(r => r.strokes >= 7);
    }
    state.flashcard.currentIndex = 0;
    unflipAndShowCard();
  });

  updateFlashcardView();
}

function toggleFlashcardFlip() {
  const card = document.getElementById('flip-card');
  state.flashcard.isFlipped = !state.flashcard.isFlipped;
  card.classList.toggle('flipped', state.flashcard.isFlipped);
}

function unflipAndShowCard() {
  const card = document.getElementById('flip-card');
  state.flashcard.isFlipped = false;
  card.classList.remove('flipped');
  updateFlashcardView();
}

function updateFlashcardView() {
  const list = state.flashcard.filteredList;
  const currentIdx = state.flashcard.currentIndex;
  const total = list.length;

  document.getElementById('fc-current-idx').textContent = total > 0 ? currentIdx + 1 : 0;
  document.getElementById('fc-total-count').textContent = total;

  document.getElementById('fc-prev-btn').disabled = currentIdx <= 0;
  document.getElementById('fc-next-btn').disabled = currentIdx >= total - 1;

  if (total === 0) return;

  const item = list[currentIdx];

  // Mặt trước
  document.getElementById('fc-front-id').textContent = `#${item.id}`;
  document.getElementById('fc-front-radical').textContent = item.radical;
  document.getElementById('fc-front-strokes').textContent = `${item.strokes} Nét`;

  // Mặt sau
  document.getElementById('fc-back-radical').textContent = item.radical;
  document.getElementById('fc-back-hanviet').textContent = item.hanViet;
  document.getElementById('fc-back-jp').textContent = `${item.nameJp} (${item.romaji})`;
  document.getElementById('fc-back-meaning').textContent = item.meaning;

  const examplesBox = document.getElementById('fc-back-examples');
  examplesBox.innerHTML = '';
  const examples = item.examples || [];
  if (examples.length === 0) {
    examplesBox.innerHTML = `<span style="color: var(--text-muted); font-size: 13px;">Đang cập nhật ví dụ...</span>`;
  } else {
    examples.slice(0, 5).forEach(ex => {
      const div = document.createElement('div');
      div.className = 'fc-example-item';
      const readText = ex.hiragana ? `${ex.hiragana} [${ex.romaji}]` : (ex.romaji ? `[${ex.romaji}]` : '');
      div.innerHTML = `
        <div>
          <span class="fc-example-kanji">${ex.kanji}</span>
          <span style="color: var(--accent-gold); font-size: 12px; margin-left: 8px;">${readText}</span>
        </div>
        <span style="color: var(--text-secondary); font-size: 13px;">${ex.meaning}</span>
      `;
      examplesBox.appendChild(div);
    });
  }
}
